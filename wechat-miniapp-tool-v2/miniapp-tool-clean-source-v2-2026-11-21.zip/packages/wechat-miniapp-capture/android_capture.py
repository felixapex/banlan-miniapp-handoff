"""Generic Android miniapp UI capture with incremental E: output."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess

from capture.platforms.android import AndroidDevice, SHARE_LINK, classify_link, open_shared_text_in_self_chat
from capture.core.brand_store import create_brand_run
from capture.core.config import require_e_output
from capture.verification.response_observer import ResponseObserver
from capture.core.visual_explorer import explore_visible
from capture.verification.verify_visible_capture import verify_capture


ACCOUNT_PAUSE = Path(__file__).resolve().parents[2] / "artifacts" / "isolated-android" / "ACCOUNT-AUTOMATION-PAUSED.txt"


def main():
    parser = argparse.ArgumentParser(description="Capture a WeChat miniapp on one Android device through ADB")
    parser.add_argument("--adb", default="adb", help="Path to adb.exe, preferably on E:")
    parser.add_argument("--serial", help="ADB serial when multiple devices are connected")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor", help="Check one authorized device and WeChat installation")
    capture = commands.add_parser("capture", help="Open a miniapp link and collect bounded screenshots and visible text")
    capture.add_argument("--link", required=True)
    capture.add_argument("--output", help="Existing run to resume, or a new E: directory; omitted creates a brand run")
    capture.add_argument("--max-pages", type=int, default=30)
    capture.add_argument("--max-depth", type=int, default=3)
    capture.add_argument("--max-scrolls", type=int, default=20)
    capture.add_argument("--max-actions", type=int, default=500)
    capture.add_argument("--no-ocr", action="store_true", help="Disable screenshot OCR; visual-only pages will have no text")
    args = parser.parse_args()

    if args.command == "capture":
        kind = classify_link(args.link)
        output = Path(args.output).resolve() if args.output else None
        if output is not None:
            require_e_output(str(output))
        if not (1 <= args.max_pages <= 500 and 0 <= args.max_depth <= 10 and
                1 <= args.max_scrolls <= 50 and 1 <= args.max_actions <= 5000):
            raise ValueError("exploration limits out of range")
        resume = output is not None and output.exists() and (output / "capture.json").is_file()
        if output is not None and output.exists() and any(output.iterdir()) and not resume:
            raise RuntimeError("Existing capture found without a resumable manifest; choose a new E: output directory")
        if resume:
            source = json.loads((output / "input.json").read_text(encoding="utf-8"))
            saved = json.loads((output / "capture.json").read_text(encoding="utf-8"))
            if source.get("link") != args.link or source.get("kind") != kind or saved.get("kind") != "visible-miniapp-capture":
                raise RuntimeError("Existing capture input does not match this miniapp link or format")
        if ACCOUNT_PAUSE.exists():
            raise RuntimeError(f"WeChat account automation is paused after an invalid-login warning: {ACCOUNT_PAUSE}")
    device = AndroidDevice(args.adb, args.serial)
    serial = device.select()
    print(f"authorized Android device: {serial}", flush=True)
    if args.command == "doctor":
        print("WeChat installation: found; no UI action sent", flush=True)
        return

    ocr = None
    if not args.no_ocr:
        from capture.core.ocr import ScreenshotOcr
        ocr = ScreenshotOcr()

    auto_new = output is None
    if auto_new:
        match = SHARE_LINK.fullmatch(args.link)
        brand = match.group(1) if match else f"wechat-link-{hashlib.sha256(args.link.encode()).hexdigest()[:8]}"
        brands_root = Path(__file__).resolve().parents[2] / "artifacts" / "brands"
        output = create_brand_run(brands_root, brand, args.link)
    output.mkdir(parents=True, exist_ok=True)
    if resume and source.get("serial") != serial:
        raise RuntimeError("Resuming capture requires the same Android device")
    if not resume:
        input_data = json.loads((output / "input.json").read_text(encoding="utf-8")) if auto_new else {}
        input_data.update({"link": args.link, "kind": kind, "serial": serial})
        (output / "input.json").write_text(json.dumps(input_data, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        if kind == "wechat_share_text":
            open_shared_text_in_self_chat(device, args.link)
        else:
            device.open_link(args.link)
        result = explore_visible(device, output, max_screens=args.max_pages, max_depth=args.max_depth,
                                 max_scrolls=args.max_scrolls, max_actions=args.max_actions,
                                 ocr=ocr, observer=ResponseObserver(output), allow_input_only=auto_new)
    except (RuntimeError, subprocess.TimeoutExpired) as error:
        (output / "failure.json").write_text(json.dumps({"error": str(error), "type": type(error).__name__}, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            (output / "failure.png").write_bytes(device.screenshot())
        except (RuntimeError, subprocess.TimeoutExpired):
            pass
        raise
    print(f"captured screens={len(result['screens'])} attempts={len(result['attempts'])} stopReason={result['stopReason']}", flush=True)
    verification = verify_capture(output)
    print(f"verified observed scope={verification['observedScopeVerified']} pending controls={verification['pendingControls']}", flush=True)
    if not verification["observedScopeVerified"]:
        raise RuntimeError(f"capture unfinished; see {output / 'verification.json'} and resume this run")


if __name__ == "__main__":
    try:
        main()
    except (FileNotFoundError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
        raise SystemExit(f"android capture error: {error}") from None
