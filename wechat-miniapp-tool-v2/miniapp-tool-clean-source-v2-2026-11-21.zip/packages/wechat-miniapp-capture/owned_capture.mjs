/** Capture an owned miniapp only through an already-running local DevTools test session. */
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const packageDir = path.dirname(fileURLToPath(import.meta.url));
const workspaceRoot = path.resolve(packageDir, '../..');
const pngSignature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

export function validateOwnedOptions({ inventoryPath, output, wsEndpoint, maxPages = 100 }) {
  if (typeof inventoryPath !== 'string' || !/^[Ee]:[\\/]/.test(inventoryPath)) throw new Error('Source inventory must be an E: file');
  const source = path.resolve(inventoryPath);
  if (!fs.existsSync(source) || !fs.statSync(source).isFile()) throw new Error('Source inventory file not found');
  const inventory = JSON.parse(fs.readFileSync(source, 'utf8'));
  if (inventory.kind !== 'own-miniapp-source' || !Array.isArray(inventory.pages) || !inventory.pages.length)
    throw new Error('Invalid own-miniapp source inventory');
  if (typeof inventory.project !== 'string' || !/^[Ee]:[\\/]/.test(inventory.project)) throw new Error('Project must be on E:');
  const project = path.resolve(inventory.project);
  const settingsFile = path.join(project, 'project.config.json');
  if (!fs.existsSync(settingsFile)) throw new Error('Owned project needs project.config.json and its AppID');
  const settings = JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
  if (!/^wx[0-9a-f]{16}$/i.test(settings.appid || '')) throw new Error('Owned project AppID is missing or invalid');
  if (inventory.pages.some(route => typeof route !== 'string' || !/^[A-Za-z0-9_/-]+$/.test(route) || route.split('/').some(part => !part || part === '..')))
    throw new Error('Invalid page route in source inventory');
  let endpoint;
  try { endpoint = new URL(wsEndpoint); } catch { throw new Error('An explicit loopback wsEndpoint is required'); }
  if (endpoint.protocol !== 'ws:' || !['127.0.0.1', 'localhost', '[::1]'].includes(endpoint.hostname) ||
      !endpoint.port || endpoint.username || endpoint.password || endpoint.pathname !== '/' || endpoint.search || endpoint.hash)
    throw new Error('wsEndpoint must be an explicit loopback WebSocket port');
  if (typeof output !== 'string' || !/^[Ee]:[\\/]/.test(output)) throw new Error('Output must be an E: directory');
  const destination = path.resolve(output);
  if (!destination.startsWith(workspaceRoot + path.sep)) throw new Error('Output must be inside the E: workspace');
  if (fs.existsSync(destination)) throw new Error('Output must be a new directory');
  if (!Number.isInteger(maxPages) || maxPages < 1 || maxPages > 500) throw new Error('maxPages must be 1..500');
  return { inventory, inventoryPath: source, output: destination, wsEndpoint: endpoint.href, appId: settings.appid, pages: inventory.pages.slice(0, maxPages), maxPages };
}

export async function captureOwned(options) {
  const selected = validateOwnedOptions(options);
  const { output } = selected;
  fs.mkdirSync(output, { recursive: true });
  fs.mkdirSync(path.join(output, 'screenshots'));
  fs.mkdirSync(path.join(output, 'pages'));
  fs.copyFileSync(selected.inventoryPath, path.join(output, 'source-inventory.json'));
  const manifest = {
    kind: 'owned-miniapp-devtools-capture', appId: selected.appId, project: selected.inventory.project,
    pages: [], errors: [], requestedPages: selected.pages.length, sourcePages: selected.inventory.pages.length,
    completeMiniapp: false, sessionDisconnected: false, success: false,
  };
  const save = () => fs.writeFileSync(path.join(output, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
  let miniProgram;
  try {
    const automator = options.automator || (await import('miniprogram-automator')).default;
    miniProgram = await automator.connect({ wsEndpoint: selected.wsEndpoint });
    const actualAppId = await miniProgram.evaluate(() => wx.getAccountInfoSync().miniProgram.appId);
    if (actualAppId !== selected.appId) throw new Error(`AppID mismatch: expected ${selected.appId}, got ${actualAppId}`);
    for (const [index, route] of selected.pages.entries()) {
      const number = String(index + 1).padStart(4, '0');
      const screenshot = `screenshots/${number}.png`;
      const data = `pages/${number}.json`;
      const entry = { route, status: 'error' };
      try {
        const page = await miniProgram.reLaunch(`/${route}`);
        if (!page || page.path.replace(/^\//, '') !== route) throw new Error('Navigation did not reach the requested page');
        await page.waitFor(500);
        await miniProgram.screenshot({ path: path.join(output, screenshot) });
        const bytes = fs.readFileSync(path.join(output, screenshot));
        if (!bytes.subarray(0, 8).equals(pngSignature)) throw new Error('DevTools screenshot is not a PNG');
        const pageData = await page.data();
        const dataBytes = Buffer.from(JSON.stringify(pageData, null, 2), 'utf8');
        fs.writeFileSync(path.join(output, data), dataBytes);
        Object.assign(entry, { status: 'saved', screenshot, data, screenshotBytes: bytes.length,
          screenshotSha256: crypto.createHash('sha256').update(bytes).digest('hex'),
          dataSha256: crypto.createHash('sha256').update(dataBytes).digest('hex') });
      } catch (error) {
        entry.error = String(error.message || error);
      }
      manifest.pages.push(entry);
      save();
    }
  } catch (error) {
    manifest.errors.push(String(error.message || error));
    throw error;
  } finally {
    if (miniProgram) {
      try { await miniProgram.disconnect(); manifest.sessionDisconnected = true; }
      catch (error) { manifest.errors.push(`disconnect: ${String(error.message || error)}`); }
    }
    manifest.success = manifest.sessionDisconnected && manifest.errors.length === 0 &&
      manifest.pages.length === selected.pages.length && manifest.pages.every(page => page.status === 'saved');
    save();
  }
  return manifest;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = Object.fromEntries(process.argv.slice(2).filter((_, index) => index % 2 === 0)
    .map((name, index) => [name, process.argv[3 + index * 2]]));
  captureOwned({ inventoryPath: args['--inventory'], output: args['--output'], wsEndpoint: args['--ws-endpoint'],
    maxPages: Number(args['--max-pages'] || 100) })
    .then(result => { console.log(JSON.stringify({ saved: result.pages.filter(page => page.status === 'saved').length,
      errors: result.errors.length + result.pages.filter(page => page.status === 'error').length,
      disconnected: result.sessionDisconnected, success: result.success }));
      if (!result.success) process.exitCode = 1; })
    .catch(error => { console.error(`owned capture error: ${error.message}`); process.exitCode = 1; });
}
