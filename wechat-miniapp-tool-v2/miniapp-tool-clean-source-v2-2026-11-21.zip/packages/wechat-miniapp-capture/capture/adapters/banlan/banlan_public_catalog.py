"""Read public Banlan category and product GET endpoints observed in a live miniapp run."""

import argparse
import json
from pathlib import Path
import time
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit
from urllib.request import urlopen


def saved_entries(run):
    return [json.loads(line) for line in (run / "responses.jsonl").read_text(encoding="utf-8").splitlines()]


def observed_urls(run):
    entries = saved_entries(run)
    category = next(e for e in entries if "/store/good/getList" in e.get("url", "") and e.get("status") == "saved")
    list_request = next(e for e in entries if "/xcx/custom/good/findPageByCid?" in e.get("url", "") and e.get("status") == "saved")
    detail_request = next(e for e in entries if "/xcx/custom/good/detail?" in e.get("url", "") and e.get("status") == "saved")
    return entries, category, list_request["url"], detail_request["url"]


def changed_url(template, changes):
    parsed = urlsplit(template)
    if parsed.scheme != "https" or parsed.hostname != "mpapi.banlan.com.cn":
        raise ValueError("unexpected API host")
    query = {key: vals[-1] for key, vals in parse_qs(parsed.query).items()}
    query.update(changes)
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), ""))


def get_json(url, destination):
    if destination.is_file():
        return json.loads(destination.read_text(encoding="utf-8"))
    with urlopen(url, timeout=15) as response:
        if urlsplit(response.geturl()).hostname != "mpapi.banlan.com.cn":
            raise ValueError("unexpected API redirect")
        body = response.read(8 * 1024 * 1024 + 1)
    if len(body) > 8 * 1024 * 1024:
        raise ValueError("API response exceeds 8 MiB")
    data = json.loads(body)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(body)
    time.sleep(0.2)
    return data


def categories(run, category_entry, template):
    source = json.loads((run / category_entry["file"]).read_text(encoding="utf-8"))
    children = [(top.get("name"), child) for top in source["list"] for child in top.get("children", [])]
    target_dir = run / "catalog" / "category-pages"
    records = []
    products = {}
    for parent, child in children:
        cid = child["id"]
        for start in range(1, 21):
            url = changed_url(template, {"cid": str(cid), "start": str(start), "limit": "200"})
            target = target_dir / f"{cid}-{start}.json"
            try:
                data = get_json(url, target)
                if str(data.get("code")) != "0" or not isinstance(data.get("page", {}).get("list"), list):
                    raise ValueError("unexpected category response")
                items = data["page"]["list"]
                for item in items:
                    if item.get("id"):
                        products[str(item["id"])] = item
                records.append({"id": cid, "parent": parent, "name": child.get("name"),
                                "page": start, "file": str(target.relative_to(run)).replace("\\", "/"), "items": len(items)})
                print("category", cid, "page", start, "items", len(items))
                if data["page"].get("lastPage") or not items:
                    break
            except Exception as error:
                records.append({"id": cid, "page": start, "error": str(error)})
                print("category error", cid, start, str(error))
                break
    result = {"categories": records, "uniqueProducts": len(products), "products": list(products.values())}
    (run / "catalog" / "all-products.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def details(run, template, entries):
    source = json.loads((run / "catalog" / "all-products.json").read_text(encoding="utf-8"))
    existing = {}
    for e in entries:
        if "/xcx/custom/good/detail?" in e.get("url", "") and e.get("status") == "saved":
            data = json.loads((run / e["file"]).read_text(encoding="utf-8"))
            good = data.get("good")
            if isinstance(good, dict) and good.get("id"):
                existing[str(good["id"])] = e["file"]
    target_dir = run / "catalog" / "product-details"
    results = []
    for index, item in enumerate(source["products"], 1):
        pid = str(item["id"])
        if pid in existing:
            results.append({"id": pid, "file": existing[pid], "source": "live miniapp capture"})
            continue
        url = changed_url(template, {"gid": pid})
        target = target_dir / f"{pid}.json"
        try:
            data = get_json(url, target)
            if str(data.get("code")) != "0" or str(data.get("good", {}).get("id")) != pid:
                raise ValueError("unexpected product detail response")
            results.append({"id": pid, "file": str(target.relative_to(run)).replace("\\", "/"), "source": "observed public GET"})
            print("detail", index, len(source["products"]))
        except Exception as error:
            results.append({"id": pid, "error": str(error)})
            print("detail error", pid, str(error))
    (run / "catalog" / "detail-index.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--mode", choices=["categories", "details"], required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    if run.drive.upper() != "E:" or run.parent.name != "runs" or not (run / "input.json").is_file():
        raise SystemExit("expected one existing E-drive brand run")
    entries, category_entry, list_template, detail_template = observed_urls(run)
    if args.mode == "categories":
        data = categories(run, category_entry, list_template)
        print(json.dumps({"categories": len(data["categories"]), "uniqueProducts": data["uniqueProducts"],
                          "errors": sum("error" in c for c in data["categories"])}))
    else:
        data = details(run, detail_template, entries)
        print(json.dumps({"details": sum("file" in d for d in data), "errors": sum("error" in d for d in data)}))


if __name__ == "__main__":
    main()
