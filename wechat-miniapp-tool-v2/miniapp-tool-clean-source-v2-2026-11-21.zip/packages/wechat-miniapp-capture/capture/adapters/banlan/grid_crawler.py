"""Discover two-column article cards and capture each live detail page."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct
import time

import win32api
import win32con
import win32gui

from capture.core.config import require_e_output
from capture.platforms.full_page import capture_page, changed_ratio, content_pixels
from capture.platforms.windows_ui import _activate, _capture, _click, _windows


def bmp_rows(file):
    image = file.read_bytes()
    offset = struct.unpack_from("<I", image, 10)[0]
    width, height = struct.unpack_from("<ii", image, 18)
    if image[:2] != b"BM" or (width, height) != (430, 788) or struct.unpack_from("<H", image, 28)[0] != 32:
        raise ValueError("expected a 430x788 BGRA BMP list screenshot")
    stride = width * 4
    return [memoryview(image)[offset + (height - 1 - y) * stride:offset + (height - y) * stride] for y in range(height)]


def card_hash(rows, x1, x2, bottom):
    digest = hashlib.sha256()
    for y in range(bottom - 100, bottom):
        digest.update(rows[y][x1 * 4:x2 * 4])
    return digest.hexdigest()


def visible_bands(rows):
    active = []
    for y in range(105, 715):
        colored = 0
        for x in (*range(19, 207), *range(222, 410)):
            pixel = rows[y][x * 4:x * 4 + 3]
            if min(pixel) < 230:
                colored += 1
        active.append(colored / 376 > 0.45)
    spans = []
    start = None
    for offset, value in enumerate(active):
        if value and start is None:
            start = offset + 105
        if start is not None and (not value or offset == len(active) - 1):
            end = offset + 105 if not value else offset + 106
            if end - start >= 5:
                spans.append([start, end])
            start = None
    merged = []
    for start, end in spans:
        if merged and start - merged[-1][1] <= 35:
            merged[-1][1] = end
        else:
            merged.append([start, end])
    return [(start, end) for start, end in merged if end - start >= 70 and start > 105 and end < 715]


def discover(list_dir, run):
    files = sorted(list_dir.glob("screen-*.bmp"))
    if not files:
        raise ValueError("no saved list screens")
    cards = []
    seen = set()
    for index, file in enumerate(files):
        rows = bmp_rows(file)
        for _, bottom in visible_bands(rows):
            for column, (x1, x2) in enumerate(((19, 207), (222, 410))):
                key = card_hash(rows, x1, x2, bottom)
                if key in seen:
                    continue
                seen.add(key)
                cards.append({"hash": key, "listScreen": index, "column": column,
                              "x": 100 if column == 0 else 300, "y": bottom - 50, "imageBottom": bottom})
    (run / "grid-cards.json").write_text(json.dumps({"listScreens": len(files), "cards": cards}, indent=2), encoding="utf-8")
    return cards


def find_card(rows, reference_rows, card):
    x1, x2 = ((19, 207), (222, 410))[card["column"]]
    top_row = bytes(reference_rows[card["imageBottom"] - 100][x1 * 4:x2 * 4])
    matches = []
    for top in range(110, 615):
        if bytes(rows[top][x1 * 4:x2 * 4]) != top_row:
            continue
        bottom = top + 100
        if card_hash(rows, x1, x2, bottom) == card["hash"]:
            matches.append(bottom - 50)
    if len(matches) > 1:
        raise RuntimeError("same card image appears multiple times in one viewport")
    return matches[0] if matches else None


def reference_rows_for(cards, list_dir):
    return {screen: bmp_rows(list_dir / f"screen-{screen:03d}.bmp")
            for screen in {card["listScreen"] for card in cards}}


def visible_orders(rows, cards, references):
    anchors = {}
    for order, card in enumerate(cards):
        x1, x2 = ((19, 207), (222, 410))[card["column"]]
        key = bytes(references[card["listScreen"]][card["imageBottom"] - 100][x1 * 4:x2 * 4])
        anchors.setdefault((card["column"], key), []).append(order)
    found = set()
    for column, (x1, x2) in enumerate(((19, 207), (222, 410))):
        for top in range(110, 615):
            key = (column, bytes(rows[top][x1 * 4:x2 * 4]))
            for order in anchors.get(key, ()):
                if card_hash(rows, x1, x2, top + 100) == cards[order]["hash"]:
                    found.add(order)
    return found


def text_row_shift(rows, reference_rows):
    """Align unchanged title/metadata rows when lazy images changed after return."""
    offsets = Counter()
    for x1, x2 in ((19, 207), (222, 410)):
        anchors = {}
        for y in range(105, 715):
            row = reference_rows[y][x1 * 4:x2 * 4]
            dark = sum(max(row[x:x + 3]) < 140 for x in range(0, len(row), 4))
            white = sum(min(row[x:x + 3]) > 245 for x in range(0, len(row), 4))
            if 5 <= dark <= 80 and white > 100:
                anchors.setdefault(bytes(row), []).append(y)
        for y in range(105, 715):
            for original_y in anchors.get(bytes(rows[y][x1 * 4:x2 * 4]), ()):
                offsets[y - original_y] += 1
    if not offsets:
        return None
    best, count = offsets.most_common(1)[0]
    second = offsets.most_common(2)[1][1] if len(offsets) > 1 else 0
    return best if count >= 10 and count >= 2 * max(1, second) else None


def locate_card(rows, cards, references, order):
    card = cards[order]
    y = find_card(rows, references[card["listScreen"]], card)
    if y is not None:
        return y, "image"
    sibling_order = order + 1 if card["column"] == 0 else order - 1
    if 0 <= sibling_order < len(cards):
        sibling = cards[sibling_order]
        if (sibling["listScreen"] == card["listScreen"] and
                sibling["imageBottom"] == card["imageBottom"] and
                sibling["column"] != card["column"]):
            y = find_card(rows, references[sibling["listScreen"]], sibling)
            if y is not None:
                return y, "same-row sibling image"
    shift = text_row_shift(rows, references[card["listScreen"]])
    if shift is not None:
        y = card["y"] + shift
        if 110 <= y <= 700:
            return y, "list text alignment"
    return None, None


def crawl(title, run, cards, list_dir, limit, seed_first_slug):
    windows = _windows(title, "WeChatAppEx.exe")
    if len(windows) != 1:
        raise RuntimeError("expected one miniapp window")
    hwnd = windows[0]
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    if (right-left, bottom-top) != (430, 788):
        raise RuntimeError("miniapp window changed size")
    results_path = run / "grid-results.jsonl"
    done = {}
    if results_path.exists():
        for line in results_path.read_text(encoding="utf-8").splitlines():
            if line:
                entry = json.loads(line)
                if entry.get("status") == "saved":
                    done[entry["hash"]] = entry
    if seed_first_slug and cards[0]["hash"] not in done:
        seed = run / "screenshots" / "long-pages" / seed_first_slug / "manifest.json"
        if not seed.is_file():
            raise ValueError("seed page is missing")
        data = json.loads(seed.read_text(encoding="utf-8"))
        if not data["steps"][-1].get("endOfPage"):
            raise ValueError("seed page has not reached bottom")
        record = {"hash": cards[0]["hash"], "status": "saved", "slug": seed_first_slug,
                  "screens": len(data["steps"]), "endOfPage": True, "source": "earlier verified capture"}
        results_path.open("a", encoding="utf-8").write(json.dumps(record) + "\n")
        done[record["hash"]] = record
    references = reference_rows_for(cards, list_dir)
    completed = 0
    for order, card in enumerate(cards):
        if card["hash"] in done:
            continue
        if completed >= limit:
            break
        before = run / "screenshots" / "long-pages" / ".grid-before.bmp"
        y = None
        located_by = None
        for _ in range(80):
            _capture(hwnd, before)
            rows = bmp_rows(before)
            y, located_by = locate_card(rows, cards, references, order)
            if y is not None:
                break
            visible = visible_orders(rows, cards, references)
            if not visible:
                aligned_screens = [screen for screen, reference in references.items()
                                   if text_row_shift(rows, reference) is not None]
                if not aligned_screens:
                    raise RuntimeError(f"cannot locate any known list content while seeking card {order}")
                current = min(aligned_screens, key=lambda screen: abs(screen - card["listScreen"]))
                distance = 120 if card["listScreen"] < current else -120
                _activate(hwnd)
                win32api.SetCursorPos((left + 215, top + 400))
                win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, distance, 0)
                time.sleep(0.9)
                continue
            if order < min(visible):
                distance = 120 if min(visible) - order <= 6 else 420
            elif order > max(visible):
                distance = -120 if order - max(visible) <= 6 else -420
            else:
                raise RuntimeError(f"card {order} is between visible cards but its image was not found")
            _activate(hwnd)
            win32api.SetCursorPos((left + 215, top + 400))
            win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, distance, 0)
            time.sleep(0.9)
        if y is None:
            raise RuntimeError(f"list card {order} could not be located within 80 small scrolls")
        x1, x2 = ((19, 207), (222, 410))[card["column"]]
        _click(hwnd, card["x"], y)
        time.sleep(1.1)
        entered = run / "screenshots" / "long-pages" / ".grid-entered.bmp"
        _capture(hwnd, entered)
        if changed_ratio(content_pixels(before, 430, 788, 105, 715),
                         content_pixels(entered, 430, 788, 105, 715)) < 0.1:
            raise RuntimeError(f"card {order} did not open a detail page")
        slug = f"diary-card-{order:03d}-{card['hash'][:10]}"
        steps = capture_page(title, run, slug, 100, -520, 430, 788, 55, 775, rewind_to_top=True)
        if not steps[-1].get("endOfPage"):
            steps = capture_page(title, run, slug, 200, -520, 430, 788, 55, 775, resume=True)
        result = {"hash": card["hash"], "status": "saved" if steps[-1].get("endOfPage") else "partial",
                  "slug": slug, "screens": len(steps), "endOfPage": bool(steps[-1].get("endOfPage"))}
        results_path.open("a", encoding="utf-8").write(json.dumps(result) + "\n")
        _click(hwnd, 38, 40)
        time.sleep(0.8)
        returned = run / "screenshots" / "long-pages" / ".grid-returned.bmp"
        _capture(hwnd, returned)
        rows = bmp_rows(returned)
        if locate_card(rows, cards, references, order)[0] is None:
            raise RuntimeError(f"list position changed after article {order}")
        before.unlink(missing_ok=True)
        entered.unlink(missing_ok=True)
        returned.unlink(missing_ok=True)
        completed += 1
        print(json.dumps({"article": order + 1, "screens": len(steps),
                          "locatedBy": located_by, "status": result["status"]}), flush=True)
    return {"discovered": len(cards), "alreadyDone": len(done), "completedNow": completed}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--list-slug", required=True)
    parser.add_argument("--limit", type=int, default=200)
    parser.add_argument("--seed-first-slug")
    parser.add_argument("--discover-only", action="store_true")
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected one brand run on E")
    if not 1 <= args.limit <= 200:
        parser.error("limit must be 1..200")
    list_dir = run / "screenshots" / "long-pages" / args.list_slug
    cards = discover(list_dir, run)
    if args.discover_only:
        print(json.dumps({"cards": len(cards)}))
        return
    result = crawl(args.title, run, cards, list_dir, args.limit, args.seed_first_slug)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
