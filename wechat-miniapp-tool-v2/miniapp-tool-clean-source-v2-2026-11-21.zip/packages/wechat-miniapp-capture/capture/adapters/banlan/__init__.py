"""Banlan reference adapter used to validate the generic capture engine."""
