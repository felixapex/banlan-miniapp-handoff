"""Export public Banlan store details and storefront photos from an observed response."""

import argparse
import csv
import hashlib
import json
from pathlib import Path

from capture.adapters.banlan.banlan_gallery_assets import existing_files, fetch_asset, image_suffix, normalized_url
from capture.adapters.banlan.banlan_public_catalog import saved_entries
from capture.core.config import require_e_output


PUBLIC_FIELDS = ("id", "name", "pname", "cname", "address", "latitude", "longitude",
                 "service_telephone", "service_synopsis")


def source_stores(base):
    for entry in saved_entries(base):
        if "/xcx/custom/store/room/getShopeList?" in entry.get("url", "") and entry.get("status") == "saved":
            data = json.loads((base / entry["file"]).read_text(encoding="utf-8"))
            stores = data.get("list")
            if str(data.get("code")) != "0" or not isinstance(stores, list):
                raise ValueError("store response has an unexpected shape")
            return stores
    raise ValueError("no live store list response in source run")


def gallery_files(deep):
    ledger = deep / "gallery" / "assets" / "manifest.jsonl"
    found = {}
    if ledger.is_file():
        for line in ledger.read_text(encoding="utf-8").splitlines():
            entry = json.loads(line)
            if entry.get("status") in ("saved", "reused") and entry.get("file"):
                path = Path(entry["file"])
                if path.is_file():
                    found[entry["url"]] = path
    return found


def export(base, deep):
    source = source_stores(base)
    output = deep / "stores"
    assets = output / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    stores = []
    urls = {}
    for item in source:
        store = {key: item.get(key) for key in PUBLIC_FIELDS}
        raw = item.get("img_urls")
        images = json.loads(raw) if isinstance(raw, str) and raw.strip() else raw or []
        if not isinstance(images, list):
            raise ValueError("store image list has an unexpected shape")
        store["images"] = []
        for raw_url in images:
            url = normalized_url(raw_url)
            if url is None:
                raise ValueError("store image uses an unexpected host")
            store["images"].append(url)
            urls.setdefault(url, []).append(str(store["id"]))
        stores.append(store)
    old = existing_files(base)
    old.update(gallery_files(deep))
    ledger = assets / "manifest.jsonl"
    done = {}
    if ledger.is_file():
        for line in ledger.read_text(encoding="utf-8").splitlines():
            entry = json.loads(line)
            if entry.get("status") in ("saved", "reused") and Path(entry["file"]).is_file():
                done[entry["url"]] = entry
    for index, url in enumerate(sorted(urls), 1):
        if url in done:
            continue
        record = {"url": url, "storeIds": sorted(set(urls[url]))}
        try:
            if url in old:
                path = old[url]
                body = path.read_bytes()
                image_suffix(body)
                record["status"] = "reused"
            else:
                path, body = fetch_asset(url, assets)
                record["status"] = "saved"
            record.update({"file": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()})
        except Exception as error:
            record.update({"status": "error", "error": str(error)})
        with ledger.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        if index % 10 == 0 or record["status"] == "error":
            print(json.dumps({"image": index, "total": len(urls), "status": record["status"]}), flush=True)
    latest = {entry["url"]: entry for line in ledger.read_text(encoding="utf-8").splitlines()
              if (entry := json.loads(line))["url"] in urls}
    result = {"stores": stores, "storeCount": len(stores), "imageUrls": len(urls),
              "imagesSavedOrReused": sum(e["status"] in ("saved", "reused") for e in latest.values()),
              "imageErrors": [e for e in latest.values() if e["status"] == "error"]}
    (output / "public-stores.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with (output / "public-stores.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        columns = [*PUBLIC_FIELDS, "imageUrls"]
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows({**{key: item[key] for key in PUBLIC_FIELDS}, "imageUrls": " | ".join(item["images"])}
                         for item in stores)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-run", required=True)
    parser.add_argument("--deep-run", required=True)
    args = parser.parse_args()
    base = Path(args.base_run).resolve()
    deep = Path(args.deep_run).resolve()
    require_e_output(str(base))
    require_e_output(str(deep))
    if base.parent != deep.parent or base.parent.name != "runs" or not (deep / "input.json").is_file():
        parser.error("expected one Banlan brand run on E")
    result = export(base, deep)
    print(json.dumps({"stores": result["storeCount"], "images": result["imageUrls"],
                      "saved": result["imagesSavedOrReused"], "errors": len(result["imageErrors"])}))


if __name__ == "__main__":
    main()
