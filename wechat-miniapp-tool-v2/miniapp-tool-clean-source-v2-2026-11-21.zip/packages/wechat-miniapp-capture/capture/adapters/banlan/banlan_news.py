"""Collect the public Banlan news list and original covers without UI input."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit

from capture.adapters.banlan.banlan_gallery_assets import HOST, existing_files, fetch_asset, normalized_url
from capture.adapters.banlan.banlan_public_catalog import changed_url, get_json, saved_entries
from capture.core.config import require_e_output


def news_url(run):
    for entry in saved_entries(run):
        if urlsplit(entry.get("url", "")).path == "/xcx/custom/lanfenPage/page3" and entry.get("status") == "saved":
            return entry["url"]
    raise ValueError("news list endpoint was not observed in this miniapp run")


def collect(run):
    template = news_url(run)
    output = run / "news"
    pages = output / "pages"
    pages.mkdir(parents=True, exist_ok=True)
    articles = {}
    reported_total = None
    for number in range(1, 101):
        data = get_json(changed_url(template, {"start": str(number), "limit": "10"}),
                        pages / f"{number:03d}.json")
        page = data.get("page", {})
        items = page.get("list")
        if str(data.get("code")) != "0" or not isinstance(items, list) or page.get("pageNumber") != number:
            raise ValueError(f"news page {number} returned unexpected data")
        if reported_total is None:
            reported_total = page.get("totalRow")
        for item in items:
            article_id = str(item.get("id", ""))
            if not article_id:
                raise ValueError(f"news page {number} contains an item without id")
            articles[article_id] = item
        print(json.dumps({"page": number, "items": len(items), "unique": len(articles)}), flush=True)
        if page.get("lastPage"):
            break
    else:
        raise RuntimeError("news list did not end within 100 pages")
    result = {"reportedTotal": reported_total, "pages": number,
              "uniqueArticles": len(articles), "articles": list(articles.values())}
    (output / "all-articles.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with (output / "articles.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        columns = ["id", "title", "summary", "file_url", "create_time", "tid", "lid", "city", "area"]
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows({key: item.get(key) for key in columns} for item in articles.values())
    return result


def covers(run):
    output = run / "news"
    articles = json.loads((output / "all-articles.json").read_text(encoding="utf-8"))["articles"]
    refs = {}
    unresolved = []
    for article in articles:
        raw = article.get("file_url") or ""
        url = normalized_url(raw if raw.startswith("https://") else f"https://{HOST}/{raw.lstrip('/')}")
        if url:
            refs.setdefault(url, []).append(str(article["id"]))
        else:
            unresolved.append({"id": str(article["id"]), "file_url": raw})
    known = existing_files(run)
    for entry in saved_entries(run):
        if entry.get("kind") == "image" and entry.get("status") == "saved":
            url = normalized_url(entry.get("url", ""))
            file = run / entry.get("file", "")
            if url and file.is_file():
                known[url] = file
    asset_dir = output / "covers"
    asset_dir.mkdir(parents=True, exist_ok=True)
    ledger = asset_dir / "manifest.jsonl"
    latest = {}
    if ledger.is_file():
        for line in ledger.read_text(encoding="utf-8").splitlines():
            entry = json.loads(line)
            latest[entry["url"]] = entry
    for url, article_ids in sorted(refs.items()):
        old = latest.get(url)
        if old and old.get("status") in ("saved", "reused") and Path(old["file"]).is_file():
            continue
        record = {"url": url, "articleIds": article_ids}
        try:
            if url in known:
                file = known[url]
                body = file.read_bytes()
                record["status"] = "reused"
            else:
                file, body = fetch_asset(url, asset_dir)
                record["status"] = "saved"
            record.update({"file": str(file), "bytes": len(body),
                           "sha256": hashlib.sha256(body).hexdigest()})
        except Exception as error:
            record.update({"status": "error", "error": str(error)})
        with ledger.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        latest[url] = record
    result = {"articles": len(articles), "coverUrls": len(refs),
              "savedOrReused": sum(e.get("status") in ("saved", "reused") for e in latest.values() if e["url"] in refs),
              "errors": [e for e in latest.values() if e["url"] in refs and e.get("status") == "error"],
              "unresolved": unresolved}
    (output / "cover-summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected an existing E-drive brand run")
    result = collect(run)
    cover_result = covers(run)
    print(json.dumps({"newsArticles": result["uniqueArticles"], "reportedTotal": result["reportedTotal"],
                      "coverUrls": cover_result["coverUrls"], "coversSavedOrReused": cover_result["savedOrReused"],
                      "coverErrors": len(cover_result["errors"]), "unresolved": len(cover_result["unresolved"])}))


if __name__ == "__main__":
    main()
