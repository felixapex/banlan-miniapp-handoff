"""Mini-program-specific capture adapters."""
