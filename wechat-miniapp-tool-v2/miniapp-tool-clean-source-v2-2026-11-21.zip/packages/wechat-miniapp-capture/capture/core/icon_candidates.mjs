// Conservative pixel inventory of unlabeled controls near navigation and overlay edges.
// Reads PNG bytes from stdin; outputs candidate points, never performs input.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PNG } from 'pngjs';

export function detectIconCandidates(bytes, words = []) {
  const image = PNG.sync.read(bytes);
  const { width, height, data } = image;
  if (width > 4000 || height > 4000) throw new Error('image too large');
  const stride = 2;
  const at = (x, y) => (y * width + x) * 4;
  const difference = (a, b) => Math.max(Math.abs(data[a] - data[b]),
    Math.abs(data[a + 1] - data[b + 1]), Math.abs(data[a + 2] - data[b + 2]));
  const counts = new Uint32Array(width);
  for (let y = Math.floor(height * .12); y < height * .88; y += 8)
    for (let x = 0; x < width; x += 2) {
      const i = at(x, y);
      if (Math.min(data[i], data[i + 1], data[i + 2]) < 238) counts[x]++;
    }
  const threshold = Math.max(2, Math.floor(height * .76 / 8 * .20));
  let left = 0, right = width, start = -1, best = 0;
  for (let x = 0; x <= width; x += 2) {
    const on = x < width && counts[x] >= threshold;
    if (on && start < 0) start = x;
    if (!on && start >= 0) {
      if (x - start > best) { best = x - start; left = start; right = x; }
      start = -1;
    }
  }
  if (best < width * .15) { left = 0; right = width; }
  const gw = Math.ceil(width / stride), gh = Math.ceil(height / stride);
  const mask = new Uint8Array(gw * gh);
  const inText = (x, y) => words.some(word => {
    const box = word.bounds;
    return Array.isArray(box) && box.length === 4 &&
      x >= box[0] - 5 && x <= box[2] + 5 && y >= box[1] - 5 && y <= box[3] + 5;
  });
  for (let gy = 1; gy < gh - 1; gy++) for (let gx = 1; gx < gw - 1; gx++) {
    const x = gx * stride, y = gy * stride;
    if (x < left || x >= right || inText(x, y)) continue;
    const lateral = x < left + (right - left) * .20 || x >= right - (right - left) * .20;
    if (y >= height * .10 && y < height * .90 && !lateral) continue;
    const i = at(x, y);
    const edge = Math.max(difference(i, at(x + stride, y)), difference(i, at(x, y + stride)));
    if (edge >= 22) mask[gy * gw + gx] = 1;
  }
  const visited = new Uint8Array(mask.length);
  const candidates = [];
  for (let gy = 1; gy < gh - 1; gy++) for (let gx = 1; gx < gw - 1; gx++) {
    const first = gy * gw + gx;
    if (!mask[first] || visited[first]) continue;
    const queue = [first]; visited[first] = 1;
    let minX = gx, maxX = gx, minY = gy, maxY = gy, count = 0;
    for (let head = 0; head < queue.length; head++) {
      const position = queue[head], px = position % gw, py = Math.floor(position / gw);
      count++; minX = Math.min(minX, px); maxX = Math.max(maxX, px);
      minY = Math.min(minY, py); maxY = Math.max(maxY, py);
      if (queue.length > 3000) break;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        const nx = px + dx, ny = py + dy;
        if (nx < 0 || nx >= gw || ny < 0 || ny >= gh) continue;
        const next = ny * gw + nx;
        if (mask[next] && !visited[next]) { visited[next] = 1; queue.push(next); }
      }
    }
    const w = (maxX - minX + 1) * stride, h = (maxY - minY + 1) * stride;
    if (count < 3 || w < 5 || h < 5 || w > 72 || h > 72 || w / h < .25 || w / h > 4) continue;
    const x = (minX + maxX) * stride / 2, y = (minY + maxY) * stride / 2;
    if (inText(x, y)) continue;
    candidates.push({ x: Math.round(x), y: Math.round(y), bounds: [minX * stride, minY * stride,
      (maxX + 1) * stride, (maxY + 1) * stride], score: Math.min(1, count / 18) });
  }
  // A centered rectangular overlay can hide every page button. Inventory its
  // upper-right dismiss position even when the tiny cross defeats OCR.
  for (let y = Math.floor(height * .12); y < height * .65; y += 2) {
    let begin = -1;
    for (let x = left + 4; x <= right - 4; x += 2) {
      const edge = Math.max(difference(at(x, y - 2), at(x, y + 2)),
        difference(at(x + 1, y - 2), at(x + 1, y + 2)));
      if (edge >= 42 && begin < 0) begin = x;
      if ((edge < 42 || x >= right - 4) && begin >= 0) {
        const end = x;
        if (end - begin >= (right - left) * .35 && end - begin <= (right - left) * .88 &&
            end < right - 20 && y + 100 < height) {
          const rightEdge = difference(at(end - 4, y + 30), at(end + 4, y + 30));
          const lowerEdge = difference(at(end - 4, y + 90), at(end + 4, y + 90));
          const cx = end - 19, cy = y + 16;
          if (rightEdge >= 28 && lowerEdge >= 28)
            candidates.push({ x: cx, y: cy, bounds: [cx - 8, cy - 8, cx + 8, cy + 8],
              score: 1, shape: 'overlay-dismiss-candidate' });
        }
        begin = -1;
      }
    }
  }
  const distinct = [];
  for (const item of candidates.sort((a, b) => b.score - a.score)) {
    if (item.bounds[2] - item.bounds[0] > 48 || item.bounds[3] - item.bounds[1] > 48) continue;
    if (distinct.some(other => Math.abs(item.x - other.x) < 14 && Math.abs(item.y - other.y) < 14)) continue;
    distinct.push(item);
    if (distinct.length >= 60) break;
  }
  return distinct.map(item => ({ ...item, region: item.y < height * .10 &&
    item.x < left + (right - left) * .20 ? 'top-left' : 'other' }));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const words = JSON.parse(process.argv[2] || '[]');
  process.stdout.write(JSON.stringify(detectIconCandidates(fs.readFileSync(0), words)));
}
