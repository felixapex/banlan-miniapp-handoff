import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { PNG } from 'pngjs';
import { detectIconCandidates } from './icon_candidates.mjs';

const packageDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

test('finds the unlabeled overlay dismissal point in archived Banlan screenshot', () => {
  const base = path.resolve(packageDir, '../../artifacts/brands/班兰/runs/20261118-android-visual-proof/home');
  if (!fs.existsSync(base + '.png')) return;
  const candidates = detectIconCandidates(fs.readFileSync(base + '.png'),
    JSON.parse(fs.readFileSync(base + '.ocr.json', 'utf8')));
  assert.ok(candidates.some(item => item.shape === 'overlay-dismiss-candidate' &&
    Math.abs(item.x - 811) < 8 && Math.abs(item.y - 215) < 8));
});

test('does not invent a modal dismissal point on archived product page', () => {
  const base = path.resolve(packageDir, '../../artifacts/brands/班兰/runs/20261118-android-visual-proof/products');
  if (!fs.existsSync(base + '.png')) return;
  const candidates = detectIconCandidates(fs.readFileSync(base + '.png'),
    JSON.parse(fs.readFileSync(base + '.ocr.json', 'utf8')));
  assert.equal(candidates.some(item => item.shape === 'overlay-dismiss-candidate'), false);
});

test('keeps a plain empty image free of invented icon controls', () => {
  const image = new PNG({ width: 200, height: 200 });
  image.data.fill(255);
  assert.deepEqual(detectIconCandidates(PNG.sync.write(image)), []);
});
