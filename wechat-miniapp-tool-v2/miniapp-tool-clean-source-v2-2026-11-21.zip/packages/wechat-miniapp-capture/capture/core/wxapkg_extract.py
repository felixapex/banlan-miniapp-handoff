"""Read-only extraction for a cached Windows WeChat V1MMWX package."""

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import struct

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


MAGIC = b"V1MMWX"
SALT = b"saltiest"
IV = b"the iv: 16 bytes"
APP_ID = re.compile(r"^wx[0-9a-f]{16}$")


@dataclass(frozen=True)
class WxapkgMember:
    name: str
    offset: int
    size: int
    payload: bytes


def decrypt_v1mmwx(encrypted: bytes, app_id: str) -> bytes:
    if not APP_ID.fullmatch(app_id):
        raise ValueError("invalid mini-program AppID")
    if not encrypted.startswith(MAGIC):
        raise ValueError("package is not a V1MMWX Windows cache file")
    if len(encrypted) < len(MAGIC) + 1024:
        raise ValueError("truncated V1MMWX package")
    key = hashlib.pbkdf2_hmac("sha1", app_id.encode("ascii"), SALT, 1000, dklen=32)
    decryptor = Cipher(algorithms.AES(key), modes.CBC(IV)).decryptor()
    head = decryptor.update(encrypted[6:1030]) + decryptor.finalize()
    xor_key = app_id.encode("ascii")[-2]
    tail = bytes(value ^ xor_key for value in encrypted[1030:])
    plain = head[:1023] + tail
    if not plain.startswith(b"\xbe"):
        raise ValueError("decryption did not produce a wxapkg; AppID may be wrong")
    return plain


def _safe_member_name(raw_name: str) -> str:
    if "\\" in raw_name or "\x00" in raw_name:
        raise ValueError(f"unsafe member path: {raw_name!r}")
    name = raw_name.lstrip("/")
    parts = PurePosixPath(name).parts
    if not name or any(part in {"", ".", ".."} for part in parts) or ":" in parts[0]:
        raise ValueError(f"unsafe member path: {raw_name!r}")
    return PurePosixPath(*parts).as_posix()


def parse_wxapkg(plain: bytes) -> list[WxapkgMember]:
    if len(plain) < 18 or plain[0] != 0xBE or plain[13] != 0xED:
        raise ValueError("invalid wxapkg header")
    index_len, body_len = struct.unpack(">II", plain[5:13])
    declared_size = 14 + index_len + body_len
    if declared_size != len(plain):
        raise ValueError("wxapkg declared size does not match file size")
    index_end = 14 + index_len
    count = struct.unpack(">I", plain[14:18])[0]
    if count > 100_000:
        raise ValueError("wxapkg member count exceeds safety limit")
    cursor = 18
    members = []
    seen = set()
    body_start = index_end
    for _ in range(count):
        if cursor + 4 > index_end:
            raise ValueError("truncated wxapkg member table")
        name_len = struct.unpack(">I", plain[cursor:cursor + 4])[0]
        cursor += 4
        if name_len > 65_536 or cursor + name_len + 8 > index_end:
            raise ValueError("invalid wxapkg member name or table row")
        try:
            raw_name = plain[cursor:cursor + name_len].decode("utf-8")
        except UnicodeDecodeError as error:
            raise ValueError("invalid UTF-8 wxapkg member name") from error
        cursor += name_len
        offset, size = struct.unpack(">II", plain[cursor:cursor + 8])
        cursor += 8
        name = _safe_member_name(raw_name)
        if name in seen:
            raise ValueError(f"duplicate wxapkg member: {name}")
        if offset < body_start or offset + size > len(plain):
            raise ValueError(f"wxapkg member is outside data region: {name}")
        seen.add(name)
        members.append(WxapkgMember(name, offset, size, plain[offset:offset + size]))
    if cursor != index_end:
        raise ValueError("wxapkg member table length mismatch")
    return members


def extract_wxapkg(encrypted: bytes, app_id: str, output: Path) -> list[dict]:
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    members = parse_wxapkg(decrypt_v1mmwx(encrypted, app_id))
    manifest = []
    for member in members:
        target = (output / Path(*PurePosixPath(member.name).parts)).resolve()
        if output not in target.parents:
            raise ValueError(f"unsafe member path: {member.name!r}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(member.payload)
        manifest.append({
            "path": member.name,
            "bytes": member.size,
            "sha256": hashlib.sha256(member.payload).hexdigest(),
        })
    (output / "wxapkg-manifest.json").write_text(
        json.dumps({"appId": app_id, "members": manifest}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return manifest
