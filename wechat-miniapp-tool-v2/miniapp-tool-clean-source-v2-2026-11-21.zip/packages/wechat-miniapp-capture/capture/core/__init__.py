"""Reusable capture primitives and data export helpers."""
