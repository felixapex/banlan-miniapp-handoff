from pathlib import PureWindowsPath


def require_e_output(value: str) -> PureWindowsPath:
    path = PureWindowsPath(value)
    if path.drive.upper() != "E:" or not path.is_absolute() or len(path.parts) < 2:
        raise ValueError("Output must be an absolute directory on E:")
    return path


def validate_steps(steps: list[dict]) -> list[dict]:
    if not isinstance(steps, list) or len(steps) > 500:
        raise ValueError("steps must be a list of at most 500 actions")
    for step in steps:
        if not isinstance(step, dict) or step.get("action") not in {"click", "scroll", "wait", "screenshot"}:
            raise ValueError("unsupported step action")
        action = step["action"]
        if action in {"click", "scroll"}:
            for axis in ("x", "y"):
                if not isinstance(step.get(axis), int) or step[axis] < 0 or step[axis] > 20000:
                    raise ValueError(f"invalid {axis} coordinate")
        if action == "scroll" and (not isinstance(step.get("delta"), int) or abs(step["delta"]) > 10000):
            raise ValueError("invalid scroll delta")
        if action == "wait" and (not isinstance(step.get("seconds"), (int, float)) or not 0 <= step["seconds"] <= 30):
            raise ValueError("invalid wait duration")
        if "settle" in step and (not isinstance(step["settle"], (int, float)) or not 0 <= step["settle"] <= 30):
            raise ValueError("invalid settle duration")
        if "name" in step and (not isinstance(step["name"], str) or not step["name"].replace("-", "").replace("_", "").isalnum()):
            raise ValueError("invalid screenshot name")
        if "awaitPath" in step:
            wanted = step["awaitPath"]
            if action not in {"click", "scroll"} or not isinstance(wanted, str) or not (wanted == "/v2/ec/searchProducts" or wanted == "/v2/ec/products/"):
                raise ValueError("awaitPath must name an allowed product response")
            timeout = step.get("awaitTimeout", 20)
            if not isinstance(timeout, (int, float)) or not 0 < timeout <= 30:
                raise ValueError("invalid response wait timeout")
        elif "awaitTimeout" in step:
            raise ValueError("awaitTimeout requires awaitPath")
    return steps
