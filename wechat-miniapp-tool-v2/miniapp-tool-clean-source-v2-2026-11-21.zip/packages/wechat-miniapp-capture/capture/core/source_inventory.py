"""Read a developer-owned miniapp project without opening WeChat or DevTools."""

import hashlib
import json
import os
from pathlib import Path

from capture.core.config import require_e_output


WORKSPACE_ROOT = Path(__file__).resolve().parents[4]
ASSET_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.svg', '.ico', '.bmp', '.avif', '.woff', '.woff2', '.ttf', '.otf'}
EXCLUDED_DIRECTORIES = {'node_modules', '.git', '.cache', '.next', '.venv', 'venv', 'artifacts', 'coverage', 'test-results', '__pycache__'}


def _route(value):
    if not isinstance(value, str) or not value or value.startswith('/') or '\\' in value or ':' in value or '?' in value or '#' in value:
        raise ValueError(f'invalid page route: {value!r}')
    parts = value.split('/')
    if any(part in {'', '.', '..'} for part in parts):
        raise ValueError(f'invalid page route: {value!r}')
    return '/'.join(parts)


def _hash_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def inspect_project(project: Path) -> dict:
    project = Path(project).resolve()
    require_e_output(str(project))
    if not project.is_dir():
        raise ValueError('miniapp project directory does not exist')
    project_config = project / 'project.config.json'
    source = project
    if project_config.is_file():
        if project_config.stat().st_size > 2 * 1024 * 1024:
            raise ValueError('project.config.json is unexpectedly large')
        try:
            settings = json.loads(project_config.read_text(encoding='utf-8-sig'))
        except (UnicodeError, json.JSONDecodeError) as error:
            raise ValueError(f'invalid project.config.json: {error}') from error
        if not isinstance(settings, dict):
            raise ValueError('project.config.json must be an object')
        root = settings.get('miniprogramRoot', '')
        if root:
            if not isinstance(root, str) or root.startswith(('/', '\\')) or ':' in root:
                raise ValueError('invalid miniprogramRoot')
            normalized = root.replace('\\', '/').removeprefix('./').rstrip('/')
            source = (project / _route(normalized)).resolve()
            if not source.is_relative_to(project):
                raise ValueError('miniprogramRoot escapes project')
    app = source / 'app.json'
    if not app.is_file():
        raise ValueError('miniapp project is missing app.json')
    if app.stat().st_size > 2 * 1024 * 1024:
        raise ValueError('app.json is unexpectedly large')
    try:
        config = json.loads(app.read_text(encoding='utf-8-sig'))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ValueError(f'invalid app.json: {error}') from error
    if not isinstance(config, dict) or not isinstance(config.get('pages'), list):
        raise ValueError('app.json must contain a pages array')
    pages = []
    for value in config['pages']:
        route = _route(value)
        if route not in pages:
            pages.append(route)
    packages = config.get('subPackages', config.get('subpackages', []))
    if not isinstance(packages, list):
        raise ValueError('app.json subPackages must be an array')
    for package in packages:
        if not isinstance(package, dict) or not isinstance(package.get('pages'), list):
            raise ValueError('app.json has an invalid subpackage')
        root = _route(package.get('root'))
        for value in package['pages']:
            route = _route(f'{root}/{_route(value)}')
            if route not in pages:
                pages.append(route)
    assets = []
    for current, directories, filenames in os.walk(source, followlinks=False):
        current_path = Path(current)
        directories[:] = sorted(name for name in directories
                                if name.lower() not in EXCLUDED_DIRECTORIES
                                and not (current_path / name).is_symlink()
                                and not (current_path / name).is_junction())
        for name in sorted(filenames):
            path = current_path / name
            if path.suffix.lower() not in ASSET_EXTENSIONS or path.is_symlink() or not path.is_file():
                continue
            if not path.resolve().is_relative_to(source):
                raise ValueError(f'asset escapes project: {path}')
            assets.append({'path': path.relative_to(source).as_posix(), 'bytes': path.stat().st_size, 'sha256': _hash_file(path)})
            if len(assets) > 100000:
                raise ValueError('asset count exceeds 100000')
    assets.sort(key=lambda item: item['path'])
    return {'kind': 'own-miniapp-source', 'project': str(project), 'sourceRoot': source.relative_to(project).as_posix(),
            'projectConfigPresent': project_config.is_file(),
            'pages': pages, 'pageCount': len(pages), 'assets': assets, 'assetCount': len(assets)}


def write_inventory(project: Path, output: Path) -> Path:
    project = Path(project).resolve()
    output = Path(output).resolve()
    require_e_output(str(output))
    if output.is_relative_to(project):
        raise ValueError('output must be outside the source project')
    if not output.is_relative_to(WORKSPACE_ROOT):
        raise ValueError('output must be inside the E: workspace')
    if output.exists():
        raise ValueError('output must be a new directory')
    data = inspect_project(project)
    output.mkdir(parents=True, exist_ok=False)
    target = output / 'source-inventory.json'
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    return target
