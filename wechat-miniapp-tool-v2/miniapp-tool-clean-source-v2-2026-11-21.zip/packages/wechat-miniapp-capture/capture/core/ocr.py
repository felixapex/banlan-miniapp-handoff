"""Local OCR for screenshots whose Android accessibility tree is empty."""

import os
import json
from pathlib import Path
import subprocess


class ScreenshotOcr:
    def __init__(self):
        os.environ.setdefault("OMP_NUM_THREADS", "2")
        try:
            from rapidocr import RapidOCR
        except ImportError as error:
            raise RuntimeError("Screenshot OCR is unavailable; use the E: ocr-venv Python or pass --no-ocr") from error
        self.engine = RapidOCR()

    def recognize(self, image_bytes):
        result = self.engine(image_bytes)
        if result.boxes is None or result.txts is None:
            return []
        words = []
        for points, text, score in zip(result.boxes, result.txts, result.scores):
            if not text or score < 0.45:
                continue
            xs = [int(point[0]) for point in points]
            ys = [int(point[1]) for point in points]
            words.append({
                "text": text.strip(),
                "score": round(float(score), 4),
                "bounds": [min(xs), min(ys), max(xs), max(ys)],
                "center": [(min(xs) + max(xs)) // 2, (min(ys) + max(ys)) // 2],
            })
        return words

    def detect_icons(self, image_bytes, words):
        detector = Path(__file__).with_name("icon_candidates.mjs")
        boxes = [{"bounds": word["bounds"]} for word in words[:200]
                 if isinstance(word.get("bounds"), list) and len(word["bounds"]) == 4]
        process = subprocess.run(["node", str(detector), json.dumps(boxes)],
                                 input=image_bytes, capture_output=True, timeout=15, check=True)
        return json.loads(process.stdout)
