"""Evidence-first traversal of visible Android miniapp viewports.

This module does not open WeChat. The CLI owns the account pause and device gate.
"""

import hashlib
import json
from pathlib import Path
import subprocess
import time

from capture.platforms.android import SKIP_WORDS, parse_nodes
from capture.core.config import require_e_output


PNG = b"\x89PNG\r\n\x1a\n"


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _attempt_evidence_ok(item):
    responses = item.get("responses") or []
    before, after = item.get("before") or {}, item.get("after") or {}
    if (item.get("branchComplete") is not True or item.get("responseCapture") != "available" or
            not responses or any(response.get("status") != "verified" for response in responses) or
            before.get("fingerprint") == after.get("fingerprint")):
        return False
    if item.get("status") == "changed_page":
        return (item.get("restored") or {}).get("fingerprint") == before.get("fingerprint")
    return item.get("status") == "overlay_dismissed"


def _controls(nodes, words, width, height, icons=()):
    controls = []

    def add(label, x, y, source, confidence=None, shape=None, region=None):
        label = str(label).strip()
        if (not label and source == "ocr") or not (0 <= x < width and 0 <= y < height):
            return
        blocked = any(word in label.lower() for word in SKIP_WORDS)
        uncertain = (not label or (source == "ocr" and (confidence is None or confidence < 0.85 or len(label) > 30)) or
                     (source == "visual-icon" and (confidence is None or confidence < 0.9 or region == "top-left")))
        if source == "visual-icon" and confidence is not None and confidence >= .9 and region != "top-left":
            uncertain = False
        status = "blocked" if blocked else "unverified" if uncertain else "eligible"
        for existing in controls:
            if abs(x - existing["x"]) < 20 and abs(y - existing["y"]) < 20:
                if source == "ocr" and existing["source"] == "accessibility" and not existing["label"]:
                    existing.update({"label": label, "confidence": confidence, "status": status,
                                     "reason": "sensitive_action" if blocked else "uncertain_visual_text" if uncertain else None})
                return
        controls.append({"label": label, "x": x, "y": y, "source": source, "shape": shape,
                         "confidence": confidence, "status": status,
                         "reason": "sensitive_action" if blocked else "unverified_icon" if source == "visual-icon" and uncertain else
                                   "unlabeled_control" if not label else "uncertain_visual_text" if uncertain else None})

    for node in nodes:
        if node["clickable"]:
            x, y = node["center"]
            add(node["label"], x, y, "accessibility")
    for word in words:
        x, y = word.get("center", (None, None))
        if isinstance(x, int) and isinstance(y, int):
            add(word.get("text", ""), x, y, "ocr", word.get("score"))
    for icon in icons:
        x, y = icon.get("x"), icon.get("y")
        if isinstance(x, int) and isinstance(y, int):
            add("[icon]", x, y, "visual-icon", icon.get("score"), icon.get("shape"), icon.get("region"))
    controls.sort(key=lambda item: item.get("shape") == "overlay-dismiss-candidate")
    return controls


def explore_visible(device, output, *, max_screens=100, max_depth=5, max_scrolls=20,
                    max_actions=500, ocr=None, observer=None, allow_input_only=False,
                    allow_prepared_run=False):
    """Walk observed controls and scroll positions; return a conservative audit.

    `observer`, when supplied, has checkpoint() and changes(cursor) methods.
    It reports only responses actually captured by a separate local collector.
    """
    output = Path(output).resolve()
    require_e_output(str(output))
    if not (1 <= max_screens <= 500 and 0 <= max_depth <= 10 and
            1 <= max_scrolls <= 50 and 1 <= max_actions <= 5000):
        raise ValueError("exploration limits out of range")
    manifest = output / "capture.json"
    if manifest.is_file():
        state = json.loads(manifest.read_text(encoding="utf-8"))
        if state.get("kind") != "visible-miniapp-capture":
            raise ValueError("Existing output is not a resumable visible capture")
        state.setdefault("historyErrors", []).extend(state["errors"])
        state["errors"] = []
        for scroll in state["scrolls"]:
            if (scroll["status"] == "limit" or scroll.get("responseCapture") == "unavailable" or
                    any(response.get("status") != "verified" for response in scroll.get("responses", []))):
                scroll["superseded"] = True
        state["stopReason"] = None
        state["resumeCount"] = state.get("resumeCount", 0) + 1
    elif output.exists() and any(output.iterdir()):
        names = {item.name for item in output.iterdir()}
        prepared = {"input.json", "share-intake.json", "self-search.bmp", "self-chat-before-send.bmp",
                    "share-code-draft.bmp", "share-code-sent.bmp", "first-screen.bmp",
                    "bridge.log", "collector.log", "responses", "responses.jsonl",
                    "collector-ready.json", "collector-heartbeat.json", "tmp", "pages.json",
                    "pages-observed.jsonl", "commands"}
        if not ((allow_input_only and names == {"input.json"}) or
                (allow_prepared_run and {"input.json", "share-intake.json"} <= names and names <= prepared)):
            raise ValueError("Existing output has no capture manifest; choose a new run directory")
        state = {"kind": "visible-miniapp-capture", "screens": [], "attempts": [], "scrolls": [],
                 "errors": [], "coverage": {}, "observedControlsDone": False,
                 "completeMiniapp": False, "stopReason": None, "resumeCount": 0}
    else:
        state = {"kind": "visible-miniapp-capture", "screens": [], "attempts": [], "scrolls": [],
                 "errors": [], "coverage": {}, "observedControlsDone": False,
                 "completeMiniapp": False, "stopReason": None, "resumeCount": 0}
    output.mkdir(parents=True, exist_ok=True)
    for folder in ("screenshots", "ui"):
        (output / folder).mkdir(exist_ok=True)
    screens = {screen["fingerprint"]: screen for screen in state["screens"]}
    visited = set()
    observation_number = max((int(file.stem) for file in (output / "screenshots").glob("[0-9]*.png")
                              if file.stem.isdigit()), default=0)
    start_attempts = len(state["attempts"])

    def save():
        controls = [control for screen in state["screens"] for control in screen["controls"]]
        eligible = {control["id"] for control in controls if control["status"] == "eligible"}
        attempted = {item["action"]["id"] for item in state["attempts"]}
        completed = {item["action"]["id"] for item in state["attempts"] if _attempt_evidence_ok(item)}
        unresolved = eligible - completed
        historical_response_errors = (
            sum(response.get("status") != "verified" for item in state["attempts"]
                for response in item.get("responses", [])) +
            sum(response.get("status") != "verified" for scroll in state["scrolls"]
                for response in scroll.get("responses", [])))
        state["coverage"] = {
            "observedScreens": len(state["screens"]),
            "eligibleControls": len(eligible),
            "attemptedControls": len(eligible & attempted),
            "unattemptedControls": len(eligible - attempted),
            "incompleteControls": len(unresolved),
            "blockedControls": sum(item["status"] == "blocked" for item in controls),
            "unverifiedControls": sum(item["status"] == "unverified" and item["source"] == "accessibility" for item in controls),
            "unverifiedVisualTexts": sum(item["status"] == "unverified" and item["source"] == "ocr" for item in controls),
            "unverifiedVisualIcons": sum(item["status"] == "unverified" and item["source"] == "visual-icon" for item in controls),
            "iconInspectionErrors": sum(screen.get("iconInspectionStatus") != "completed" for screen in state["screens"]),
            "pageInspectionErrors": sum(bool(screen.get("pageInspectionError")) for screen in state["screens"]),
            "scrollsToEnd": sum(item["status"] == "end" for item in state["scrolls"]),
            "scrollsTruncated": sum(item["status"] == "limit" and not item.get("superseded") for item in state["scrolls"]),
            "responseCaptureUnavailableActions": sum(item["responseCapture"] == "unavailable" and
                                                     item["action"]["id"] in unresolved for item in state["attempts"]),
            "responseCaptureUnavailableScrolls": sum(item.get("responseCapture") == "unavailable" and
                                                     not item.get("superseded") for item in state["scrolls"]),
            "historicalResponseErrors": historical_response_errors,
            "responseErrors": sum(response.get("status") != "verified" for item in state["attempts"]
                                  if item["action"]["id"] in unresolved
                                  for response in item.get("responses", [])) +
                              sum(response.get("status") != "verified" for scroll in state["scrolls"]
                                  if not scroll.get("superseded") for response in scroll.get("responses", [])),
        }
        state["observedControlsDone"] = (
            bool(state["screens"]) and not state["errors"] and
            state["coverage"]["unattemptedControls"] == 0 and
            state["coverage"]["incompleteControls"] == 0 and
            state["coverage"]["blockedControls"] == 0 and
            state["coverage"]["unverifiedControls"] == 0 and
            state["coverage"]["unverifiedVisualTexts"] == 0 and
            state["coverage"]["unverifiedVisualIcons"] == 0 and
            state["coverage"]["iconInspectionErrors"] == 0 and
            state["coverage"]["pageInspectionErrors"] == 0 and
            state["coverage"]["scrollsTruncated"] == 0 and
            state["coverage"]["responseCaptureUnavailableActions"] == 0 and
            state["coverage"]["responseCaptureUnavailableScrolls"] == 0 and
            state["coverage"]["responseErrors"] == 0 and
            state["stopReason"] is None)
        temporary = output / "capture.json.tmp"
        temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(output / "capture.json")

    def observe():
        nonlocal observation_number
        image = device.screenshot()
        if not image.startswith(PNG) or len(image) < 24:
            raise RuntimeError("device screenshot is not a PNG")
        width = int.from_bytes(image[16:20], "big")
        height = int.from_bytes(image[20:24], "big")
        if not (1 <= width <= 10000 and 1 <= height <= 10000):
            raise RuntimeError("invalid screenshot dimensions")
        hierarchy = device.hierarchy()
        nodes = parse_nodes(hierarchy)
        words = ocr.recognize(image) if ocr is not None else []
        icons = []
        icon_error = None
        icon_status = "unavailable"
        if ocr is not None and hasattr(ocr, "detect_icons"):
            try:
                icons = ocr.detect_icons(image, words)
                icon_status = "completed"
            except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
                icon_error = str(error)
                icon_status = "error"
        fingerprint = _sha(image)
        observation_number += 1
        name = f"{observation_number:05d}"
        screenshot = f"screenshots/{name}.png"
        ui = f"ui/{name}.xml"
        (output / screenshot).write_bytes(image)
        (output / ui).write_bytes(hierarchy)
        page_info = {}
        if observer is not None and getattr(observer, "supports_page_inspection", False):
            try:
                page_info["pages"] = observer.command("inspectPages")["pages"]
            except (RuntimeError, TimeoutError, KeyError, TypeError, ValueError) as error:
                page_info["pageInspectionError"] = str(error)
        controls = _controls(nodes, words, width, height, icons)
        for control in controls:
            control["id"] = _sha(f"{fingerprint}:{control['label']}:{control['x']}:{control['y']}".encode())[:20]
        texts = sorted({text.strip() for node in nodes for text in (node["text"], node["description"]) if text.strip()} |
                       {word["text"].strip() for word in words if word.get("text", "").strip()})
        return {"fingerprint": fingerprint, "width": width, "height": height,
                "screenshot": screenshot, "screenshotSha256": _sha(image),
                "ui": ui, "uiSha256": _sha(hierarchy), "texts": texts,
                "controls": controls, "iconInspectionStatus": icon_status, **page_info,
                **({"iconInspectionError": icon_error} if icon_error else {})}

    def add_screen(observation):
        existing = screens.get(observation["fingerprint"])
        if existing is None:
            screens[observation["fingerprint"]] = observation
            state["screens"].append(observation)
            save()
        else:
            known = {item["id"] for item in existing["controls"]}
            additions = [item for item in observation["controls"] if item["id"] not in known]
            refreshed_inspection = (existing.get("iconInspectionStatus") != "completed" and
                                    observation.get("iconInspectionStatus") == "completed")
            refreshed_pages = bool(existing.get("pageInspectionError") and "pages" in observation)
            if additions:
                existing["controls"].extend(additions)
            if refreshed_inspection:
                existing["iconInspectionStatus"] = "completed"
                existing.pop("iconInspectionError", None)
            if refreshed_pages:
                existing["pages"] = observation["pages"]
                existing.pop("pageInspectionError", None)
            if additions or refreshed_inspection or refreshed_pages:
                save()

    def walk(depth, initial):
        current = initial
        no_movement = 0
        for scroll_index in range(max_scrolls + 1):
            if current["fingerprint"] not in visited:
                if current["fingerprint"] not in screens and len(screens) >= max_screens:
                    state["stopReason"] = "screen_limit"
                    save()
                    return False
                visited.add(current["fingerprint"])
                add_screen(current)
                if depth >= max_depth and any(item["status"] == "eligible" for item in current["controls"]):
                    state["stopReason"] = "depth_limit"
                    save()
                    return False
                for action in current["controls"]:
                    if action["status"] != "eligible":
                        continue
                    prior = next((item for item in reversed(state["attempts"])
                                  if item["action"]["id"] == action["id"]), None)
                    if prior and _attempt_evidence_ok(prior):
                        continue
                    if len(state["attempts"]) - start_attempts >= max_actions:
                        state["stopReason"] = "action_limit"
                        save()
                        return False
                    cursor = observer.checkpoint() if observer is not None else None
                    device.tap(action["x"], action["y"])
                    time.sleep(0.8)
                    responses = (getattr(observer, "settle", observer.changes)(cursor)
                                 if observer is not None else [])
                    after = observe()
                    changed = after["fingerprint"] != current["fingerprint"]
                    channel_verified = observer is not None and getattr(observer, "channel_verified", False)
                    evidence_ok = channel_verified and bool(responses) and all(
                        item.get("status") == "verified" for item in responses)
                    failure_reason = (None if evidence_ok else "response_capture_unavailable" if not channel_verified else
                                      "no_response_observed" if not responses else "response_not_verified")
                    if not changed and failure_reason is None:
                        failure_reason = "no_visible_change"
                    result = {"action": action, "before": current, "after": after,
                              "status": "changed_page" if changed else "no_change",
                              "replay": bool(prior), "branchComplete": False,
                              "failureReason": failure_reason,
                              "responseCapture": "available" if channel_verified else "unavailable",
                              "responses": responses,
                              "dataFiles": [item["file"] for item in responses if item.get("status") == "verified" and item.get("kind") == "json"],
                              "imageFiles": [item["file"] for item in responses if item.get("status") == "verified" and item.get("kind") == "image"]}
                    state["attempts"].append(result)
                    save()
                    if changed:
                        if action.get("shape") == "overlay-dismiss-candidate":
                            child_complete = walk(depth, after)
                            result["branchComplete"] = bool(child_complete and evidence_ok)
                            if not child_complete and result["failureReason"] is None:
                                result["failureReason"] = "child_branch_incomplete"
                            result["status"] = "overlay_dismissed"
                            save()
                            return child_complete
                        child_complete = after["fingerprint"] in visited or walk(depth + 1, after)
                        device.back()
                        time.sleep(0.8)
                        restored = observe()
                        result["restored"] = restored
                        if restored["fingerprint"] != current["fingerprint"]:
                            result["status"] = "return_mismatch"
                            result["failureReason"] = "return_mismatch"
                            state["errors"].append({"actionId": action["id"], "error": "return_mismatch"})
                            state["stopReason"] = "return_mismatch"
                            save()
                            return False
                        result["branchComplete"] = bool(child_complete and evidence_ok)
                        if not child_complete and result["failureReason"] is None:
                            result["failureReason"] = "child_branch_incomplete"
                        save()
                        if not child_complete:
                            return False
            if scroll_index == max_scrolls:
                state["scrolls"].append({"from": current["fingerprint"], "status": "limit"})
                state["stopReason"] = state["stopReason"] or "scroll_limit"
                save()
                return False
            if not hasattr(device, "swipe"):
                state["scrolls"].append({"from": current["fingerprint"], "status": "unavailable"})
                state["stopReason"] = state["stopReason"] or "scroll_unavailable"
                save()
                return False
            x = current["width"] // 2
            cursor = observer.checkpoint() if observer is not None else None
            device.swipe(x, int(current["height"] * 0.8), x, int(current["height"] * 0.25), 350)
            time.sleep(0.5)
            scroll_responses = (getattr(observer, "settle", observer.changes)(cursor)
                                if observer is not None else [])
            after_scroll = observe()
            channel_verified = observer is not None and getattr(observer, "channel_verified", False)
            scroll_evidence = {"responses": scroll_responses,
                               "responseCapture": "available" if channel_verified else "unavailable",
                               "dataFiles": [item["file"] for item in scroll_responses
                                             if item.get("status") == "verified" and item.get("kind") == "json"],
                               "imageFiles": [item["file"] for item in scroll_responses
                                              if item.get("status") == "verified" and item.get("kind") == "image"]}
            no_movement = (no_movement + 1 if after_scroll["fingerprint"] == current["fingerprint"] and
                           not scroll_responses else 0)
            if no_movement >= 2:
                state["scrolls"].append({"from": current["fingerprint"], "after": after_scroll,
                                         "status": "end", **scroll_evidence})
                save()
                return True
            state["scrolls"].append({"from": current["fingerprint"], "after": after_scroll,
                                     "status": "unchanged" if no_movement else "moved", **scroll_evidence})
            current = after_scroll
            save()
        return False

    try:
        walk(0, observe())
    except Exception as error:
        state["errors"].append({"error": str(error), "type": type(error).__name__})
        state["stopReason"] = state["stopReason"] or "capture_error"
        save()
        raise
    save()
    return state
