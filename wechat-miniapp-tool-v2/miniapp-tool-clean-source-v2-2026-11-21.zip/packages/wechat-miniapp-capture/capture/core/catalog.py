"""Index captured product details, screenshots, and original image files in a brand run."""

import argparse
import csv
import json
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit


def values(item):
    if isinstance(item, dict):
        for value in item.values():
            yield from values(value)
    elif isinstance(item, list):
        for value in item:
            yield from values(value)
    elif isinstance(item, str):
        yield item


def build(run: Path, list_path: str, detail_path: str, asset_prefix: str) -> dict:
    entries = [json.loads(line) for line in (run / "responses.jsonl").read_text(encoding="utf-8").splitlines()]
    saved = [e for e in entries if e.get("status") == "saved"]
    lists = [e for e in saved if list_path in e.get("url", "")]
    if not lists:
        raise ValueError("product list response was not captured")
    list_entry = lists[-1]
    listing = json.loads((run / list_entry["file"]).read_text(encoding="utf-8"))
    products = listing.get("page", {}).get("list") or listing.get("list")
    if not isinstance(products, list):
        raise ValueError("product list schema is not supported")
    details = {}
    for e in saved:
        if detail_path in e.get("url", ""):
            data = json.loads((run / e["file"]).read_text(encoding="utf-8"))
            good = data.get("good")
            if isinstance(good, dict) and good.get("id"):
                details[str(good["id"])] = (e, good)
    images = {}
    for e in saved:
        if e.get("kind") == "image":
            images.setdefault(unquote(urlsplit(e["url"]).path).lstrip("/"), e["file"])
    asset_manifest_path = run / "referenced-assets" / "manifest.json"
    asset_manifest = json.loads(asset_manifest_path.read_text(encoding="utf-8")) if asset_manifest_path.exists() else {}
    for ref, result in asset_manifest.get("assets", {}).items():
        if result.get("status") == "saved":
            images[ref] = result["file"]
    catalog = []
    for index, item in enumerate(products, 1):
        product_id = str(item.get("id", ""))
        detail = details.get(product_id)
        good = detail[1] if detail else {}
        refs = sorted({s for s in values(good) if s.startswith(asset_prefix) and len(s) <= 500
                       and s.lower().endswith((".jpg", ".jpeg", ".png", ".webp", ".gif"))})
        assets = [{"source": ref, "file": images.get(ref)} for ref in refs]
        screenshot = f"product-detail-{index}.bmp"
        catalog.append({
            "id": product_id,
            "title": good.get("title") or item.get("title"),
            "price": good.get("price", item.get("price")),
            "listImage": item.get("file_url"),
            "screenshot": screenshot if (run / screenshot).is_file() else None,
            "fullDetailJson": detail[0]["file"] if detail else None,
            "imageReferences": len(refs),
            "imagesSaved": sum(a["file"] is not None for a in assets),
            "images": assets,
        })
    result = {
        "source": {"list": list_entry["file"], "detailPath": detail_path},
        "productCount": len(catalog),
        "detailCount": sum(bool(p["fullDetailJson"]) for p in catalog),
        "screenshotCount": sum(bool(p["screenshot"]) for p in catalog),
        "productImageReferences": sum(p["imageReferences"] for p in catalog),
        "productImagesSaved": sum(p["imagesSaved"] for p in catalog),
        "allSavedResponses": len(saved),
        "allSavedImages": sum(e.get("kind") == "image" for e in saved),
        "allSavedBytes": sum((run / e["file"]).stat().st_size for e in saved),
        "products": catalog,
    }
    (run / "product-catalog.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def build_full(run: Path, asset_prefix: str) -> dict:
    source = json.loads((run / "catalog" / "all-products.json").read_text(encoding="utf-8"))
    detail_index = {str(entry["id"]): entry for entry in json.loads((run / "catalog" / "detail-index.json").read_text(encoding="utf-8"))}
    screenshot_index = {str(entry["id"]): entry for line in (run / "screenshots" / "products" / "manifest.jsonl").read_text(encoding="utf-8").splitlines()
                        if line and (entry := json.loads(line)).get("status") == "saved"}
    traffic = [json.loads(line) for line in (run / "responses.jsonl").read_text(encoding="utf-8").splitlines()]
    image_files = {unquote(urlsplit(entry["url"]).path).lstrip("/"): entry["file"] for entry in traffic
                   if entry.get("kind") == "image" and entry.get("status") == "saved"}
    asset_manifest = json.loads((run / "referenced-assets" / "manifest.json").read_text(encoding="utf-8"))
    asset_host = urlsplit(asset_manifest["assetBase"]).hostname
    if not asset_host:
        raise ValueError("asset host missing from manifest")
    for ref, result in asset_manifest["assets"].items():
        if result.get("status") == "saved":
            image_files[unquote(urlsplit(ref).path).lstrip("/")] = result["file"]
    absolute_image = re.compile(r"https://" + re.escape(asset_host) + r"/[^,\"'<>()\s\\]+?\.(?:jpg|jpeg|png|webp|gif)", re.I)
    absolute_video = re.compile(r"https://" + re.escape(asset_host) + r"/[^,\"'<>()\s\\]+?\.(?:mp4|mov|webm)", re.I)
    products = []
    text_rows = []
    unique_images = set()
    for listed in source["products"]:
        pid = str(listed["id"])
        detail = detail_index.get(pid, {})
        good = json.loads((run / detail["file"]).read_text(encoding="utf-8")).get("good", {}) if detail.get("file") else {}
        images = set()
        videos = set()
        for value in values(good):
            if value.startswith(asset_prefix) and len(value) <= 500 and value.lower().endswith((".jpg", ".jpeg", ".png", ".webp", ".gif")):
                images.add(value)
            images.update(absolute_image.findall(value))
            videos.update(absolute_video.findall(value))
        assets = []
        for ref in sorted(images):
            key = unquote(urlsplit(ref).path).lstrip("/")
            unique_images.add(key)
            assets.append({"urlOrPath": ref, "localFile": image_files.get(key)})
        screenshot = screenshot_index.get(pid, {}).get("file")
        products.append({"id": pid, "title": good.get("title") or listed.get("title"),
                         "price": good.get("price", listed.get("price")), "fullDetailJson": detail.get("file"),
                         "screenshot": screenshot, "images": assets, "videoUrls": sorted(videos)})
        text_rows.append({"id": pid, "title": good.get("title") or listed.get("title"),
                          "price": good.get("price", listed.get("price")),
                          "characteristic": good.get("characteristic"), "rich_title": good.get("rich_title"),
                          "plan_content": good.get("plan_content"), "parameter_json": good.get("parameter_json"),
                          "specs_json": json.dumps(good.get("specs"), ensure_ascii=False),
                          "fullDetailJson": detail.get("file")})
    result = {
        "brand": run.parent.parent.name, "appId": json.loads((run / "collector-ready.json").read_text(encoding="utf-8"))["appId"],
        "categories": len(source["categories"]), "products": len(products),
        "detailsSaved": sum(bool(p["fullDetailJson"]) for p in products),
        "screenshotsSaved": sum(bool(p["screenshot"]) and (run / p["screenshot"]).is_file() for p in products),
        "uniqueProductImageReferences": len(unique_images),
        "uniqueProductImagesSaved": sum(key in image_files and (run / image_files[key]).is_file() for key in unique_images),
        "allObservedImageResponses": sum(e.get("kind") == "image" and e.get("status") == "saved" for e in traffic),
        "productEntries": products,
    }
    (run / "catalog" / "full-product-catalog.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with (run / "catalog" / "product-text.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["id", "title", "price", "characteristic", "rich_title",
                                                   "plan_content", "parameter_json", "specs_json", "fullDetailJson"])
        writer.writeheader()
        writer.writerows(text_rows)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--list-path")
    parser.add_argument("--detail-path")
    parser.add_argument("--asset-prefix", required=True)
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()
    run = Path(args.run).resolve()
    if run.drive.upper() != "E:" or run.parent.name != "runs" or not (run / "input.json").is_file():
        raise SystemExit("expected one existing E-drive brand run")
    if args.full:
        result = build_full(run, args.asset_prefix)
        print(json.dumps({k: v for k, v in result.items() if k != "productEntries"}, ensure_ascii=False))
        return
    if not args.list_path or not args.detail_path:
        parser.error("--list-path and --detail-path are required unless --full is used")
    result = build(run, args.list_path, args.detail_path, args.asset_prefix)
    print(json.dumps({k: v for k, v in result.items() if k not in ("source", "products")}))


if __name__ == "__main__":
    main()
