from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
import json
import re
from html.parser import HTMLParser
from urllib.parse import urlsplit


class _Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag in {"br", "p", "div", "li"}:
            self.parts.append("\n")

    def handle_data(self, data):
        self.parts.append(data)


def plain_text(value):
    parser = _Text()
    parser.feed(value or "")
    return "\n".join(line.strip() for line in "".join(parser.parts).splitlines() if line.strip())


def write_detail_text(records, output: Path):
    output.mkdir(parents=True, exist_ok=True)
    rows = {}
    for record in records:
        if not str(record.get("path", "")).startswith("/v2/ec/products/"):
            continue
        data = record.get("data") or {}
        product = data.get("product") or {}
        ec = data.get("ec") or {}
        if not isinstance(product, dict) or not product.get("id"):
            continue
        properties = ((product.get("category") or {}).get("properties") or [])
        rows[str(product["id"])] = {
            "商品ID": str(product["id"]),
            "商城商品ID": str(ec.get("id") or ""),
            "商品名称": str(product.get("name") or ""),
            "商品介绍": plain_text(product.get("intro") or ""),
            "商品描述": plain_text(product.get("description") or ""),
            "分类属性": json.dumps(properties, ensure_ascii=False),
            "分享文案": str(ec.get("shareDescription") or ""),
            "原始JSON": str(record.get("source") or ""),
        }
    destination = output / "detail-text.csv"
    columns = ["商品ID", "商城商品ID", "商品名称", "商品介绍", "商品描述", "分类属性", "分享文案", "原始JSON"]
    with destination.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows.values())
    return destination


def collect_products(records: list[dict]) -> dict:
    products = {}
    for record in records:
        data = record.get("data") or {}
        if not isinstance(data, dict):
            continue
        entries = [data] if isinstance(data.get("product"), dict) else []
        entries.extend(item for item in (data.get("items") or []) if isinstance(item, dict))
        for entry in entries:
            product = entry.get("product")
            if not isinstance(product, dict) or not product.get("id"):
                continue
            product_id = str(product["id"])
            pictures = []
            for picture in product.get("pictures") or []:
                url = picture.get("url") if isinstance(picture, dict) else None
                if isinstance(url, str) and urlsplit(url).hostname == "statics.maiscrm.com" and url.startswith("https://"):
                    pictures.append(url)
            candidate = {"id": product_id, "name": str(product.get("name") or ""), "pictures": pictures, "source": record.get("source", "")}
            if product_id not in products or len(pictures) > len(products[product_id]["pictures"]):
                products[product_id] = candidate
    return products


def export_images(products: dict, output: Path, fetch) -> dict:
    image_dir = output / "images"
    image_dir.mkdir(parents=True, exist_ok=True)
    result = {"productCount": len(products), "products": []}
    jobs = []
    for product in products.values():
        item = {"id": product["id"], "name": product["name"], "source": product.get("source", ""), "images": []}
        safe_id = re.sub(r"[^A-Za-z0-9_-]", "_", product["id"])
        for index, url in enumerate(product["pictures"], 1):
            extension = Path(urlsplit(url).path).suffix.lower()
            if extension not in {".jpg", ".jpeg", ".png", ".webp", ".gif"}:
                extension = ".img"
            url_key = hashlib.sha256(url.encode("utf-8")).hexdigest()[:12]
            destination = image_dir / f"{safe_id}-{index:02d}-{url_key}{extension}"
            image = {"url": url, "file": str(destination)}
            item["images"].append(image)
            jobs.append((image, url, destination))
        result["products"].append(item)
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = [pool.submit(_download, url, destination, fetch) for _, url, destination in jobs]
        for (image, _, _), future in zip(jobs, futures):
            image.update(future.result())
    output.mkdir(parents=True, exist_ok=True)
    (output / "manifest.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def _download(url: str, destination: Path, fetch) -> dict:
    part = destination.with_suffix(destination.suffix + ".part")
    try:
        if destination.is_file() and destination.stat().st_size:
            data = destination.read_bytes()
            status = "existing"
        else:
            data = fetch(url)
            if not data or len(data) > 100 * 1024 * 1024:
                raise ValueError("empty or oversized image")
            part.write_bytes(data)
            part.replace(destination)
            status = "downloaded"
        return {"status": status, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    except Exception as error:
        return {"status": "error", "error": str(error)}
    finally:
        part.unlink(missing_ok=True)


def write_catalog(manifest: dict, output: Path) -> Path:
    output.mkdir(parents=True, exist_ok=True)
    destination = output / "catalog.csv"
    columns = ["商品ID", "商品名称", "原图数量", "首张原图URL", "首张原图本地路径", "来源JSON"]
    with destination.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        for product in manifest["products"]:
            first = product["images"][0] if product["images"] else {}
            writer.writerow({"商品ID": product["id"], "商品名称": product["name"], "原图数量": len(product["images"]), "首张原图URL": first.get("url", ""), "首张原图本地路径": first.get("file", ""), "来源JSON": product.get("source", "")})
    return destination


def export_assets(urls: list[str], output: Path, fetch) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    accepted = {}
    for raw in urls:
        try:
            parsed = urlsplit(raw.strip())
        except ValueError:
            continue
        extension = Path(parsed.path).suffix.lower()
        if parsed.scheme != "https" or parsed.hostname != "statics.maiscrm.com" or extension not in {".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg"}:
            continue
        url = f"https://statics.maiscrm.com{parsed.path}"
        accepted[url] = extension
    result = {"observedUrls": len(set(urls)), "assets": []}
    jobs = []
    for url, extension in sorted(accepted.items()):
        digest = hashlib.sha256(url.encode("utf-8")).hexdigest()[:20]
        destination = output / f"{digest}{extension}"
        asset = {"url": url, "file": str(destination)}
        result["assets"].append(asset)
        jobs.append((asset, url, destination))
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = [pool.submit(_download, url, destination, fetch) for _, url, destination in jobs]
        for (asset, _, _), future in zip(jobs, futures):
            asset.update(future.result())
    (output / "manifest.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
