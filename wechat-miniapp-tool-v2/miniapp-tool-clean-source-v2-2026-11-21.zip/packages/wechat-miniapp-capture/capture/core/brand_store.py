"""Allocate isolated E: output directories for individual miniapp brands."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import unicodedata
from uuid import uuid4

from capture.core.config import require_e_output


RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}
RUN_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$")


def _slug(name):
    if not isinstance(name, str) or not name.strip() or len(name) > 80 or any(ch in name for ch in "/\\:"):
        raise ValueError("unsafe brand name")
    normalized = unicodedata.normalize("NFKC", name).strip().casefold()
    if any(ord(ch) < 32 for ch in normalized):
        raise ValueError("unsafe brand name")
    result = re.sub(r"-+", "-", "".join(ch if ch.isalnum() else "-" for ch in normalized)).strip("-")[:48].strip("-")
    if not result:
        raise ValueError("unsafe brand name")
    if result in RESERVED:
        result = "brand-" + result
    return result


def _existing_brand(root, name):
    wanted = unicodedata.normalize("NFKC", name).strip().casefold()
    matches = []
    for folder in root.iterdir() if root.exists() else ():
        metadata = folder / "brand.json"
        if not folder.is_dir() or not metadata.is_file():
            continue
        record = json.loads(metadata.read_text(encoding="utf-8"))
        names = [record.get("displayName", ""), *(record.get("aliases") or [])]
        if any(unicodedata.normalize("NFKC", value).strip().casefold() == wanted for value in names if isinstance(value, str)):
            matches.append(folder)
    if len(matches) > 1:
        raise RuntimeError("brand alias matches multiple directories")
    return matches[0] if matches else None


def create_brand_run(brands_root, brand_name, link, run_id=None):
    root = Path(brands_root).resolve()
    require_e_output(str(root))
    slug = _slug(brand_name)
    if not isinstance(link, str) or not link or len(link) > 2048:
        raise ValueError("invalid miniapp link")
    run_id = run_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid4().hex[:8]
    if not RUN_ID.fullmatch(run_id) or run_id.casefold() in RESERVED:
        raise ValueError("invalid run ID")
    root.mkdir(parents=True, exist_ok=True)
    brand = _existing_brand(root, brand_name)
    if brand is None:
        brand = root / slug
        metadata = brand / "brand.json"
        if brand.exists() and metadata.exists():
            suffix = hashlib.sha256(brand_name.encode("utf-8")).hexdigest()[:8]
            brand = root / f"{slug}-{suffix}"
            metadata = brand / "brand.json"
        brand.mkdir(parents=True, exist_ok=True)
        if not metadata.exists():
            metadata.write_text(json.dumps({"displayName": brand_name, "aliases": [brand_name]}, ensure_ascii=False, indent=2), encoding="utf-8")
    run = brand / "runs" / run_id
    run.mkdir(parents=True, exist_ok=False)
    (run / "input.json").write_text(json.dumps({"brand": brand.name, "link": link, "createdAtUtc": datetime.now(timezone.utc).isoformat()}, ensure_ascii=False, indent=2), encoding="utf-8")
    return run
