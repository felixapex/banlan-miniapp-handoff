param(
    [Parameter(Mandatory = $true)][string]$Run
)

$runPath = [IO.Path]::GetFullPath($Run)
if (-not $runPath.StartsWith('E:\', [StringComparison]::OrdinalIgnoreCase) -or
    -not (Test-Path -LiteralPath (Join-Path $runPath 'input.json'))) {
    throw 'Expected an existing E-drive brand run.'
}
Add-Type -AssemblyName System.Drawing

function Get-ColorSample([string]$path, [System.Drawing.Rectangle]$sourceRect) {
    $source = [System.Drawing.Bitmap]::new($path)
    $small = [System.Drawing.Bitmap]::new(20, 10)
    $graphics = [System.Drawing.Graphics]::FromImage($small)
    try {
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.DrawImage($source, [System.Drawing.Rectangle]::new(0, 0, 20, 10),
            $sourceRect, [System.Drawing.GraphicsUnit]::Pixel)
        $colors = [int[]]::new(600)
        $index = 0
        for ($y = 0; $y -lt 10; $y++) {
            for ($x = 0; $x -lt 20; $x++) {
                $pixel = $small.GetPixel($x, $y)
                $colors[$index++] = $pixel.R
                $colors[$index++] = $pixel.G
                $colors[$index++] = $pixel.B
            }
        }
        return ,$colors
    } finally {
        $graphics.Dispose()
        $small.Dispose()
        $source.Dispose()
    }
}

function Color-Distance([int[]]$a, [int[]]$b) {
    if ($a.Length -ne $b.Length) { throw 'Sample sizes differ.' }
    $sum = 0
    for ($i = 0; $i -lt $a.Length; $i++) {
        $sum += [Math]::Abs($a[$i] - $b[$i])
    }
    return [Math]::Round($sum / $a.Length, 3)
}

$cards = (Get-Content -LiteralPath (Join-Path $runPath 'news-cards.json') -Raw -Encoding utf8 | ConvertFrom-Json).cards
$articles = (Get-Content -LiteralPath (Join-Path $runPath 'news/all-articles.json') -Raw -Encoding utf8 | ConvertFrom-Json).articles
$assets = Get-Content -LiteralPath (Join-Path $runPath 'news/covers/manifest.jsonl') -Encoding utf8 | ForEach-Object { $_ | ConvertFrom-Json }
$coverById = @{}
foreach ($asset in $assets) {
    if ($asset.status -notin @('saved', 'reused')) { continue }
    $file = [IO.Path]::GetFullPath($asset.file)
    if (-not (Test-Path -LiteralPath $file)) { throw "Missing cover file: $file" }
    $bitmap = [System.Drawing.Bitmap]::new($file)
    try { $rectangle = [System.Drawing.Rectangle]::new(0, 0, $bitmap.Width, $bitmap.Height) }
    finally { $bitmap.Dispose() }
    $sample = Get-ColorSample $file $rectangle
    foreach ($articleId in $asset.articleIds) {
        $coverById[[string]$articleId] = $sample
    }
}
if ($coverById.Count -ne $articles.Count) { throw 'Not every news article has a cover sample.' }

$listDir = Join-Path $runPath 'screenshots/long-pages/brand-news-list-fine'
$matches = @()
for ($order = 0; $order -lt $cards.Count; $order++) {
    $card = $cards[$order]
    $file = Join-Path $listDir ('screen-{0:d3}.bmp' -f [int]$card.listScreen)
    $sample = Get-ColorSample $file ([System.Drawing.Rectangle]::new(19, [int]$card.imageTop, 392, 210))
    $ranked = foreach ($article in $articles) {
        [pscustomobject]@{ id = [string]$article.id; score = Color-Distance $sample $coverById[[string]$article.id] }
    }
    $best = $ranked | Sort-Object score | Select-Object -First 2
    $matches += [pscustomobject]@{ card = $order; articleId = $best[0].id; score = $best[0].score;
        secondId = $best[1].id; secondScore = $best[1].score; margin = [Math]::Round($best[1].score - $best[0].score, 3) }
}
$matchedIds = [Collections.Generic.HashSet[string]]::new()
foreach ($match in $matches) { [void]$matchedIds.Add($match.articleId) }
$missing = @($articles | Where-Object { -not $matchedIds.Contains([string]$_.id) } | ForEach-Object {
    [pscustomobject]@{ id = [string]$_.id; title = $_.title; file_url = $_.file_url }
})
$result = [pscustomobject]@{ articles = $articles.Count; cards = $cards.Count; uniqueMatched = $matchedIds.Count;
    ambiguous = @($matches | Where-Object { $_.margin -lt 5 }).Count; matches = $matches; missing = $missing }
$destination = Join-Path $runPath 'news/cover-matches.json'
[IO.File]::WriteAllText($destination, ($result | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
[pscustomobject]@{ articles = $result.articles; cards = $result.cards; uniqueMatched = $result.uniqueMatched;
    ambiguous = $result.ambiguous; missing = $result.missing.Count; output = $destination } | ConvertTo-Json -Compress
