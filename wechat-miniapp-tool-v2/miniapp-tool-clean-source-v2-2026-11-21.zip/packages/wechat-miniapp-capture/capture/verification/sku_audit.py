"""Enumerate and verify every SKU selection without driving WeChat UI."""

import argparse
from copy import deepcopy
import hashlib
import itertools
import json
from pathlib import Path
import time
from urllib import request


DEFAULT_PRICE_URL = "https://mpapi.banlan.com.cn/xcx/custom/good/getPrice"


def _leaf_choices(nodes, path=()):
    choices = []
    for node in nodes or []:
        children = node.get("children") or []
        if children:
            choices.extend(_leaf_choices(children, path + (node.get("name", ""),)))
            continue
        choices.append({
            "id": str(node["id"]),
            "name": node.get("name", ""),
            "description": node.get("tex_description", ""),
            "fileUrl": node.get("file_url"),
            "mobileFileUrl": node.get("m_file_url"),
            "path": [part for part in path if part],
            "source": deepcopy(node),
        })
    return choices


def build_selection_plan(detail):
    good = detail.get("good") or {}
    specs = good.get("specs") or []
    if not specs or not isinstance(specs[0], dict):
        raise ValueError("product has no SKU specification tree")
    roots = specs[0].get("children") or []
    groups = []
    for index, group in enumerate(roots):
        choices = _leaf_choices(group.get("children") or [])
        if not choices:
            raise ValueError(f"SKU group has no selectable buttons: {group.get('name', index)}")
        groups.append({
            "index": index,
            "id": str(group["id"]),
            "name": group.get("name", ""),
            "choices": choices,
        })

    combinations = []
    for combination_index, selected in enumerate(
        itertools.product(*(group["choices"] for group in groups)), start=1
    ):
        ids = [choice["id"] for choice in selected]
        clicks = []
        before = []
        for group, choice in zip(groups, selected):
            after = before + [choice["id"]]
            clicks.append({
                "groupIndex": group["index"],
                "groupId": group["id"],
                "groupName": group["name"],
                "buttonId": choice["id"],
                "buttonName": choice["name"],
                "beforeIds": before,
                "afterIds": after,
            })
            before = after
        combinations.append({
            "index": combination_index,
            "ids": ids,
            "selections": [
                {
                    "groupId": group["id"],
                    "groupName": group["name"],
                    "button": choice,
                }
                for group, choice in zip(groups, selected)
            ],
            "clicks": clicks,
        })

    return {
        "product": {"id": str(good.get("id", "")), "title": good.get("title", "")},
        "groups": groups,
        "buttonCount": sum(len(group["choices"]) for group in groups),
        "combinationCount": len(combinations),
        "selectionEventCount": sum(len(item["clicks"]) for item in combinations),
        "combinations": combinations,
    }


def request_price(gid, ids, url=DEFAULT_PRICE_URL, timeout=20, attempts=3):
    payload = json.dumps({"gid": gid, "ids": ids}, ensure_ascii=False).encode("utf-8")
    last_error = None
    for attempt in range(attempts):
        try:
            req = request.Request(
                url,
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with request.urlopen(req, timeout=timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except Exception as error:
            last_error = error
            if attempt + 1 < attempts:
                time.sleep(0.5 * (attempt + 1))
    raise last_error


def _verify_button_assets(groups, catalog, asset_root):
    asset_root = Path(asset_root).resolve()
    lookup = {}
    for product in (catalog or {}).get("productEntries", []):
        for image in product.get("images", []):
            source = image.get("urlOrPath")
            if source:
                lookup.setdefault(source, image)
    verified = set()
    missing = []
    for group in groups:
        for choice in group["choices"]:
            button_id = choice["id"]
            source = choice.get("fileUrl")
            entry = lookup.get(source)
            evidence = {"source": source, "status": "missing"}
            if entry and entry.get("localFile"):
                path = (asset_root / entry["localFile"]).resolve()
                try:
                    path.relative_to(asset_root)
                    body = path.read_bytes()
                    digest = hashlib.sha256(body).hexdigest()
                    expected = entry.get("sha256")
                    if body and (not expected or digest == expected):
                        evidence = {
                            "source": source,
                            "status": "verified",
                            "localFile": str(path),
                            "bytes": len(body),
                            "sha256": digest,
                        }
                        verified.add(button_id)
                except (OSError, ValueError):
                    pass
            if button_id not in verified:
                missing.append(button_id)
            choice["asset"] = evidence
    return sorted(verified), sorted(set(missing))


def _load_verified_cached_response(path, gid, ids):
    try:
        response = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(response, dict) or str(response.get("code")) != "0":
            return None
        price_obj = response.get("priceObj")
        if not isinstance(price_obj, dict) or price_obj.get("price") is None:
            return None
        if str(price_obj.get("gid")) != str(gid):
            return None
        cached_ids = price_obj.get("ids")
        if isinstance(cached_ids, str):
            cached_ids = json.loads(cached_ids)
        if not isinstance(cached_ids, list):
            return None
        if [str(item) for item in cached_ids] != [str(item) for item in ids]:
            return None
        return response
    except (OSError, UnicodeError, json.JSONDecodeError, TypeError):
        return None


def run_selection_audit(detail, output, resolver=request_price, *, asset_catalog=None,
                        asset_root=None, require_assets=False, reuse_responses=True,
                        request_delay=0, sleeper=time.sleep):
    output = Path(output).resolve()
    response_dir = output / "responses"
    response_dir.mkdir(parents=True, exist_ok=True)
    plan = build_selection_plan(detail)
    verified_assets = []
    missing_assets = []
    if asset_catalog is not None and asset_root is not None:
        verified_assets, missing_assets = _verify_button_assets(
            plan["groups"], asset_catalog, asset_root
        )
    gid = plan["product"]["id"]
    results = []
    covered = set()
    cached_responses = 0
    network_responses = 0

    for combination in plan["combinations"]:
        result = deepcopy(combination)
        for click in result["clicks"]:
            covered.add(click["buttonId"])
        response_file = response_dir / (
            f'{combination["index"]:04d}-' + "-".join(combination["ids"]) + ".json"
        )
        try:
            response = None
            response_source = "network"
            if reuse_responses and response_file.is_file():
                response = _load_verified_cached_response(
                    response_file, gid, combination["ids"]
                )
            if response is not None:
                cached_responses += 1
                response_source = "cache"
            else:
                if request_delay and network_responses:
                    sleeper(request_delay)
                response = resolver(gid, combination["ids"])
                network_responses += 1
                response_file.write_text(
                    json.dumps(response, ensure_ascii=False, indent=2), encoding="utf-8"
                )
            price_obj = response.get("priceObj") if isinstance(response, dict) else None
            price = price_obj.get("price") if isinstance(price_obj, dict) else None
            if str(response.get("code")) != "0" or price is None:
                result.update({
                    "status": "failed",
                    "error": response.get("message", "missing price response"),
                })
            else:
                result.update({
                    "status": "valid" if float(price) > 0 else "invalid",
                    "price": price,
                    "rebate": price_obj.get("rebate"),
                    "priceId": price_obj.get("price_id"),
                    "image": price_obj.get("file_url"),
                })
            result["responseSource"] = response_source
        except Exception as error:
            response_file.write_text(
                json.dumps({"error": str(error)}, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            result.update({"status": "failed", "error": str(error)})
            result["responseSource"] = "network"
        result["responseFile"] = str(response_file)
        results.append(result)

    valid = sum(item["status"] == "valid" for item in results)
    invalid = sum(item["status"] == "invalid" for item in results)
    failed = sum(item["status"] == "failed" for item in results)
    expected_buttons = sorted(
        choice["id"] for group in plan["groups"] for choice in group["choices"]
    )
    summary = {
        "discoveredButtons": plan["buttonCount"],
        "coveredButtonIds": sorted(covered),
        "allButtonsSelected": sorted(covered) == expected_buttons,
        "theoreticalCombinations": plan["combinationCount"],
        "attemptedCombinations": len(results),
        "validCombinations": valid,
        "invalidCombinations": invalid,
        "failedCombinations": failed,
        "executedSelectionEvents": sum(len(item["clicks"]) for item in results),
        "allCombinationsResolved": failed == 0 and len(results) == plan["combinationCount"],
        "buttonsWithVerifiedImage": len(verified_assets),
        "verifiedButtonImageIds": verified_assets,
        "missingButtonImageIds": missing_assets,
        "allButtonImagesVerified": len(verified_assets) == plan["buttonCount"],
        "cachedResponses": cached_responses,
        "networkResponses": network_responses,
    }
    report = {
        "method": "offline SKU selection replay plus read-only price API; no WeChat UI or account automation",
        "product": plan["product"],
        "groups": plan["groups"],
        "summary": summary,
        "complete": (
            summary["allButtonsSelected"]
            and summary["allCombinationsResolved"]
            and (not require_assets or summary["allButtonImagesVerified"])
        ),
        "combinations": results,
    }
    (output / "sku-selection-audit.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--detail", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--price-url", default=DEFAULT_PRICE_URL)
    parser.add_argument("--asset-catalog")
    parser.add_argument("--asset-root")
    parser.add_argument("--require-assets", action="store_true")
    parser.add_argument("--request-delay", type=float, default=0)
    args = parser.parse_args()
    detail = json.loads(Path(args.detail).read_text(encoding="utf-8"))
    asset_catalog = None
    if args.asset_catalog:
        asset_catalog = json.loads(Path(args.asset_catalog).read_text(encoding="utf-8"))
    report = run_selection_audit(
        detail,
        Path(args.output),
        lambda gid, ids: request_price(gid, ids, url=args.price_url),
        asset_catalog=asset_catalog,
        asset_root=args.asset_root,
        require_assets=args.require_assets,
        request_delay=args.request_delay,
    )
    print(json.dumps({
        "output": str(Path(args.output).resolve()),
        "product": report["product"],
        "summary": report["summary"],
        "complete": report["complete"],
    }, ensure_ascii=False))
    raise SystemExit(0 if report["complete"] else 2)


if __name__ == "__main__":
    main()
