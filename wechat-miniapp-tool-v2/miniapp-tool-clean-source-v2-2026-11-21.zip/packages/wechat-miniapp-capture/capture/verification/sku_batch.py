"""Select and verify a fixed batch of Banlan products."""

import argparse
from collections import OrderedDict
from copy import deepcopy
import html
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import time

from capture.verification.sku_audit import (
    _load_verified_cached_response,
    build_selection_plan,
    request_price,
    run_selection_audit,
)


PROMOTIONAL_CATEGORIES = {"2026新品"}


def _primary_category(memberships):
    memberships = list(memberships or [])
    if not memberships:
        return {"id": None, "parent": "未分类", "name": "未分类"}
    for category in memberships:
        if category.get("name") not in PROMOTIONAL_CATEGORIES:
            selected = deepcopy(category)
            selected["name"] = selected.get("name") or selected.get("parent") or "未分类"
            return selected
    selected = deepcopy(memberships[0])
    selected["name"] = selected.get("name") or selected.get("parent") or "未分类"
    return selected


def select_products(product_entries, category_memberships, count, required_ids=()):
    """Return exactly ``count`` unique products using deterministic category rotation."""
    if count < 1:
        raise ValueError("count must be positive")
    entries = [deepcopy(entry) for entry in product_entries]
    by_id = OrderedDict((str(entry["id"]), entry) for entry in entries)
    if len(by_id) < count:
        raise ValueError(f"only {len(by_id)} unique products are available for {count} slots")

    selected = []
    selected_ids = set()

    def add(product_id):
        product_id = str(product_id)
        if product_id in selected_ids:
            return
        if product_id not in by_id:
            raise ValueError(f"required product is unavailable: {product_id}")
        entry = deepcopy(by_id[product_id])
        entry["primaryCategory"] = _primary_category(category_memberships.get(product_id))
        selected.append(entry)
        selected_ids.add(product_id)

    for product_id in required_ids:
        add(product_id)

    buckets = {}
    for product_id, entry in by_id.items():
        if product_id in selected_ids:
            continue
        category = _primary_category(category_memberships.get(product_id))
        key = (str(category.get("parent", "")), str(category.get("name", "")), str(category.get("id", "")))
        buckets.setdefault(key, []).append(entry)

    ordered = OrderedDict((key, buckets[key]) for key in sorted(buckets))
    while len(selected) < count:
        progressed = False
        for bucket in ordered.values():
            while bucket and str(bucket[0]["id"]) in selected_ids:
                bucket.pop(0)
            if not bucket:
                continue
            add(bucket.pop(0)["id"])
            progressed = True
            if len(selected) == count:
                break
        if not progressed:
            raise ValueError(f"could select only {len(selected)} of {count} products")
    return selected


def _audit_file(root, relative_path, label):
    evidence = {"label": label, "relativePath": relative_path}
    if not relative_path:
        return evidence, {"kind": "missing", "label": label, "path": relative_path}
    path = (root / relative_path).resolve()
    try:
        path.relative_to(root)
    except ValueError:
        return evidence, {"kind": "outside-root", "label": label, "path": relative_path}
    if not path.is_file():
        return evidence, {"kind": "missing", "label": label, "path": relative_path}
    body = path.read_bytes()
    if not body:
        return evidence, {"kind": "empty", "label": label, "path": relative_path}
    evidence.update({
        "path": str(path),
        "bytes": len(body),
        "sha256": hashlib.sha256(body).hexdigest(),
    })
    return evidence, None


def audit_local_product(entry, run_root):
    """Hash-check one catalog entry and every local file it declares."""
    root = Path(run_root).resolve()
    missing = []
    detail, problem = _audit_file(root, entry.get("fullDetailJson"), "detail")
    if problem:
        missing.append(problem)
    else:
        try:
            payload = json.loads(Path(detail["path"]).read_text(encoding="utf-8"))
            good = payload.get("good") if isinstance(payload, dict) else None
            if not isinstance(good, dict) or str(good.get("id")) != str(entry.get("id")):
                missing.append({
                    "kind": "invalid-detail",
                    "label": "detail",
                    "path": entry.get("fullDetailJson"),
                })
        except (OSError, UnicodeError, json.JSONDecodeError):
            missing.append({
                "kind": "invalid-json",
                "label": "detail",
                "path": entry.get("fullDetailJson"),
            })

    screenshot, problem = _audit_file(root, entry.get("screenshot"), "screenshot")
    if problem:
        missing.append(problem)

    images = []
    for index, image in enumerate(entry.get("images") or []):
        evidence, problem = _audit_file(root, image.get("localFile"), f"image:{index}")
        evidence["source"] = image.get("urlOrPath")
        images.append(evidence)
        if problem:
            problem["source"] = image.get("urlOrPath")
            missing.append(problem)

    return {
        "productId": str(entry.get("id", "")),
        "title": entry.get("title", ""),
        "detail": detail,
        "screenshot": screenshot,
        "images": images,
        "declaredImageCount": len(images),
        "missing": missing,
        "complete": not missing,
    }


def load_category_memberships(all_products, run_root):
    root = Path(run_root).resolve()
    memberships = {}
    for category in all_products.get("categories") or []:
        relative_path = category.get("file")
        if not relative_path:
            continue
        path = (root / relative_path).resolve()
        try:
            path.relative_to(root)
        except ValueError as error:
            raise ValueError(f"category file is outside run root: {relative_path}") from error
        payload = json.loads(path.read_text(encoding="utf-8"))
        page = payload.get("page") if isinstance(payload, dict) else None
        products = page.get("list") if isinstance(page, dict) else None
        category_ref = {
            "id": category.get("id"),
            "parent": category.get("parent", ""),
            "name": category.get("name", ""),
        }
        for product in products or []:
            product_id = str(product.get("id", ""))
            if product_id:
                values = memberships.setdefault(product_id, [])
                if category_ref not in values:
                    values.append(category_ref)
    return memberships


def _basic_product_files_available(entry, root):
    relative_paths = [entry.get("fullDetailJson"), entry.get("screenshot")]
    relative_paths.extend(image.get("localFile") for image in entry.get("images") or [])
    for relative_path in relative_paths:
        if not relative_path:
            return False
        path = (root / relative_path).resolve()
        try:
            path.relative_to(root)
        except ValueError:
            return False
        if not path.is_file() or path.stat().st_size == 0:
            return False
    return True


def prepare_products(full_catalog, all_products, run_root, *, count=50,
                     max_combinations=120, required_ids=()):
    """Choose a complete, category-balanced batch with bounded SKU expansion."""
    root = Path(run_root).resolve()
    required = {str(product_id) for product_id in required_ids}
    memberships = load_category_memberships(all_products, root)
    candidates = []
    for source_entry in full_catalog.get("productEntries") or []:
        entry = deepcopy(source_entry)
        product_id = str(entry.get("id", ""))
        if not product_id or not _basic_product_files_available(entry, root):
            continue
        detail_path = (root / entry["fullDetailJson"]).resolve()
        try:
            detail = json.loads(detail_path.read_text(encoding="utf-8"))
            plan = build_selection_plan(detail)
        except (OSError, UnicodeError, json.JSONDecodeError, KeyError, TypeError, ValueError):
            continue
        if plan["product"]["id"] != product_id:
            continue
        entry.update({
            "skuGroupCount": len(plan["groups"]),
            "buttonCount": plan["buttonCount"],
            "combinationCount": plan["combinationCount"],
        })
        if plan["combinationCount"] <= max_combinations or product_id in required:
            candidates.append(entry)
    candidates.sort(key=lambda item: (
        item["combinationCount"], item["buttonCount"], item.get("title", ""), item["id"]
    ))
    return select_products(
        candidates, memberships, count, required_ids=list(required_ids)
    )


def _write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _ensure_copy(source, target, expected_sha256):
    source = Path(source)
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file() and _sha256(target) == expected_sha256:
        return
    if target.exists():
        target.unlink()
    shutil.copy2(source, target)
    if _sha256(target) != expected_sha256:
        raise OSError(f"copied file hash mismatch: {target}")


def _ensure_link_or_copy(source, target, expected_sha256):
    source = Path(source)
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file() and _sha256(target) == expected_sha256:
        return
    if target.exists():
        target.unlink()
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)
    if _sha256(target) != expected_sha256:
        raise OSError(f"materialized file hash mismatch: {target}")


def _decode_json_field(value):
    if isinstance(value, (list, dict)):
        return value
    if not value:
        return []
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return value


def _strip_html(value):
    value = re.sub(r"<[^>]+>", "\n", value or "")
    value = html.unescape(value)
    return "\n".join(line.strip() for line in value.splitlines() if line.strip())


def _extract_product_text(detail):
    good = detail.get("good") or {}
    renovation = _decode_json_field(good.get("renovation_json"))
    detail_html = []
    if isinstance(renovation, list):
        for section in renovation:
            config = section.get("config") if isinstance(section, dict) else None
            content = config.get("content") if isinstance(config, dict) else None
            if content:
                detail_html.append(content)
    return {
        "id": str(good.get("id", "")),
        "title": good.get("title", ""),
        "richTitle": good.get("rich_title", ""),
        "price": good.get("price"),
        "unit": good.get("unit"),
        "delivery": good.get("plan_content", ""),
        "characteristic": good.get("characteristic", ""),
        "parameters": _decode_json_field(good.get("parameter_json")),
        "questions": _decode_json_field(good.get("problem_json")),
        "detailHtml": "\n".join(detail_html),
        "detailText": _strip_html("\n".join(detail_html)),
        "specifications": good.get("specs") or [],
    }


def _materialize_product(entry, local_audit, detail, product_dir, output_root):
    product_dir = Path(product_dir).resolve()
    output_root = Path(output_root).resolve()
    data_dir = product_dir / "data"
    detail_target = data_dir / "detail.json"
    screenshot_source = Path(local_audit["screenshot"]["path"])
    screenshot_target = data_dir / ("screenshot" + (screenshot_source.suffix or ".bin"))
    _ensure_copy(local_audit["detail"]["path"], detail_target, local_audit["detail"]["sha256"])
    _ensure_copy(screenshot_source, screenshot_target, local_audit["screenshot"]["sha256"])

    text_json = data_dir / "product-text.json"
    text_txt = data_dir / "product-text.txt"
    text = _extract_product_text(detail)
    _write_json(text_json, text)
    text_txt.write_text(
        "\n".join([
            f"商品：{text['title']}",
            f"英文名：{text['richTitle']}",
            f"价格：{text['price']}",
            f"交付：{text['delivery']}",
            "",
            text["detailText"],
        ]),
        encoding="utf-8",
    )

    images = []
    for index, evidence in enumerate(local_audit["images"], start=1):
        source = Path(evidence["path"])
        suffix = source.suffix.lower() or ".bin"
        central = output_root / "assets" / f"{evidence['sha256']}{suffix}"
        _ensure_copy(source, central, evidence["sha256"])
        target = data_dir / "images" / f"{index:04d}-{evidence['sha256'][:12]}{suffix}"
        _ensure_link_or_copy(central, target, evidence["sha256"])
        images.append({
            "source": evidence.get("source"),
            "file": str(target),
            "bytes": evidence["bytes"],
            "sha256": evidence["sha256"],
        })

    manifest = {
        "productId": str(entry.get("id", "")),
        "title": entry.get("title", ""),
        "detail": {
            "file": str(detail_target),
            "bytes": local_audit["detail"]["bytes"],
            "sha256": local_audit["detail"]["sha256"],
        },
        "screenshot": {
            "file": str(screenshot_target),
            "bytes": local_audit["screenshot"]["bytes"],
            "sha256": local_audit["screenshot"]["sha256"],
        },
        "productTextJson": str(text_json),
        "productTextTxt": str(text_txt),
        "textExports": [
            {"file": str(text_json), "bytes": text_json.stat().st_size, "sha256": _sha256(text_json)},
            {"file": str(text_txt), "bytes": text_txt.stat().st_size, "sha256": _sha256(text_txt)},
        ],
        "images": images,
    }
    manifest_path = product_dir / "materials-manifest.json"
    _write_json(manifest_path, manifest)
    return manifest_path


def run_batch(selected_products, run_root, output_root, asset_catalog, *,
              resolver, request_delay=0, sleeper=time.sleep):
    """Run resumable SKU audits for a fixed product list."""
    run_root = Path(run_root).resolve()
    output_root = Path(output_root).resolve()
    products_root = output_root / "products"
    products_root.mkdir(parents=True, exist_ok=True)
    _write_json(output_root / "selection.json", {
        "count": len(selected_products),
        "products": [{
            "index": index,
            "id": str(entry.get("id", "")),
            "title": entry.get("title", ""),
            "primaryCategory": entry.get("primaryCategory"),
            "skuGroupCount": entry.get("skuGroupCount"),
            "buttonCount": entry.get("buttonCount"),
            "combinationCount": entry.get("combinationCount"),
            "declaredImageCount": len(entry.get("images") or []),
        } for index, entry in enumerate(selected_products, start=1)],
    })

    network_call_count = 0

    def limited_resolver(gid, ids):
        nonlocal network_call_count
        if request_delay and network_call_count:
            sleeper(request_delay)
        response = resolver(gid, ids)
        network_call_count += 1
        return response

    results = []
    for index, entry in enumerate(selected_products, start=1):
        product_id = str(entry.get("id", ""))
        product_dir = products_root / f"{index:02d}-{product_id}"
        product_dir.mkdir(parents=True, exist_ok=True)
        local_audit = audit_local_product(entry, run_root)
        local_audit_file = product_dir / "local-audit.json"
        _write_json(local_audit_file, local_audit)
        result = {
            "index": index,
            "id": product_id,
            "title": entry.get("title", ""),
            "primaryCategory": entry.get("primaryCategory"),
            "localAuditFile": str(local_audit_file),
            "localComplete": local_audit["complete"],
            "skuStatus": "not-run",
            "buttonCount": 0,
            "combinationCount": 0,
            "failures": [],
            "complete": False,
        }
        if not local_audit["complete"]:
            result["failures"].append("local-files-incomplete")
            results.append(result)
            continue

        detail = json.loads(Path(local_audit["detail"]["path"]).read_text(encoding="utf-8"))
        try:
            manifest_path = _materialize_product(
                entry, local_audit, detail, product_dir, output_root
            )
            result["materialsManifestFile"] = str(manifest_path)
        except (OSError, ValueError, KeyError, TypeError) as error:
            result["failures"].append("materialization-failed")
            result["materializationError"] = str(error)
            results.append(result)
            continue
        good = detail.get("good") or {}
        specs = good.get("specs") or []
        if not specs:
            result.update({
                "skuStatus": "no-specification",
                "complete": True,
            })
            results.append(result)
            continue

        sku_dir = product_dir / "sku"
        try:
            sku_report = run_selection_audit(
                detail,
                sku_dir,
                limited_resolver,
                asset_catalog=asset_catalog,
                asset_root=run_root,
                require_assets=True,
                reuse_responses=True,
            )
            result.update({
                "skuStatus": "complete" if sku_report["complete"] else "incomplete",
                "skuAuditFile": str(sku_dir / "sku-selection-audit.json"),
                "buttonCount": sku_report["summary"]["discoveredButtons"],
                "combinationCount": sku_report["summary"]["theoreticalCombinations"],
                "cachedResponses": sku_report["summary"]["cachedResponses"],
                "networkResponses": sku_report["summary"]["networkResponses"],
                "complete": sku_report["complete"],
            })
            if not sku_report["complete"]:
                result["failures"].append("sku-audit-incomplete")
        except (KeyError, TypeError, ValueError) as error:
            result.update({"skuStatus": "invalid-specification", "skuError": str(error)})
            result["failures"].append("invalid-specification")
        results.append(result)

    summary = {
        "selectedProducts": len(selected_products),
        "completedProducts": sum(item["complete"] for item in results),
        "failedProducts": sum(not item["complete"] for item in results),
        "discoveredButtons": sum(item["buttonCount"] for item in results),
        "theoreticalCombinations": sum(item["combinationCount"] for item in results),
        "cachedResponses": sum(item.get("cachedResponses", 0) for item in results),
        "networkResponses": sum(item.get("networkResponses", 0) for item in results),
    }
    report = {
        "method": "saved Banlan product data plus offline SKU enumeration and anonymous read-only price API",
        "summary": summary,
        "complete": bool(results) and summary["completedProducts"] == len(selected_products),
        "products": results,
    }
    _write_json(output_root / "batch-audit.json", report)
    return report


def _path_in_root(path, root):
    path = Path(path).resolve()
    path.relative_to(root)
    return path


def verify_batch(output_root, *, expected_count=50, write_report=True):
    """Independently re-read a batch and reject missing, changed, or mismatched evidence."""
    root = Path(output_root).resolve()
    errors = []
    try:
        selection = json.loads((root / "selection.json").read_text(encoding="utf-8"))
        batch = json.loads((root / "batch-audit.json").read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        result = {"complete": False, "expectedProducts": expected_count, "verifiedProducts": 0,
                  "errors": [f"cannot read batch control files: {error}"]}
        if write_report:
            _write_json(root / "verification.json", result)
        return result

    selected = selection.get("products") or []
    products = batch.get("products") or []
    selected_ids = [str(item.get("id", "")) for item in selected]
    selected_by_id = {str(item.get("id", "")): item for item in selected}
    product_ids = [str(item.get("id", "")) for item in products]
    if len(selected) != expected_count:
        errors.append(f"expected {expected_count} selected products, found {len(selected)}")
    if len(set(selected_ids)) != len(selected_ids):
        errors.append("selection contains duplicate product ids")
    if selected_ids != product_ids:
        errors.append("selection and batch product order differ")
    if not batch.get("complete"):
        errors.append("batch-audit.json is not complete")

    verified_products = 0
    for product in products:
        product_id = str(product.get("id", ""))
        product_errors = []
        if not product.get("complete"):
            product_errors.append("product report is incomplete")
        try:
            manifest_path = _path_in_root(product["materialsManifestFile"], root)
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            if str(manifest.get("productId")) != product_id:
                product_errors.append("materials manifest product id mismatch")
            declared_images = selected_by_id.get(product_id, {}).get("declaredImageCount")
            actual_images = len(manifest.get("images") or [])
            if declared_images != actual_images:
                product_errors.append(
                    f"declared {declared_images} images but materials manifest has {actual_images}"
                )
            evidence_items = [manifest.get("detail") or {}, manifest.get("screenshot") or {}]
            evidence_items.extend(manifest.get("images") or [])
            evidence_items.extend(manifest.get("textExports") or [])
            for evidence in evidence_items:
                path = _path_in_root(evidence.get("file"), root)
                if not path.is_file() or path.stat().st_size == 0:
                    product_errors.append(f"missing or empty material: {path}")
                    continue
                digest = _sha256(path)
                if digest != evidence.get("sha256"):
                    product_errors.append(f"sha256 mismatch: {path}")
            if len(manifest.get("textExports") or []) != 2:
                product_errors.append("text export hash evidence is incomplete")
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
            product_errors.append(f"materials verification error: {error}")
            manifest = None

        if product.get("skuStatus") == "no-specification":
            pass
        elif product.get("skuStatus") != "complete":
            product_errors.append(f"SKU status is {product.get('skuStatus')}")
        else:
            try:
                sku_path = _path_in_root(product["skuAuditFile"], root)
                sku = json.loads(sku_path.read_text(encoding="utf-8"))
                if not sku.get("complete") or str(sku.get("product", {}).get("id")) != product_id:
                    product_errors.append("SKU report is incomplete or belongs to another product")
                detail_path = _path_in_root(manifest["detail"]["file"], root)
                detail = json.loads(detail_path.read_text(encoding="utf-8"))
                expected_plan = build_selection_plan(detail)
                expected = {tuple(item["ids"]) for item in expected_plan["combinations"]}
                actual = {tuple(item.get("ids") or []) for item in sku.get("combinations") or []}
                if expected != actual:
                    product_errors.append("SKU combination set differs from specification tree")
                expected_buttons = {
                    choice["id"] for group in expected_plan["groups"] for choice in group["choices"]
                }
                covered = set(sku.get("summary", {}).get("coveredButtonIds") or [])
                if expected_buttons != covered:
                    product_errors.append("SKU button coverage differs from specification tree")
                for combination in sku.get("combinations") or []:
                    if combination.get("status") not in {"valid", "invalid"}:
                        product_errors.append(f"failed SKU combination: {combination.get('ids')}")
                        continue
                    response_path = _path_in_root(combination.get("responseFile"), root)
                    if _load_verified_cached_response(
                        response_path, product_id, combination.get("ids") or []
                    ) is None:
                        product_errors.append(f"invalid SKU response: {response_path}")
            except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
                product_errors.append(f"SKU verification error: {error}")

        if product_errors:
            errors.extend(f"{product_id}: {message}" for message in product_errors)
        else:
            verified_products += 1

    result = {
        "complete": not errors and verified_products == expected_count,
        "expectedProducts": expected_count,
        "verifiedProducts": verified_products,
        "errors": errors,
    }
    if write_report:
        _write_json(root / "verification.json", result)
    return result


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    run = subparsers.add_parser("run")
    run.add_argument("--run-root", required=True)
    run.add_argument("--catalog", required=True)
    run.add_argument("--all-products", required=True)
    run.add_argument("--output", required=True)
    run.add_argument("--count", type=int, default=50)
    run.add_argument("--max-combinations", type=int, default=120)
    run.add_argument("--required-id", action="append", default=[])
    run.add_argument("--request-delay", type=float, default=0.15)
    verify = subparsers.add_parser("verify")
    verify.add_argument("--output", required=True)
    verify.add_argument("--count", type=int, default=50)
    args = parser.parse_args()

    output = Path(args.output).resolve()
    if output.drive.upper() != "E:":
        raise SystemExit("output must be on E drive")
    if args.command == "verify":
        result = verify_batch(output, expected_count=args.count)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        raise SystemExit(0 if result["complete"] else 2)

    run_root = Path(args.run_root).resolve()
    catalog = json.loads(Path(args.catalog).read_text(encoding="utf-8"))
    all_products = json.loads(Path(args.all_products).read_text(encoding="utf-8"))
    selected = prepare_products(
        catalog, all_products, run_root,
        count=args.count,
        max_combinations=args.max_combinations,
        required_ids=args.required_id,
    )
    report = run_batch(
        selected, run_root, output, catalog,
        resolver=request_price,
        request_delay=args.request_delay,
    )
    verification = verify_batch(output, expected_count=args.count)
    print(json.dumps({"batch": report["summary"], "verification": verification},
                     ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["complete"] and verification["complete"] else 2)


if __name__ == "__main__":
    main()
