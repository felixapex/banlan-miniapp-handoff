"""Verify a captured brand run without opening apps or using the network."""

import argparse
import hashlib
import json
from pathlib import Path
import struct


def digest(path):
    sha = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            sha.update(block)
    return sha.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    if run.drive.upper() != "E:" or run.parent.name != "runs" or not (run / "input.json").is_file():
        raise SystemExit("expected one existing E-drive brand run")
    catalog = json.loads((run / "catalog" / "full-product-catalog.json").read_text(encoding="utf-8"))
    manifest = json.loads((run / "referenced-assets" / "manifest.json").read_text(encoding="utf-8"))
    entries = [json.loads(line) for line in (run / "responses.jsonl").read_text(encoding="utf-8").splitlines()]
    errors = []
    checked_hashes = {}
    def verify_hash(relative, expected):
        target = run / relative
        if not target.is_file():
            errors.append(f"missing {relative}")
            return
        actual = checked_hashes.setdefault(relative, digest(target))
        if actual != expected:
            errors.append(f"hash mismatch {relative}")

    for entry in entries:
        if entry.get("status") == "saved":
            verify_hash(entry["file"], entry["sha256"])
    for asset in manifest["assets"].values():
        if asset.get("status") == "saved":
            verify_hash(asset["file"], asset["sha256"])
        elif asset.get("status") == "error":
            errors.append(f"asset download failed {asset['url']}")
    screenshots = set()
    screenshot_hashes = set()
    product_ids = set()
    for product in catalog["productEntries"]:
        pid = product["id"]
        if pid in product_ids:
            errors.append(f"duplicate product {pid}")
        product_ids.add(pid)
        detail_file = product.get("fullDetailJson")
        if not detail_file or not (run / detail_file).is_file():
            errors.append(f"detail missing {pid}")
        else:
            detail = json.loads((run / detail_file).read_text(encoding="utf-8"))
            if str(detail.get("good", {}).get("id")) != pid:
                errors.append(f"detail ID mismatch {pid}")
        screenshot = product.get("screenshot")
        if not screenshot or not (run / screenshot).is_file():
            errors.append(f"screenshot missing {pid}")
        else:
            screenshots.add(screenshot)
            with (run / screenshot).open("rb") as image:
                header = image.read(26)
            if len(header) < 26 or header[:2] != b"BM" or struct.unpack_from("<ii", header, 18) != (430, 788):
                errors.append(f"invalid screenshot {pid}")
            screenshot_hashes.add(digest(run / screenshot))
        for image in product["images"]:
            if not image.get("localFile") or not (run / image["localFile"]).is_file():
                errors.append(f"product image missing {pid}: {image['urlOrPath']}")
    if len(screenshot_hashes) != len(screenshots):
        errors.append("duplicate screenshot pixels")
    report = {
        "brand": catalog["brand"], "products": len(product_ids), "screenshots": len(screenshots),
        "distinctScreenshots": len(screenshot_hashes), "productImageReferences": catalog["uniqueProductImageReferences"],
        "productImagesSaved": catalog["uniqueProductImagesSaved"],
        "networkResponseFilesVerified": sum(e.get("status") == "saved" for e in entries),
        "referencedAssetFilesVerified": sum(a.get("status") == "saved" for a in manifest["assets"].values()),
        "errors": errors,
    }
    (run / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v if k != "errors" else len(v) for k, v in report.items()}, ensure_ascii=False))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
