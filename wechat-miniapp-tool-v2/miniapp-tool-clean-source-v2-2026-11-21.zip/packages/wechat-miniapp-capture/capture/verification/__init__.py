"""Capture reconciliation, retry, and completeness verification."""
