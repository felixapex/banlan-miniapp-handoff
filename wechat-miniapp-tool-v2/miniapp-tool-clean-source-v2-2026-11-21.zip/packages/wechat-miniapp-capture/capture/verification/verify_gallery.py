"""Rehash saved gallery originals and account for every public image reference."""

import argparse
import hashlib
import json
from pathlib import Path

from capture.adapters.banlan.banlan_gallery_assets import references
from capture.core.config import require_e_output


def file_sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def verify(deep):
    posts = json.loads((deep / "gallery" / "all-posts.json").read_text(encoding="utf-8"))["posts"]
    refs, unresolved, inferred = references(posts)
    ledger = deep / "gallery" / "assets" / "manifest.jsonl"
    latest = {}
    for line in ledger.read_text(encoding="utf-8").splitlines():
        entry = json.loads(line)
        if entry["url"] in refs:
            latest[entry["url"]] = entry
    failures = []
    saved = set()
    brand_dir = deep.parent.parent.resolve()
    for url in sorted(refs):
        entry = latest.get(url)
        if not entry or entry.get("status") not in ("saved", "reused"):
            failures.append({"url": url, "reason": entry.get("error", "not downloaded") if entry else "missing ledger entry"})
            continue
        path = Path(entry["file"]).resolve()
        if not path.is_relative_to(brand_dir) or not path.is_file():
            failures.append({"url": url, "reason": "file missing or outside brand directory"})
            continue
        if path.stat().st_size != entry["bytes"] or file_sha256(path) != entry["sha256"]:
            failures.append({"url": url, "reason": "size or SHA-256 mismatch"})
            continue
        saved.add(url)
    by_post = {str(post["id"]): {"referenced": 0, "saved": 0} for post in posts}
    for url, post_ids in refs.items():
        for post_id in post_ids:
            by_post[post_id]["referenced"] += 1
            by_post[post_id]["saved"] += url in saved
    for entry in unresolved:
        by_post[entry["postId"]]["referenced"] += 1
    report = {"posts": len(posts), "imageUrls": len(refs), "filesVerified": len(saved),
              "failures": failures, "unresolvedReferences": unresolved,
              "inferredRelativeReferences": inferred,
              "postsWithAllImages": sum(p["referenced"] == p["saved"] for p in by_post.values()),
              "postsWithAtLeastOneImage": sum(p["saved"] > 0 for p in by_post.values()),
              "postCoverage": by_post}
    (deep / "gallery" / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--deep-run", required=True)
    args = parser.parse_args()
    deep = Path(args.deep_run).resolve()
    require_e_output(str(deep))
    if deep.parent.name != "runs" or not (deep / "input.json").is_file():
        parser.error("expected an existing E-drive brand run")
    result = verify(deep)
    print(json.dumps({k: len(v) if k in ("failures", "unresolvedReferences", "inferredRelativeReferences") else v
                      for k, v in result.items() if k != "postCoverage"}))


if __name__ == "__main__":
    main()
