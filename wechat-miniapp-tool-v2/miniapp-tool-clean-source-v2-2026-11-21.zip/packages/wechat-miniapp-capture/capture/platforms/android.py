"""Bounded Android WeChat UI capture using only an explicitly selected ADB device."""

import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import time
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET

from capture.core.config import require_e_output


WECHAT_PACKAGE = "com.tencent.mm"
SHARE_LINK = re.compile(r"^#小程序://([^/\r\n]{1,100})/([A-Za-z0-9_-]{6,200})$")
BOUNDS = re.compile(r"^\[(\d+),(\d+)\]\[(\d+),(\d+)\]$")
SKIP_WORDS = ("支付", "购买", "下单", "提交", "删除", "退出", "注销", "授权", "登录", "注册", "发送", "拨打", "电话", "转账", "聊天", "客服", "领取", "订单", "个人", "账号", "钱包", "地址", "隐私", "pay", "buy", "delete", "submit", "send", "login")


def classify_link(value):
    if not isinstance(value, str) or len(value) > 2048:
        raise ValueError("invalid miniapp link")
    if SHARE_LINK.fullmatch(value):
        return "wechat_share_text"
    url = urlsplit(value)
    if url.scheme == "weixin" and url.netloc == "dl" and url.path == "/business/" and url.query.startswith("t="):
        return "wechat_scheme"
    if url.scheme == "https" and url.hostname in {"wxaur.cn", "wxaurl.cn"} and url.path.strip("/"):
        return "wechat_url_link"
    raise ValueError("unsupported link; use #小程序://, WeChat URL Scheme, or WeChat URL Link")


def parse_nodes(xml_bytes):
    root = ET.fromstring(xml_bytes)
    nodes = []
    for element in root.iter("node"):
        attrs = element.attrib
        match = BOUNDS.fullmatch(attrs.get("bounds", ""))
        if not match:
            continue
        x1, y1, x2, y2 = map(int, match.groups())
        if x2 <= x1 or y2 <= y1:
            continue
        label = (attrs.get("text", "") or attrs.get("content-desc", "")).strip()
        if not label and attrs.get("clickable") == "true":
            label = " ".join(dict.fromkeys(
                value.strip()
                for child in element.iter("node")
                for value in (child.get("text", ""), child.get("content-desc", ""))
                if value.strip()
            ))
        nodes.append({
            "text": attrs.get("text", ""),
            "description": attrs.get("content-desc", ""),
            "label": label,
            "resourceId": attrs.get("resource-id", ""),
            "class": attrs.get("class", ""),
            "clickable": attrs.get("clickable") == "true",
            "bounds": [x1, y1, x2, y2],
            "center": [(x1 + x2) // 2, (y1 + y2) // 2],
        })
    return nodes


def safe_actions(nodes, width, height):
    actions = []
    seen = set()
    for node in nodes:
        if not node["clickable"]:
            continue
        label = node["label"].lower()
        x, y = node["center"]
        if not label or any(word in label for word in SKIP_WORDS) or not (0 <= x < width and 0 <= y < height):
            continue
        if node["bounds"][2] - node["bounds"][0] > width * 0.95 and node["bounds"][3] - node["bounds"][1] > height * 0.7:
            continue
        key = (label, x, y)
        if key not in seen:
            actions.append({"label": label, "x": x, "y": y})
            seen.add(key)
    return actions


class AndroidDevice:
    def __init__(self, adb="adb", serial=None):
        self.adb = str(adb)
        self.serial = serial

    def _run(self, *args, timeout=15):
        command = [self.adb]
        if self.serial:
            command.extend(["-s", self.serial])
        command.extend(args)
        home = Path(__file__).resolve().parents[2] / ".adb-home"
        temp = home / "tmp"
        temp.mkdir(parents=True, exist_ok=True)
        environment = os.environ.copy()
        environment.update({
            "HOME": str(home), "USERPROFILE": str(home),
            "HOMEDRIVE": home.drive, "HOMEPATH": str(home)[len(home.drive):],
            "TMP": str(temp), "TEMP": str(temp),
            "ANDROID_USER_HOME": str(home / ".android"),
            "ANDROID_SDK_HOME": str(home),
        })
        result = subprocess.run(command, capture_output=True, timeout=timeout, check=False, env=environment)
        if result.returncode:
            raise RuntimeError(f"ADB command failed ({result.returncode}): {result.stderr.decode('utf-8', 'replace')[:250]}")
        return result.stdout

    def select(self):
        output = self._run("devices", "-l", timeout=10).decode("utf-8", "replace")
        devices = []
        for line in output.splitlines()[1:]:
            fields = line.split()
            if len(fields) >= 2 and fields[1] == "device":
                devices.append(fields[0])
        if self.serial:
            if self.serial not in devices:
                raise RuntimeError(f"ADB device {self.serial} is not authorized and online")
        elif len(devices) == 1:
            self.serial = devices[0]
        else:
            raise RuntimeError(f"Expected one authorized Android device; found {len(devices)}")
        if not self._run("shell", "pm", "path", WECHAT_PACKAGE, timeout=10).strip():
            raise RuntimeError("WeChat is not installed on the selected Android device")
        return self.serial

    def screenshot(self):
        data = self._run("exec-out", "screencap", "-p", timeout=20)
        if not data.startswith(b"\x89PNG\r\n\x1a\n"):
            raise RuntimeError("ADB screenshot is not a PNG")
        return data

    def hierarchy(self):
        remote = "/sdcard/Download/codex-miniapp-window.xml"
        for options in ((), ("--compressed",)):
            self._run("shell", "rm", "-f", remote, timeout=10)
            try:
                self._run("shell", "uiautomator", "dump", *options, remote, timeout=25)
                data = self._run("exec-out", "cat", remote, timeout=10)
                if b"<hierarchy" in data:
                    return data
            except (RuntimeError, subprocess.TimeoutExpired):
                pass
            finally:
                self._run("shell", "rm", "-f", remote, timeout=10)
        raise RuntimeError("Android UI hierarchy is unavailable after normal and compressed dumps")

    def tap(self, x, y):
        self._run("shell", "input", "tap", str(x), str(y), timeout=10)

    def swipe(self, x1, y1, x2, y2, duration_ms=350):
        self._run("shell", "input", "swipe", str(x1), str(y1), str(x2), str(y2), str(duration_ms), timeout=15)

    def back(self):
        self._run("shell", "input", "keyevent", "KEYCODE_BACK", timeout=10)

    def open_link(self, link):
        kind = classify_link(link)
        if kind == "wechat_share_text":
            command = f"am start -a android.intent.action.SEND -t text/plain --es android.intent.extra.TEXT {shlex.quote(link)} -p {WECHAT_PACKAGE}"
        else:
            command = f"am start -a android.intent.action.VIEW -d {shlex.quote(link)} -p {WECHAT_PACKAGE}"
        self._run("shell", command, timeout=20)
        return kind

    def input_ascii(self, value):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", value):
            raise ValueError("ADB text input accepts only a safe ASCII search term")
        self._run("shell", "input", "text", value, timeout=10)


def _find_exact(nodes, label):
    matches = [node for node in nodes if node["text"].strip() == label or node["description"].strip() == label]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one '{label}' control; found {len(matches)}")
    return matches[0]["center"]


def _find_exact_clickable(nodes, label):
    matches = [node for node in nodes if node["clickable"] and node["label"] == label]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one clickable '{label}' control; found {len(matches)}")
    return matches[0]["center"]


def open_shared_text_in_self_chat(device, link):
    """Use only WeChat's own File Transfer Assistant; never select a contact."""
    if classify_link(link) != "wechat_share_text":
        raise ValueError("not a WeChat share-text link")
    device.open_link(link)
    time.sleep(1)
    nodes = parse_nodes(device.hierarchy())
    if any("账号状态异常" in node["text"] for node in nodes):
        raise RuntimeError("WeChat ended the emulator login; stop capture until the account session is restored")
    if any(node["text"].strip() == "分享方式" for node in nodes):
        x, y = _find_exact(nodes, "发送给朋友")
        device.tap(x, y)
        time.sleep(0.4)
        nodes = parse_nodes(device.hierarchy())
        x, y = _find_exact(nodes, "仅此一次")
        device.tap(x, y)
        time.sleep(1)
        nodes = parse_nodes(device.hierarchy())
    elif any(node["text"].strip() == "使用发送给朋友分享" for node in nodes):
        device.tap(*_find_exact(nodes, "仅此一次"))
        time.sleep(1)
        nodes = parse_nodes(device.hierarchy())
    if any(node["text"].strip() == "选择一个聊天" for node in nodes):
        x, y = _find_exact_clickable(nodes, "搜索")
        device.tap(x, y)
        device.input_ascii("filehelper")
        time.sleep(0.8)
        nodes = parse_nodes(device.hierarchy())
        if not any(node["text"].strip() == "微信号: filehelper" for node in nodes):
            raise RuntimeError("File Transfer Assistant ID was not confirmed; message not sent")
    x, y = _find_exact(nodes, "文件传输助手")
    device.tap(x, y)
    time.sleep(1)
    nodes = parse_nodes(device.hierarchy())
    if not any(node["text"].strip() == "文件传输助手" for node in nodes):
        raise RuntimeError("File Transfer Assistant was not confirmed; message not sent")
    if not any(node["text"].strip() == link for node in nodes):
        raise RuntimeError("Exact share text was not confirmed; message not sent")
    x, y = _find_exact(nodes, "发送")
    device.tap(x, y)
    time.sleep(1)
    nodes = parse_nodes(device.hierarchy())
    if any(node["text"].strip() == "已发送" for node in nodes):
        device.tap(*_find_exact(nodes, "留在微信"))
        time.sleep(1)
        nodes = parse_nodes(device.hierarchy())
    candidates = [node for node in nodes if node["text"].strip() == link]
    if len(candidates) != 1:
        raise RuntimeError("Shared miniapp link was not found in self chat")
    device.tap(*candidates[0]["center"])
    time.sleep(0.5)
    nodes = parse_nodes(device.hierarchy())
    if any("即将打开" in node["text"] and "小程序" in node["text"] for node in nodes):
        device.tap(*_find_exact(nodes, "允许"))
        time.sleep(4)


def snapshot(device, output, number, ocr=None):
    output = Path(output)
    require_e_output(str(output.resolve()))
    screen = device.screenshot()
    hierarchy = device.hierarchy()
    nodes = parse_nodes(hierarchy)
    width = int.from_bytes(screen[16:20], "big")
    height = int.from_bytes(screen[20:24], "big")
    actions = safe_actions(nodes, width, height)
    visible_nodes = [node for node in nodes if node["text"].strip() or node["description"].strip()]
    ocr_words = ocr.recognize(screen) if ocr is not None and not actions else []
    mode = "accessibility" if visible_nodes and actions else "ocr" if ocr_words else "screenshot_only"
    eligible = {(action["label"], action["x"], action["y"]) for action in actions}
    controls = []
    for node in nodes:
        if not node["clickable"]:
            continue
        x, y = node["center"]
        label = node["label"].lower()
        controls.append({"label": node["label"], "center": [x, y],
                         "status": "eligible" if (label, x, y) in eligible else "skipped"})
    if not actions:
        controls.extend({"label": word["text"], "center": word["center"],
                         "status": "unverified_visual_text"} for word in ocr_words)
    key = hashlib.sha256(hierarchy if visible_nodes else screen).hexdigest()
    name = f"{number:04d}-{key[:12]}"
    (output / "screenshots").mkdir(parents=True, exist_ok=True)
    (output / "ui").mkdir(parents=True, exist_ok=True)
    (output / "screenshots" / f"{name}.png").write_bytes(screen)
    (output / "ui" / f"{name}.xml").write_bytes(hierarchy)
    texts = sorted({value.strip() for node in nodes for value in (node["text"], node["description"]) if value.strip()} | {word["text"] for word in ocr_words})
    return {"id": name, "fingerprint": key, "screenshot": f"screenshots/{name}.png", "ui": f"ui/{name}.xml", "texts": texts, "ocr": ocr_words, "mode": mode, "controls": controls, "nodes": nodes}


def explore(device, output, max_pages=30, max_depth=3, ocr=None):
    output = Path(output).resolve()
    require_e_output(str(output))
    if not (1 <= max_pages <= 100 and 0 <= max_depth <= 5):
        raise ValueError("exploration limits out of range")
    output.mkdir(parents=True, exist_ok=True)
    state = {"pages": [], "transitions": [], "attempts": [], "coverage": {},
             "complete": False, "stopReason": None}
    seen = set()

    def save():
        controls = [control for page in state["pages"] for control in page["controls"]]
        eligible = sum(control["status"] == "eligible" for control in controls)
        state["coverage"] = {
            "observedPages": len(state["pages"]), "eligibleControls": eligible,
            "attemptedActions": len(state["attempts"]),
            "unattemptedEligibleControls": max(0, eligible - len(state["attempts"])),
            "skippedControls": sum(control["status"] == "skipped" for control in controls),
            "unverifiedVisualTexts": sum(control["status"] == "unverified_visual_text" for control in controls),
        }
        pending = output / "capture.json.tmp"
        pending.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        pending.replace(output / "capture.json")

    def walk(depth, page=None):
        if len(state["pages"]) >= max_pages:
            state["stopReason"] = "page limit"
            return
        if page is None:
            page = snapshot(device, output, len(state["pages"]) + 1, ocr=ocr)
        if page["fingerprint"] in seen:
            return
        seen.add(page["fingerprint"])
        nodes = page.pop("nodes")
        state["pages"].append(page)
        save()
        if depth >= max_depth:
            return
        png = (output / page["screenshot"]).read_bytes()
        width = int.from_bytes(png[16:20], "big")
        height = int.from_bytes(png[20:24], "big")
        actions = safe_actions(nodes, width, height)
        if not actions and page["mode"] != "accessibility":
            state["stopReason"] = "visual page has no accessible click targets; screenshot and OCR saved"
            save()
        for action in actions:
            if len(state["pages"]) >= max_pages:
                state["stopReason"] = "page limit"
                save()
                break
            device.tap(action["x"], action["y"])
            time.sleep(0.8)
            child = snapshot(device, output, len(state["pages"]) + 1, ocr=ocr)
            state["attempts"].append({"from": page["id"], "action": action,
                                      "status": "changed_page" if child["fingerprint"] != page["fingerprint"] else "no_change"})
            if child["fingerprint"] != page["fingerprint"]:
                state["transitions"].append({"from": page["id"], "action": action, "to": child["id"]})
                save()
                if child["fingerprint"] not in seen:
                    walk(depth + 1, child)
                device.back()
                time.sleep(0.8)
                restored = hashlib.sha256(device.hierarchy()).hexdigest()
                if restored != page["fingerprint"]:
                    state["stopReason"] = "navigation did not return to the same page"
                    save()
                    return
        save()

    walk(0)
    return state
