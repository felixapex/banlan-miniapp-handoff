"""Platform-specific device and desktop automation adapters."""
