"""Capture every visible scroll position of one live miniapp page."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import time

import win32api
import win32con
import win32gui

from capture.core.config import require_e_output
from capture.platforms.open_share_code import bmp_region_hash
from capture.platforms.windows_ui import _activate, _capture, _windows


def content_pixels(file, width, height, top, bottom):
    image = file.read_bytes()
    if image[:2] != b"BM" or struct.unpack_from("<ii", image, 18) != (width, height):
        raise ValueError("unexpected screenshot dimensions")
    depth = struct.unpack_from("<H", image, 28)[0]
    if depth != 32:
        raise ValueError("unexpected screenshot depth")
    offset = struct.unpack_from("<I", image, 10)[0]
    stride = width * 4
    # Omit the moving scrollbar and floating buttons near the right edge.
    return b"".join(image[offset + (height - 1 - y) * stride + 20 * 4:
                          offset + (height - 1 - y) * stride + min(width - 55, 355) * 4]
                    for y in range(top, bottom, 3))


def changed_ratio(a, b):
    if len(a) != len(b):
        raise ValueError("screenshot sample size changed")
    # Compare one BGRA pixel every fourth pixel; large page shifts exceed 1%.
    total = 0
    different = 0
    for index in range(0, len(a), 16):
        total += 1
        if a[index:index + 3] != b[index:index + 3]:
            different += 1
    return different / total if total else 0.0


def capture_page(title, run, slug, max_scrolls, delta, width, height, top, bottom, resume=False, rewind_to_top=False, header_reference=None):
    windows = _windows(title, "WeChatAppEx.exe")
    if len(windows) != 1:
        raise RuntimeError("expected exactly one target miniapp window")
    hwnd = windows[0]
    left, upper, right, lower = win32gui.GetWindowRect(hwnd)
    if (right-left, lower-upper) != (width, height):
        raise RuntimeError("miniapp window dimensions changed")
    if header_reference is not None:
        expected_header = bmp_region_hash(header_reference, (156, 20, 264, 60))
        probe = run / "screenshots" / ".header-probe.bmp"
        probe.parent.mkdir(parents=True, exist_ok=True)
        try:
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline:
                _capture(hwnd, probe)
                if bmp_region_hash(probe, (156, 20, 264, 60)) == expected_header:
                    break
                time.sleep(0.25)
            else:
                raise RuntimeError("visible miniapp header did not match the requested page")
        finally:
            probe.unlink(missing_ok=True)
    output = run / "screenshots" / "long-pages" / slug
    output.mkdir(parents=True, exist_ok=resume)
    manifest = output / "manifest.json"
    if rewind_to_top:
        before = output / ".rewind-before.bmp"
        after = output / ".rewind-after.bmp"
        for _ in range(30):
            _capture(hwnd, before)
            old_pixels = content_pixels(before, width, height, top, bottom)
            _activate(hwnd)
            win32api.SetCursorPos((left + width // 2, upper + (top + bottom) // 2))
            win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, 10000, 0)
            time.sleep(0.5)
            _capture(hwnd, after)
            new_pixels = content_pixels(after, width, height, top, bottom)
            if changed_ratio(old_pixels, new_pixels) < 0.01:
                break
        else:
            raise RuntimeError("could not verify top of page after 30 upward scrolls")
        before.unlink()
        after.unlink()
    results = json.loads(manifest.read_text(encoding="utf-8"))["steps"] if resume else []
    if results and results[-1].get("endOfPage"):
        return results
    if results:
        previous = content_pixels(run / results[-1]["file"], width, height, top, bottom)
        results[-1].pop("maxScrollsReached", None)
        start = results[-1]["step"] + 1
        _activate(hwnd)
        win32api.SetCursorPos((left + width // 2, upper + (top + bottom) // 2))
        win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, delta, 0)
        time.sleep(1.0)
    else:
        previous = None
        start = 0
    for step in range(start, max_scrolls + 1):
        target = output / f"screen-{step:03d}.bmp"
        _capture(hwnd, target)
        pixels = content_pixels(target, width, height, top, bottom)
        ratio = changed_ratio(previous, pixels) if previous is not None else None
        entry = {"step": step, "file": str(target.relative_to(run)).replace("\\", "/"),
                 "sampleSha256": hashlib.sha256(pixels).hexdigest(), "changedRatio": ratio}
        results.append(entry)
        manifest.write_text(json.dumps({"title": title, "slug": slug, "steps": results}, ensure_ascii=False, indent=2), encoding="utf-8")
        if ratio is not None and ratio < 0.01:
            entry["endOfPage"] = True
            break
        if step == max_scrolls:
            entry["maxScrollsReached"] = True
            break
        previous = pixels
        _activate(hwnd)
        win32api.SetCursorPos((left + width // 2, upper + (top + bottom) // 2))
        win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, delta, 0)
        time.sleep(1.0)
    manifest.write_text(json.dumps({"title": title, "slug": slug, "steps": results}, ensure_ascii=False, indent=2), encoding="utf-8")
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--slug", required=True)
    parser.add_argument("--max-scrolls", type=int, default=100)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--rewind-to-top", action="store_true")
    parser.add_argument("--delta", type=int, default=-520)
    parser.add_argument("--width", type=int, default=430)
    parser.add_argument("--height", type=int, default=788)
    parser.add_argument("--top", type=int, default=105)
    parser.add_argument("--bottom", type=int, default=715)
    parser.add_argument("--header-reference")
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected an existing E-drive brand run")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,80}", args.slug):
        parser.error("unsafe page slug")
    if not 0 <= args.max_scrolls <= 200 or not -1000 <= args.delta <= -120:
        parser.error("scroll bounds exceeded")
    if args.resume and args.rewind_to_top:
        parser.error("--resume and --rewind-to-top cannot be combined")
    if not 0 <= args.top < args.bottom <= args.height:
        parser.error("invalid content region")
    header_reference = Path(args.header_reference).resolve() if args.header_reference else None
    if header_reference:
        require_e_output(str(header_reference))
        if not header_reference.is_file():
            parser.error("header reference image is missing")
    results = capture_page(args.title, run, args.slug, args.max_scrolls, args.delta,
                           args.width, args.height, args.top, args.bottom, args.resume, args.rewind_to_top,
                           header_reference)
    print(json.dumps({"screens": len(results), "endOfPage": results[-1].get("endOfPage", False),
                      "maxScrollsReached": results[-1].get("maxScrollsReached", False)}))


if __name__ == "__main__":
    main()
