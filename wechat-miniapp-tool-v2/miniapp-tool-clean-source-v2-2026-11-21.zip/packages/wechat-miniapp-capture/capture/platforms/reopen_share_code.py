"""Reopen an already sent miniapp share code from the user's self chat."""

import argparse
import json
from pathlib import Path
import time

import win32api
import win32con
import win32gui
import win32process

from capture.core.config import require_e_output
from capture.platforms.open_share_code import MAIN_SIZE, SELF_HEADER_HASH, bmp_region_hash, locate_self_result, popup_for
from capture.platforms.windows_ui import _activate, _click, _capture, _process_name, _type_unicode, _windows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file() or not (run / "share-code-sent.bmp").is_file():
        parser.error("an existing brand run with a sent link is required")
    main = _windows("微信", "Weixin.exe")
    if len(main) != 1:
        raise RuntimeError("expected one WeChat main window")
    _activate(main[0])
    left, top, right, bottom = win32gui.GetWindowRect(main[0])
    if (right-left, bottom-top) != MAIN_SIZE:
        raise RuntimeError("WeChat window size changed")
    _click(main[0], 150, 56)
    win32api.keybd_event(win32con.VK_CONTROL, 0, 0, 0)
    win32api.keybd_event(ord("A"), 0, 0, 0)
    win32api.keybd_event(ord("A"), 0, win32con.KEYEVENTF_KEYUP, 0)
    win32api.keybd_event(win32con.VK_CONTROL, 0, win32con.KEYEVENTF_KEYUP, 0)
    _type_unicode("文件传输助手")
    deadline = time.monotonic() + 8
    popup = None
    while time.monotonic() < deadline:
        try:
            popup = popup_for(main[0])
            break
        except RuntimeError:
            time.sleep(0.2)
    if popup is None:
        raise RuntimeError("self-chat search popup did not appear")
    search_image = run / "reopen-self-search.bmp"
    _capture(popup, search_image)
    y = locate_self_result(search_image)
    if win32gui.GetForegroundWindow() != main[0]:
        raise RuntimeError("WeChat lost focus")
    left, top, _, _ = win32gui.GetWindowRect(popup)
    win32api.SetCursorPos((left+110, top+y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    time.sleep(0.7)
    chat_image = run / "reopen-self-chat.bmp"
    _capture(main[0], chat_image)
    if bmp_region_hash(chat_image, (310, 34, 480, 72)) != SELF_HEADER_HASH:
        raise RuntimeError("self chat header not verified")
    link_rect = (393, 383, 638, 421)
    expected = bmp_region_hash(run / "share-code-sent.bmp", link_rect)
    matches = [y for y in range(80, 430)
               if bmp_region_hash(chat_image, (link_rect[0], y, link_rect[2], y + 38)) == expected]
    if len(matches) != 1:
        raise RuntimeError("saved share code is not the latest visible self-chat message")
    _click(main[0], 500, matches[0] + 17)
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        foreground = win32gui.GetForegroundWindow()
        try:
            _, pid = win32process.GetWindowThreadProcessId(foreground)
            if _process_name(pid) == "wechatappex.exe":
                time.sleep(1)
                output = run / "reopened-screen.bmp"
                _capture(foreground, output)
                print(json.dumps({"windowTitle": win32gui.GetWindowText(foreground), "screenshot": str(output)}, ensure_ascii=False))
                return
        except Exception:
            pass
        time.sleep(0.25)
    raise RuntimeError("saved share code did not reopen a miniapp")


if __name__ == "__main__":
    main()
