import json
from pathlib import Path
import socket
import struct
import subprocess
import time

from capture.core.config import require_e_output, validate_steps


def choose_unique(candidates, label):
    if len(candidates) != 1:
        raise ValueError(f"Expected exactly one {label}; found {len(candidates)}")
    return candidates[0]


def bridge_preflight(root, version):
    root = Path(root)
    bridge = root / "platforms" / "wmpf" / "bridge"
    if version not in {26134, 26506}:
        raise ValueError(f"unsupported WMPF version {version}; this bridge supports 26134 and 26506")
    config = bridge / f"windows-wmpf-{version}.json"
    if not config.is_file():
        raise FileNotFoundError(config)
    data = json.loads(config.read_text(encoding="utf-8"))
    if data.get("version") != version:
        raise ValueError("bridge offset config version mismatch")
    for name in ("agent.js", "server.mjs", "wire.mjs", "sockets.mjs"):
        if not (bridge / name).is_file():
            raise FileNotFoundError(bridge / name)
    return {"version": version, "config": str(config)}


def runtime_preflight(root, version):
    root = Path(root)
    info = bridge_preflight(root, version)
    for name in ("ws", "frida"):
        if not (root / "node_modules" / name).is_dir():
            raise FileNotFoundError(f"Install {name} in the capture package on E:")
    if not (root / "node_modules/frida/build/frida_binding.node").is_file():
        raise FileNotFoundError("Frida native binding is missing from the capture package")
    for port in (9421, 62000):
        _require_free_port(port)
    return info


def load_target(config_path):
    config = json.loads(Path(config_path).read_text(encoding="utf-8"))
    if not isinstance(config, dict) or not all(key in config for key in ("title", "appId", "wmpfVersion", "searchText", "searchPoint", "resultPoint", "windowSize", "steps")):
        raise ValueError("target configuration is incomplete")
    if not isinstance(config["title"], str) or not isinstance(config["searchText"], str):
        raise ValueError("title and searchText must be strings")
    if not isinstance(config["appId"], str) or not config["appId"].startswith("wx") or len(config["appId"]) != 18:
        raise ValueError("invalid miniapp AppID")
    for name in ("searchPoint", "resultPoint", "windowSize"):
        value = config[name]
        if not isinstance(value, list) or len(value) != 2 or any(not isinstance(n, int) or n <= 0 for n in value):
            raise ValueError(f"invalid {name}")
    validate_steps(config["steps"])
    return config


def _require_free_port(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        try:
            probe.bind(("127.0.0.1", port))
        except OSError as error:
            raise RuntimeError(f"Local port {port} is already in use; no process was started") from error


def _stop_owned(process):
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def matching_responses(directory, wanted_path):
    names = set()
    for file in Path(directory).glob("*.json"):
        if file.name == "ready.json":
            continue
        try:
            path = json.loads(file.read_text(encoding="utf-8")).get("path", "")
        except (ValueError, OSError):
            continue
        if path == wanted_path or (wanted_path.endswith("/") and path.startswith(wanted_path)):
            names.add(file.name)
    return names


def wait_for_response(directory, wanted_path, before, timeout, process=None):
    deadline = time.monotonic() + timeout
    while time.monotonic() <= deadline:
        found = matching_responses(directory, wanted_path) - before
        if found:
            return sorted(found)[0]
        if process is not None and process.poll() is not None:
            raise RuntimeError("CDP collector stopped before expected response")
        time.sleep(0.1)
    raise RuntimeError(f"Expected product response {wanted_path} was not observed within {timeout}s")


def load_product_targets(responses):
    targets = {}
    for file in sorted(Path(responses).glob("*.json")):
        if file.name == "ready.json":
            continue
        record = json.loads(file.read_text(encoding="utf-8"))
        if record.get("path") != "/v2/ec/searchProducts":
            continue
        for item in (record.get("data") or {}).get("items") or []:
            if not isinstance(item, dict):
                continue
            ec = item.get("ec") or {}
            product = item.get("product") or {}
            ec_id = ec.get("id")
            if isinstance(ec_id, str) and len(ec_id) == 24 and isinstance(product.get("id"), str):
                targets[ec_id] = {"ecId": ec_id, "productId": product["id"], "name": str(product.get("name") or "")}
    return list(targets.values())


def send_runtime_command(process, responses, command_id, action, ec_id=None, timeout=12):
    result_file = Path(responses) / "command-result.json"
    result_file.unlink(missing_ok=True)
    process.stdin.write(json.dumps({"id": command_id, "action": action, "productId": ec_id}) + "\n")
    process.stdin.flush()
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if result_file.is_file():
            try:
                result = json.loads(result_file.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                time.sleep(0.1)
                continue
            if result.get("id") == command_id:
                if not result.get("ok"):
                    raise RuntimeError(result.get("error", "Product navigation failed"))
                return
        if process.poll() is not None:
            raise RuntimeError("CDP collector stopped during product navigation")
        time.sleep(0.1)
    raise RuntimeError(f"Product navigation command {command_id} timed out")


def detail_image_visible(bitmap_path):
    data = Path(bitmap_path).read_bytes()
    if data[:2] != b"BM" or len(data) < 54:
        raise ValueError("Invalid detail screenshot")
    offset = struct.unpack_from("<I", data, 10)[0]
    width, height = struct.unpack_from("<ii", data, 18)
    bits = struct.unpack_from("<H", data, 28)[0]
    if bits != 32 or width < 400 or height < 700:
        raise ValueError("Unexpected detail screenshot format")
    nonwhite = 0
    total = 0
    for y in range(115, 360, 3):
        for x in range(45, min(width - 45, 385), 3):
            pixel = offset + ((height - 1 - y) * width + x) * 4
            if min(data[pixel:pixel + 3]) < 230:
                nonwhite += 1
            total += 1
    return nonwhite / total > 0.01


def run_capture(config_path, output_path, node_exe="node", open_target=True, detail_source=None, detail_limit=None):
    config = load_target(config_path)
    targets = load_product_targets(detail_source) if detail_source else None
    if targets is not None and not targets:
        raise ValueError("No product targets found in source responses")
    if targets is not None and detail_limit is not None:
        targets = targets[:detail_limit]
    output = Path(output_path).resolve()
    require_e_output(str(output))
    package = Path(__file__).resolve().parents[2]
    runtime_preflight(package, config["wmpfVersion"])
    from capture.platforms.windows_ui import WindowsUi, _windows
    ui = WindowsUi(config)
    existing = _windows(config["title"], "WeChatAppEx.exe")
    if existing:
        choose_unique(existing, "miniapp window")
    elif open_target:
        choose_unique(_windows("微信", "Weixin.exe"), "signed-in WeChat main window")
    else:
        raise RuntimeError("Target miniapp window is not visible")
    output.mkdir(parents=True, exist_ok=True)
    raw = output / "responses"
    raw.mkdir(exist_ok=True)
    screenshots = output / "screenshots"
    screenshots.mkdir(exist_ok=True)
    ready = raw / "ready.json"
    ready.unlink(missing_ok=True)
    bridge_process = None
    collector_process = None
    with (output / "bridge.log").open("w", encoding="utf-8") as bridge_log, (output / "collector.log").open("w", encoding="utf-8") as collector_log:
        try:
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            bridge_process = subprocess.Popen([node_exe, str(package / "platforms/wmpf/bridge/server.mjs"), "--version", str(config["wmpfVersion"])], cwd=package, stdout=bridge_log, stderr=subprocess.STDOUT, creationflags=flags)
            for _ in range(150):
                if bridge_process.poll() is not None:
                    raise RuntimeError("Own WMPF bridge exited; inspect bridge.log")
                if "bridge ready" in (output / "bridge.log").read_text(encoding="utf-8", errors="replace"):
                    break
                time.sleep(0.2)
            else:
                raise RuntimeError("Own WMPF bridge did not attach within 30 seconds")
            if open_target:
                ui.open_miniapp()
            else:
                ui.miniapp_window()
            collector = package / "platforms/wmpf/cdp/collector.mjs"
            collector_process = subprocess.Popen([node_exe, str(collector), "--app-id", config["appId"], "--output", str(raw)], cwd=package, stdin=subprocess.PIPE if targets is not None else None, text=targets is not None, stdout=collector_log, stderr=subprocess.STDOUT, creationflags=flags)
            for _ in range(150):
                if ready.is_file():
                    break
                if collector_process.poll() is not None:
                    raise RuntimeError("CDP collector exited; inspect collector.log")
                time.sleep(0.2)
            else:
                raise RuntimeError("Miniapp AppID was not validated within 30 seconds")
            if targets is not None:
                try:
                    send_runtime_command(collector_process, raw, 0, "readCampaignSetting")
                    print("campaign setting read from miniapp runtime", flush=True)
                except RuntimeError as error:
                    print(f"campaign setting unavailable: {error}", flush=True)
                verified = []
                for index, item in enumerate(targets, 1):
                    wanted = f"/v2/ec/products/{item['ecId']}"
                    before = matching_responses(raw, wanted)
                    send_runtime_command(collector_process, raw, index, "openProduct", item["ecId"])
                    response_name = wait_for_response(raw, wanted, before, 20, collector_process)
                    screenshot_name = f"{index:02d}-{item['ecId']}.bmp"
                    deadline = time.monotonic() + 16
                    image_visible = False
                    while time.monotonic() < deadline:
                        time.sleep(1.5)
                        ui.perform({"action": "screenshot", "name": screenshot_name[:-4]}, screenshots)
                        image_visible = detail_image_visible(screenshots / screenshot_name)
                        if image_visible:
                            break
                    verified.append({**item, "response": response_name, "screenshot": screenshot_name, "imageVisible": image_visible})
                    (output / "detail-visits.json").write_text(json.dumps(verified, ensure_ascii=False, indent=2), encoding="utf-8")
                    print(f"detail {index}/{len(targets)}: {item['name']} imageVisible={image_visible}", flush=True)
                    ui.perform({"action": "click", "x": 35, "y": 42, "settle": 0.6}, screenshots)
                return {"appId": config["appId"], "output": str(output), "details": len(verified)}
            for index, step in enumerate(config["steps"], 1):
                if collector_process.poll() is not None:
                    raise RuntimeError("CDP collector stopped during capture; inspect collector.log")
                if "awaitPath" in step:
                    wanted = step["awaitPath"]
                    before = matching_responses(raw, wanted)
                    action = {**step, "settle": 0}
                    action.pop("name", None)
                    ui.perform(action, screenshots)
                    wait_for_response(raw, wanted, before, step.get("awaitTimeout", 20), collector_process)
                    time.sleep(step.get("settle", 1.5))
                    if step.get("name"):
                        ui.perform({"action": "screenshot", "name": step["name"]}, screenshots)
                else:
                    ui.perform(step, screenshots)
                print(f"step {index}/{len(config['steps'])}: {step['action']}")
            return {"appId": config["appId"], "output": str(output), "steps": len(config["steps"])}
        finally:
            _stop_owned(collector_process)
            _stop_owned(bridge_process)
