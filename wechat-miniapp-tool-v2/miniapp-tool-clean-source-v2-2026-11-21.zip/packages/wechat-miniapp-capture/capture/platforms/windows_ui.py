"""Window-scoped WeChat input and screenshots; no browser or login automation."""

import ctypes
import os
from pathlib import Path
import time

import win32api
import win32con
import win32gui
import win32process
import win32ui

from capture.platforms.runner import choose_unique

ACCOUNT_PAUSE = Path(__file__).resolve().parents[4] / "artifacts" / "isolated-android" / "ACCOUNT-AUTOMATION-PAUSED.txt"


class _KeybdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort), ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.c_void_p)]


class _MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long), ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.c_void_p)]


class _InputUnion(ctypes.Union):
    _fields_ = [("ki", _KeybdInput), ("mi", _MouseInput)]


class _Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("data", _InputUnion)]


def _process_name(pid):
    handle = win32api.OpenProcess(win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_READ, False, pid)
    try:
        return Path(win32process.GetModuleFileNameEx(handle, 0)).name.lower()
    finally:
        win32api.CloseHandle(handle)


def _windows(title, executable):
    matches = []

    def visit(hwnd, _):
        try:
            if not win32gui.IsWindowVisible(hwnd) or win32gui.GetWindowText(hwnd) != title:
                return
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            if _process_name(pid) == executable.lower():
                matches.append(hwnd)
        except Exception:
            pass

    win32gui.EnumWindows(visit, None)
    return matches


def _activate(hwnd):
    if ACCOUNT_PAUSE.exists():
        raise RuntimeError(f"WeChat account automation is paused: {ACCOUNT_PAUSE}")
    if os.environ.get("WECHAT_ALLOW_FOREGROUND_INPUT") != "1":
        raise RuntimeError("foreground input is disabled; set WECHAT_ALLOW_FOREGROUND_INPUT=1 only in an isolated session")
    if win32gui.IsIconic(hwnd):
        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
    win32gui.SetForegroundWindow(hwnd)
    for _ in range(10):
        if win32gui.GetForegroundWindow() == hwnd:
            return
        time.sleep(0.1)
    raise RuntimeError("Target window did not become foreground; input cancelled")


def _click(hwnd, x, y):
    _activate(hwnd)
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    if not (0 <= x < right - left and 0 <= y < bottom - top):
        raise ValueError("Click point is outside target window")
    win32api.SetCursorPos((left + x, top + y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)


def _type_unicode(value):
    if ACCOUNT_PAUSE.exists():
        raise RuntimeError(f"WeChat account automation is paused: {ACCOUNT_PAUSE}")
    if os.environ.get("WECHAT_ALLOW_FOREGROUND_INPUT") != "1":
        raise RuntimeError("foreground input is disabled; set WECHAT_ALLOW_FOREGROUND_INPUT=1 only in an isolated session")
    for char in value:
        code = ord(char)
        if code > 0xFFFF:
            raise ValueError("Search text contains unsupported character")
        for flags in (0x0004, 0x0004 | 0x0002):
            event = _Input(type=1, data=_InputUnion(ki=_KeybdInput(wScan=code, dwFlags=flags)))
            if ctypes.windll.user32.SendInput(1, ctypes.byref(event), ctypes.sizeof(event)) != 1:
                raise RuntimeError("Unicode input failed")


def _capture(hwnd, destination):
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    width, height = right - left, bottom - top
    if width <= 0 or height <= 0:
        raise RuntimeError("Target window has invalid size")
    window_dc = win32gui.GetWindowDC(hwnd)
    source = win32ui.CreateDCFromHandle(window_dc)
    dest = source.CreateCompatibleDC()
    bitmap = win32ui.CreateBitmap()
    bitmap.CreateCompatibleBitmap(source, width, height)
    dest.SelectObject(bitmap)
    try:
        if ctypes.windll.user32.PrintWindow(hwnd, dest.GetSafeHdc(), 2) != 1:
            raise RuntimeError("PrintWindow failed")
        destination.parent.mkdir(parents=True, exist_ok=True)
        bitmap.SaveBitmapFile(dest, str(destination))
    finally:
        win32gui.DeleteObject(bitmap.GetHandle())
        dest.DeleteDC()
        source.DeleteDC()
        win32gui.ReleaseDC(hwnd, window_dc)


class WindowsUi:
    def __init__(self, config):
        self.config = config

    def miniapp_window(self):
        return choose_unique(_windows(self.config["title"], "WeChatAppEx.exe"), "miniapp window")

    def open_miniapp(self):
        existing = _windows(self.config["title"], "WeChatAppEx.exe")
        if len(existing) == 1:
            return existing[0]
        if existing:
            raise ValueError("Multiple target miniapp windows")
        wechat = choose_unique(_windows("微信", "Weixin.exe"), "signed-in WeChat main window")
        _activate(wechat)
        _click(wechat, *self.config["searchPoint"])
        time.sleep(0.2)
        _type_unicode(self.config["searchText"])
        deadline = time.monotonic() + 5
        popups = []
        _, wechat_pid = win32process.GetWindowThreadProcessId(wechat)
        while time.monotonic() < deadline:
            popups.clear()

            def visit(hwnd, _):
                if not win32gui.IsWindowVisible(hwnd) or win32gui.GetClassName(hwnd) != "Qt51514QWindowToolSaveBits":
                    return
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                left, top, right, bottom = win32gui.GetWindowRect(hwnd)
                if pid == wechat_pid and right - left >= 300 and bottom - top >= 500:
                    popups.append(hwnd)

            win32gui.EnumWindows(visit, None)
            if len(popups) == 1:
                break
            time.sleep(0.2)
        popup = choose_unique(popups, "WeChat search popup")
        if win32gui.GetForegroundWindow() != wechat:
            raise RuntimeError("WeChat lost foreground before result click")
        left, top, right, bottom = win32gui.GetWindowRect(popup)
        x, y = self.config["resultPoint"]
        if not (0 <= x < right - left and 0 <= y < bottom - top):
            raise ValueError("Search result point outside popup")
        win32api.SetCursorPos((left + x, top + y))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            matches = _windows(self.config["title"], "WeChatAppEx.exe")
            if len(matches) == 1:
                return matches[0]
            time.sleep(0.25)
        raise RuntimeError("Expected miniapp window did not appear")

    def perform(self, step, output):
        hwnd = self.miniapp_window()
        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
        expected = self.config["windowSize"]
        if abs((right - left) - expected[0]) > 12 or abs((bottom - top) - expected[1]) > 12:
            raise RuntimeError("Miniapp window size changed; coordinates are unsafe")
        action = step["action"]
        if action == "click":
            _click(hwnd, step["x"], step["y"])
        elif action == "scroll":
            if not (0 <= step["x"] < right - left and 0 <= step["y"] < bottom - top):
                raise ValueError("Scroll point is outside target window")
            _activate(hwnd)
            win32api.SetCursorPos((left + step["x"], top + step["y"]))
            win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, step["delta"], 0)
        elif action == "wait":
            time.sleep(step["seconds"])
        if action in {"click", "scroll"}:
            time.sleep(step.get("settle", 1.5))
        if action == "screenshot" or step.get("name"):
            name = step.get("name") or "screenshot"
            _capture(hwnd, output / f"{name}.bmp")
