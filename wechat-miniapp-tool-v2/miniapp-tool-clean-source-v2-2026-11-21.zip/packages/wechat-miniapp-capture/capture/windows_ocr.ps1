param(
    [Parameter(Mandatory = $true)][string]$Image,
    [string]$Output
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime

$imagePath = [IO.Path]::GetFullPath($Image)
if (-not $imagePath.StartsWith('E:\', [StringComparison]::OrdinalIgnoreCase) -or
    -not [IO.File]::Exists($imagePath)) {
    throw 'OCR input must be an existing E-drive image.'
}
if ($Output) {
    $outputPath = [IO.Path]::GetFullPath($Output)
    if (-not $outputPath.StartsWith('E:\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'OCR output must be on E drive.'
    }
}

$storageFileType = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$streamType = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
$decoderType = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
$softwareBitmapType = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
$ocrEngineType = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$ocrResultType = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Foundation.IAsyncOperation`1, Windows.Foundation, ContentType = WindowsRuntime]

function Await-WinRT($operation, [Type]$resultType) {
    $method = [System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethodDefinition -and
            $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 } |
        Select-Object -First 1
    $task = $method.MakeGenericMethod($resultType).Invoke($null, @($operation))
    $task.Wait()
    return $task.Result
}

$file = Await-WinRT ($storageFileType::GetFileFromPathAsync($imagePath)) $storageFileType
$stream = Await-WinRT ($file.OpenReadAsync()) $streamType
try {
    $decoder = Await-WinRT ($decoderType::CreateAsync($stream)) $decoderType
    $bitmap = Await-WinRT ($decoder.GetSoftwareBitmapAsync()) $softwareBitmapType
    try {
        $engine = $ocrEngineType::TryCreateFromUserProfileLanguages()
        if ($null -eq $engine) { throw 'No installed OCR language is available.' }
        $result = Await-WinRT ($engine.RecognizeAsync($bitmap)) $ocrResultType
        $text = $result.Text
        if ($Output) {
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($outputPath)) | Out-Null
            [IO.File]::WriteAllText($outputPath, $text, [Text.UTF8Encoding]::new($false))
        } else {
            $text
        }
    } finally {
        if ($bitmap -is [IDisposable]) { $bitmap.Dispose() }
    }
} finally {
    if ($stream -is [IDisposable]) { $stream.Dispose() }
}
