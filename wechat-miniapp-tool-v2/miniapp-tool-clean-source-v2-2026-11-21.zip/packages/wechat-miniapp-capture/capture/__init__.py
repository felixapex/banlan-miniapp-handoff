"""Local WeChat miniapp capture package."""
