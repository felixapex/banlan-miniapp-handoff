"""Offline traversal tests: no ADB process or WeChat account is used."""

import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from capture.core.visual_explorer import explore_visible


def png(state):
    return (b'\x89PNG\r\n\x1a\n' + b'\x00' * 8 + (400).to_bytes(4, 'big') +
            (800).to_bytes(4, 'big') + state.encode('ascii'))


def xml(*items):
    return ('<hierarchy>' + ''.join(
        f'<node text="{label}" clickable="true" bounds="[{x},{y}][{x+80},{y+50}]"/>'
        for label, x, y in items) + '</hierarchy>').encode()


class FakeDevice:
    def __init__(self):
        self.state = 'home-0'
        self.taps = []
        self.swipes = []
        self.back_target = None
        self.previous = 'home-0'
        self.extra_button = False

    def screenshot(self): return png(self.state)

    def hierarchy(self):
        pages = {
            'home-0': xml(('Catalog', 20, 100), ('Pay now', 20, 200),
                          *((('Other', 120, 300),) if self.extra_button else ())),
            'home-1': xml(('More', 20, 120)),
            'catalog': xml(('Info', 20, 100)),
            'more': xml(),
            'lost': xml(),
        }
        return pages[self.state]

    def tap(self, x, y):
        self.taps.append((self.state, x, y))
        if self.state == 'home-0' and y == 125:
            self.previous, self.state = self.state, 'catalog'
        elif self.state == 'home-1' and y == 145:
            self.previous, self.state = self.state, 'more'

    def back(self): self.state = self.back_target or self.previous

    def swipe(self, x1, y1, x2, y2, duration_ms=350):
        self.swipes.append(self.state)
        if self.state == 'home-0': self.state = 'home-1'


class VisualExplorerTests(unittest.TestCase):
    def test_scroll_waits_for_network_and_records_loaded_response(self):
        class ScrollDevice(FakeDevice):
            def hierarchy(self): return xml()

        class Observer:
            channel_verified = True
            settles = 0
            def checkpoint(self): return self.settles
            def changes(self, cursor): raise AssertionError('scroll bypassed settle')
            def settle(self, cursor):
                self.settles += 1
                return ([{'status': 'verified', 'kind': 'json', 'file': 'responses/list.json'}]
                        if self.settles == 1 else [])

        observer = Observer()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            state = explore_visible(ScrollDevice(), temp, max_screens=5, max_depth=1,
                                    max_scrolls=5, observer=observer)
            self.assertEqual(state['scrolls'][0]['responses'][0]['file'], 'responses/list.json')
            self.assertEqual(state['scrolls'][0]['responseCapture'], 'available')
            self.assertGreaterEqual(observer.settles, 3)
            self.assertEqual(state['scrolls'][-1]['status'], 'end')

    def test_no_change_and_no_response_is_a_failed_button_attempt(self):
        class NoChangeDevice(FakeDevice):
            def hierarchy(self): return xml(('Info', 20, 100))
            def tap(self, x, y): self.taps.append((self.state, x, y))
            def swipe(self, *args): self.swipes.append(self.state)

        class Observer:
            channel_verified = True
            def checkpoint(self): return 0
            def changes(self, cursor): return []

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            state = explore_visible(NoChangeDevice(), temp, max_screens=5, max_depth=1,
                                    max_scrolls=2, observer=Observer())
            self.assertEqual(state['attempts'][0]['status'], 'no_change')
            self.assertEqual(state['attempts'][0]['failureReason'], 'no_response_observed')
            self.assertFalse(state['attempts'][0]['branchComplete'])

    def test_no_visible_effect_is_not_complete_even_when_network_activity_exists(self):
        class NoChangeDevice(FakeDevice):
            def hierarchy(self): return xml(('Info', 20, 100))
            def tap(self, x, y): self.taps.append((self.state, x, y))
            def swipe(self, *args): self.swipes.append(self.state)

        class Observer:
            channel_verified = True
            def checkpoint(self): return 0
            def changes(self, cursor):
                return [{'status': 'verified', 'kind': 'json', 'file': 'responses/one.json'}]

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            state = explore_visible(NoChangeDevice(), temp, max_screens=5, max_depth=1,
                                    max_scrolls=2, observer=Observer())
            self.assertFalse(state['attempts'][0]['branchComplete'])
            self.assertEqual(state['attempts'][0]['failureReason'], 'no_visible_change')

    def test_detected_unlabeled_overlay_icon_is_clicked_and_reconciled(self):
        class Ocr:
            def recognize(self, image): return []
            def detect_icons(self, image, words):
                return ([{'x': 180, 'y': 125, 'score': 1, 'region': 'other',
                          'shape': 'overlay-dismiss-candidate'}] if image.endswith(b'home-0') else [])

        class OverlayDevice(FakeDevice):
            def hierarchy(self):
                return xml() if self.state == 'home-0' else super().hierarchy()
            def back(self): raise AssertionError('dismissed overlay cannot be restored with Back')

        device = OverlayDevice()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            result = explore_visible(device, temp, max_screens=10, max_depth=1, max_scrolls=3, ocr=Ocr())
            self.assertEqual(result['attempts'][0]['action']['source'], 'visual-icon')
            self.assertEqual(device.taps[0][1:], (180, 125))
            self.assertEqual(result['attempts'][0]['status'], 'overlay_dismissed')
            self.assertEqual(result['coverage']['unverifiedVisualIcons'], 0)
            self.assertTrue((Path(temp) / result['attempts'][0]['after']['screenshot']).is_file())

    def test_scrolls_to_end_and_clicks_each_safe_control_with_before_after_evidence(self):
        device = FakeDevice()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            result = explore_visible(device, temp, max_screens=20, max_depth=2, max_scrolls=5)
            labels = [attempt['action']['label'] for attempt in result['attempts']]
            self.assertEqual(labels, ['Catalog', 'Info', 'More'])
            self.assertEqual(result['coverage']['blockedControls'], 1)
            self.assertEqual(result['coverage']['unattemptedControls'], 0)
            self.assertGreater(result['coverage']['incompleteControls'], 0)
            self.assertFalse(result['observedControlsDone'])
            self.assertTrue(any(item['status'] == 'end' for item in result['scrolls']))
            for attempt in result['attempts']:
                self.assertTrue((Path(temp) / attempt['before']['screenshot']).is_file())
                self.assertTrue((Path(temp) / attempt['after']['screenshot']).is_file())
                self.assertNotEqual(attempt['before']['screenshot'], attempt['after']['screenshot'])
                self.assertEqual(attempt['responseCapture'], 'unavailable')
            self.assertFalse(result['completeMiniapp'])
            self.assertGreater(result['coverage']['iconInspectionErrors'], 0)
            self.assertEqual(json.loads((Path(temp) / 'capture.json').read_text(encoding='utf-8'))['coverage'], result['coverage'])

    def test_no_change_button_has_attempt_and_return_failure_leaves_remaining_pending(self):
        device = FakeDevice()
        device.back_target = 'lost'
        device.extra_button = True
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            result = explore_visible(device, temp, max_screens=20, max_depth=2, max_scrolls=2)
            self.assertIn('return_mismatch', [attempt['status'] for attempt in result['attempts']])
            self.assertGreater(result['coverage']['unattemptedControls'], 0)
            self.assertFalse(result['observedControlsDone'])

    def test_high_confidence_ocr_is_attempted_and_unsafe_text_is_blocked(self):
        class OcrDevice(FakeDevice):
            def hierarchy(self): return xml()
            def tap(self, x, y):
                self.taps.append((self.state, x, y))
                if y == 125: self.state = 'catalog'

        class Ocr:
            def recognize(self, image):
                if image.endswith(b'home-0'):
                    return [{'text': 'Menu', 'score': .99, 'bounds': [20, 100, 100, 150], 'center': [60, 125]},
                            {'text': 'Pay now', 'score': .99, 'bounds': [20, 200, 100, 250], 'center': [60, 225]}]
                return []

        device = OcrDevice()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            result = explore_visible(device, temp, max_screens=10, max_depth=1, max_scrolls=1, ocr=Ocr())
            self.assertEqual(result['attempts'][0]['action']['label'], 'Menu')
            self.assertEqual(result['coverage']['blockedControls'], 1)

    def test_unlabeled_icon_is_unverified_and_response_evidence_is_attached(self):
        class IconDevice(FakeDevice):
            def hierarchy(self):
                if self.state == 'home-0':
                    return b'<hierarchy><node text="Catalog" clickable="true" bounds="[20,100][100,150]"/><node text="" clickable="true" bounds="[120,100][170,150]"/></hierarchy>'
                return xml()

        class Observer:
            available = True
            channel_verified = True
            def checkpoint(self): return 0
            def changes(self, cursor):
                return [{'status': 'verified', 'kind': 'json', 'file': 'responses/one.json'},
                        {'status': 'verified', 'kind': 'image', 'file': 'responses/one.png'}]

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            result = explore_visible(IconDevice(), temp, max_screens=10, max_depth=1, max_scrolls=3, observer=Observer())
            self.assertEqual(result['coverage']['unverifiedControls'], 1)
            self.assertFalse(result['observedControlsDone'])
            self.assertEqual(result['attempts'][0]['responseCapture'], 'available')
            self.assertEqual([item['kind'] for item in result['attempts'][0]['responses']], ['json', 'image'])
            self.assertEqual(result['attempts'][0]['dataFiles'], ['responses/one.json'])
            self.assertEqual(result['attempts'][0]['imageFiles'], ['responses/one.png'])

    def test_resume_keeps_saved_evidence_and_continues_unfinished_branch(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            first = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2, max_scrolls=5, max_actions=1)
            self.assertEqual(first['stopReason'], 'action_limit')
            saved_path = Path(temp) / first['attempts'][0]['before']['screenshot']
            original = saved_path.read_bytes()
            second = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2, max_scrolls=5, max_actions=10)
            self.assertEqual(second['resumeCount'], 1)
            self.assertEqual([item['action']['label'] for item in second['attempts'] if not item.get('replay')],
                             ['Catalog', 'Info', 'More'])
            self.assertEqual(second['coverage']['unattemptedControls'], 0)
            self.assertGreater(second['coverage']['incompleteControls'], 0)
            self.assertEqual(saved_path.read_bytes(), original)

    def test_resume_adds_newly_detected_icons_without_replacing_old_screenshot(self):
        class NewDetector:
            def recognize(self, image): return []
            def detect_icons(self, image, words):
                return ([{'x': 180, 'y': 125, 'score': 1, 'region': 'other'}]
                        if image.endswith(b'home-0') else [])

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            first = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2,
                                    max_scrolls=3, max_actions=1)
            saved_path = Path(temp) / first['screens'][0]['screenshot']
            saved_bytes = saved_path.read_bytes()
            second = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2,
                                     max_scrolls=3, max_actions=20, ocr=NewDetector())
            self.assertTrue(any(control['source'] == 'visual-icon'
                                for control in second['screens'][0]['controls']))
            self.assertTrue(any(attempt['action']['source'] == 'visual-icon'
                                for attempt in second['attempts']))
            self.assertEqual(saved_path.read_bytes(), saved_bytes)

    def test_missing_or_invalid_response_evidence_prevents_done_status(self):
        class SimpleDevice(FakeDevice):
            def hierarchy(self): return xml(('Info', 20, 100)) if self.state == 'home-0' else xml()
            def tap(self, x, y): self.taps.append((self.state, x, y))
            def swipe(self, *args): self.swipes.append(self.state)

        class BadObserver:
            available = True
            def checkpoint(self): return 0
            def changes(self, cursor): return [{'status': 'invalid', 'kind': 'image', 'file': 'responses/missing.png'}]

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            result = explore_visible(SimpleDevice(), temp, max_screens=5, max_depth=1, max_scrolls=3,
                                     observer=BadObserver())
            self.assertGreater(result['coverage']['responseErrors'], 0)
            self.assertFalse(result['observedControlsDone'])

    def test_action_waits_for_response_settle_before_marking_done(self):
        class SimpleDevice(FakeDevice):
            def hierarchy(self): return xml(('Info', 20, 100)) if self.state == 'home-0' else xml()
            def tap(self, x, y): self.taps.append((self.state, x, y))
            def swipe(self, *args): self.swipes.append(self.state)

        class Observer:
            channel_verified = True
            def checkpoint(self): return 0
            def changes(self, cursor): raise AssertionError('settle was bypassed')
            def settle(self, cursor): return [{'status': 'capture-error', 'error': 'response activity did not settle'}]

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            result = explore_visible(SimpleDevice(), temp, max_screens=5, max_depth=1, max_scrolls=3,
                                     observer=Observer())
            self.assertEqual(result['attempts'][0]['responses'][0]['status'], 'capture-error')
            self.assertFalse(result['attempts'][0]['branchComplete'])

    def test_ocr_labels_an_unlabeled_accessibility_button_at_same_position(self):
        class HybridDevice(FakeDevice):
            def hierarchy(self):
                if self.state == 'home-0':
                    return b'<hierarchy><node text="" clickable="true" bounds="[20,100][100,150]"/></hierarchy>'
                return xml()

        class Ocr:
            def recognize(self, image):
                return [{'text': 'Catalog', 'score': .99, 'bounds': [20, 100, 100, 150], 'center': [60, 125]}] if image.endswith(b'home-0') else []

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            result = explore_visible(HybridDevice(), temp, max_screens=10, max_depth=1, max_scrolls=3, ocr=Ocr())
            self.assertEqual(result['attempts'][0]['action']['label'], 'Catalog')
            self.assertEqual(result['coverage']['unverifiedControls'], 0)

    def test_brand_allocator_input_file_can_start_new_capture_without_overwrite(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            input_file = Path(temp) / 'input.json'
            input_file.write_text('{"link":"sample"}', encoding='utf-8')
            with self.assertRaises(ValueError):
                explore_visible(FakeDevice(), temp, max_screens=5, max_depth=0, max_scrolls=2)
            result = explore_visible(FakeDevice(), temp, max_screens=5, max_depth=0, max_scrolls=2,
                                     allow_input_only=True)
            self.assertTrue(result['screens'])
            self.assertEqual(input_file.read_text(encoding='utf-8'), '{"link":"sample"}')

    def test_prepared_pc_run_accepts_only_known_pre_capture_files(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            root = Path(temp)
            (root / 'input.json').write_text('{"link":"sample"}', encoding='utf-8')
            (root / 'share-intake.json').write_text('{}', encoding='utf-8')
            (root / 'responses').mkdir()
            (root / 'collector-ready.json').write_text('{}', encoding='utf-8')
            result = explore_visible(FakeDevice(), temp, max_screens=5, max_depth=0, max_scrolls=2,
                                     allow_prepared_run=True)
            self.assertTrue(result['screens'])

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp)
            (root / 'unexpected-secret.txt').write_text('keep', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'Existing output'):
                explore_visible(FakeDevice(), temp, allow_prepared_run=True)


if __name__ == '__main__':
    unittest.main()
