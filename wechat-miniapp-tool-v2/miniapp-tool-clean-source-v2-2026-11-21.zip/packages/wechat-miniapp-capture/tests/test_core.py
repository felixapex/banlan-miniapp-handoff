import json
import csv
from pathlib import Path
import tempfile
import unittest

from capture.core.config import require_e_output, validate_steps
from capture.core.export import collect_products, export_images, export_assets, write_catalog, write_detail_text


class ConfigTests(unittest.TestCase):
    def test_rejects_c_drive_output(self):
        with self.assertRaisesRegex(ValueError, "E:"):
            require_e_output(r"C:\Users\example\capture")
        self.assertEqual(require_e_output(r"E:\captures").drive.upper(), "E:")

    def test_rejects_destructive_or_out_of_window_steps(self):
        with self.assertRaises(ValueError):
            validate_steps([{"action": "send_message", "text": "hi"}])
        with self.assertRaises(ValueError):
            validate_steps([{"action": "click", "x": -1, "y": 15}])
        validate_steps([{"action": "click", "x": 12, "y": 20, "awaitPath": "/v2/ec/searchProducts", "awaitTimeout": 20}])
        with self.assertRaises(ValueError):
            validate_steps([{"action": "click", "x": 12, "y": 20, "awaitPath": "/v2/member/profile"}])


class ExportTests(unittest.TestCase):
    def test_detail_text_preserves_product_copy_without_html(self):
        records = [{"source": "detail.json", "path": "/v2/ec/products/ec1", "data": {
            "ec": {"id": "ec1", "shareDescription": "分享文案"},
            "product": {"id": "p1", "name": "座椅", "intro": "<p>第一行<br/>第二行 &amp; 更多</p>", "category": {"properties": [{"name": "设计师", "value": "某设计师"}]}}
        }}]
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            file = write_detail_text(records, Path(temp))
            with file.open(encoding="utf-8-sig", newline="") as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["商品介绍"], "第一行\n第二行 & 更多")
            self.assertIn("设计师", rows[0]["分类属性"])

    def test_catalog_deduplicates_detail_and_list_and_uses_original_url(self):
        records = [
            {"path": "/v2/ec/products/1", "data": {"product": {"id": "1", "name": "Amama", "pictures": [{"url": "https://statics.maiscrm.com/a.jpg", "thumbnailUrl": "https://statics.maiscrm.com/a.jpg?resize"}]}}},
            {"path": "/v2/ec/searchProducts", "data": {"total": 2, "items": [{"product": {"id": "1", "name": "Amama", "pictures": []}}, {"product": {"id": "2", "name": "Campus", "pictures": [{"url": "https://statics.maiscrm.com/b.jpg"}]}}]}},
        ]
        products = collect_products(records)
        self.assertEqual(list(products), ["1", "2"])
        self.assertEqual(products["1"]["pictures"], ["https://statics.maiscrm.com/a.jpg"])

    def test_image_export_reuses_matching_file_and_reports_failure(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp)
            calls = []

            def fetch(url):
                calls.append(url)
                if url.endswith("bad.jpg"):
                    raise OSError("offline")
                return b"\xff\xd8test-image"

            products = {"1": {"id": "1", "name": "Amama", "pictures": ["https://statics.maiscrm.com/a.jpg", "https://statics.maiscrm.com/bad.jpg"]}}
            first = export_images(products, root, fetch)
            second = export_images(products, root, fetch)
            self.assertEqual(first["products"][0]["images"][0]["status"], "downloaded")
            self.assertEqual(second["products"][0]["images"][0]["status"], "existing")
            self.assertEqual(second["products"][0]["images"][1]["status"], "error")
            self.assertEqual(calls.count("https://statics.maiscrm.com/a.jpg"), 1)
            self.assertTrue((root / "manifest.json").is_file())
            changed = {"1": {"id": "1", "name": "Amama", "pictures": ["https://statics.maiscrm.com/updated.jpg"]}}
            third = export_images(changed, root, fetch)
            self.assertEqual(third["products"][0]["images"][0]["status"], "downloaded")
            self.assertEqual(calls.count("https://statics.maiscrm.com/updated.jpg"), 1)

    def test_catalog_keeps_source_and_asset_export_is_allowlisted(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp)
            records = [{"source": "living.json", "path": "/v2/ec/searchProducts", "data": {"items": [{"product": {"id": "1", "name": "Amama", "pictures": [{"url": "https://statics.maiscrm.com/a.jpg"}]}}]}}]
            products = collect_products(records)
            self.assertEqual(products["1"]["source"], "living.json")
            image_manifest = export_images(products, root / "products", lambda _: b"\xff\xd8image")
            write_catalog(image_manifest, root / "products")
            catalog = (root / "products/catalog.csv").read_text(encoding="utf-8-sig")
            self.assertIn("living.json", catalog)
            self.assertIn("Amama", catalog)
            seen = []
            urls = ["https://statics.maiscrm.com/a.jpg?resize=1", "https://evil.example/steal.jpg", "http://statics.maiscrm.com/plain.jpg", "https://statics.maiscrm.com/icon.svg"]
            assets = export_assets(urls, root / "assets", lambda url: seen.append(url) or b"image")
            self.assertEqual(len(assets["assets"]), 2)
            self.assertEqual(len(seen), 2)
            self.assertTrue(all("?" not in url for url in seen))
            self.assertTrue((root / "assets/manifest.json").is_file())


if __name__ == "__main__":
    unittest.main()
