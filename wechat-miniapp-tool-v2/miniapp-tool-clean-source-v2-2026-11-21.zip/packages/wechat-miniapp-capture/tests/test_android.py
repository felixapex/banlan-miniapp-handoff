import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from android_capture import main
from capture.platforms.android import AndroidDevice, classify_link, explore, open_shared_text_in_self_chat, parse_nodes, safe_actions


SAMPLE_UI = b'''<hierarchy><node text="Products" content-desc="" resource-id="x" class="android.view.View" clickable="true" bounds="[10,20][110,80]"/><node text="Pay now" content-desc="" resource-id="y" class="android.view.View" clickable="true" bounds="[10,100][110,160]"/></hierarchy>'''


class AndroidCaptureTests(unittest.TestCase):
    def test_supported_links_and_rejects_unrelated_url(self):
        self.assertEqual(classify_link('#小程序://NatuzziItalia/tjezlUI89cIWHDw'), 'wechat_share_text')
        self.assertEqual(classify_link('weixin://dl/business/?t=abc123'), 'wechat_scheme')
        self.assertEqual(classify_link('https://wxaur.cn/abc123'), 'wechat_url_link')
        with self.assertRaises(ValueError):
            classify_link('https://example.com/login')

    def test_ui_nodes_and_safe_actions(self):
        nodes = parse_nodes(SAMPLE_UI)
        self.assertEqual(nodes[0]['center'], [60, 50])
        self.assertEqual([a['label'] for a in safe_actions(nodes, 400, 800)], ['products'])

    def test_clickable_parent_uses_child_label(self):
        ui = b'<hierarchy><node clickable="true" bounds="[0,0][200,100]"><node text="Catalog" clickable="false" bounds="[20,10][180,80]"/></node></hierarchy>'
        actions = safe_actions(parse_nodes(ui), 400, 800)
        self.assertEqual([a['label'] for a in actions], ['catalog'])

    def test_child_page_is_saved_once(self):
        root = b'<hierarchy><node text="Catalog" clickable="true" bounds="[0,0][100,100]"/></hierarchy>'
        child = b'<hierarchy><node text="Product details" clickable="false" bounds="[0,0][100,100]"/></hierarchy>'

        class FakeDevice:
            def __init__(self): self.current = root; self.captures = 0
            def screenshot(self):
                self.captures += 1
                return b'\x89PNG\r\n\x1a\n' + b'\x00' * 8 + (400).to_bytes(4, 'big') + (800).to_bytes(4, 'big')
            def hierarchy(self): return self.current
            def tap(self, x, y): self.current = child
            def back(self): self.current = root

        device = FakeDevice()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.platforms.android.time.sleep'):
            state = explore(device, temp, max_pages=2, max_depth=1)
            self.assertEqual(len(state['pages']), 2)
            self.assertEqual(device.captures, 2)

    def test_adb_process_uses_e_drive_home_and_temp(self):
        device = AndroidDevice('adb.exe')
        with patch('capture.platforms.android.subprocess.run') as run:
            run.return_value.returncode = 0
            run.return_value.stdout = b'ok'
            device._run('version')
        environment = run.call_args.kwargs['env']
        for name in ('HOME', 'USERPROFILE', 'TMP', 'TEMP', 'ANDROID_USER_HOME'):
            self.assertTrue(environment[name].upper().startswith('E:'), name)

    def test_hierarchy_falls_back_when_normal_dump_cannot_get_idle_state(self):
        device = AndroidDevice('adb.exe')
        commands = []

        def run(*args, **_kwargs):
            commands.append(args)
            if args[:3] == ('shell', 'uiautomator', 'dump') and '--compressed' not in args:
                return b'ERROR: could not get idle state.'
            if args[:2] == ('exec-out', 'cat'):
                if any('--compressed' in command for command in commands):
                    return SAMPLE_UI
                raise RuntimeError('No such file')
            return b''

        with patch.object(device, '_run', side_effect=run):
            self.assertEqual(device.hierarchy(), SAMPLE_UI)
        self.assertTrue(any('--compressed' in command for command in commands))

    def test_accessibility_description_is_exported_as_text(self):
        ui = b'<hierarchy><node text="" content-desc="Featured sofa" clickable="false" bounds="[0,0][100,100]"/></hierarchy>'
        class FakeDevice:
            def screenshot(self): return b'\x89PNG\r\n\x1a\n' + b'\x00' * 8 + (400).to_bytes(4, 'big') + (800).to_bytes(4, 'big')
            def hierarchy(self): return ui
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            state = explore(FakeDevice(), temp, max_pages=1, max_depth=0)
            self.assertEqual(state['pages'][0]['texts'], ['Featured sofa'])

    def test_capture_refuses_partial_existing_output_before_adb(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            (Path(temp) / 'input.json').write_text('{}', encoding='utf-8')
            argv = ['android_capture.py', 'capture', '--link', '#小程序://NatuzziItalia/tjezlUI89cIWHDw', '--output', temp]
            with patch('sys.argv', argv), patch('android_capture.AndroidDevice') as device:
                with self.assertRaisesRegex(RuntimeError, 'Existing capture'):
                    main()
                device.assert_not_called()

    def test_ambiguous_self_chat_never_sends(self):
        class FakeDevice:
            def __init__(self): self.taps = []
            def open_link(self, link): return 'wechat_share_text'
            def hierarchy(self):
                return b'<hierarchy><node text="Else" clickable="true" bounds="[0,0][100,100]"/></hierarchy>'
            def tap(self, x, y): self.taps.append((x, y))
        device = FakeDevice()
        with patch('capture.platforms.android.time.sleep'):
            with self.assertRaisesRegex(RuntimeError, 'found 0'):
                open_shared_text_in_self_chat(device, '#小程序://NatuzziItalia/tjezlUI89cIWHDw')
        self.assertEqual(device.taps, [])

    def test_share_intent_quotes_unicode_link_as_one_android_shell_argument(self):
        device = AndroidDevice('adb.exe')
        link = '#小程序://班兰/QWrl0vfR4c04F3j'
        with patch.object(device, '_run', return_value=b'') as run:
            device.open_link(link)
        args = run.call_args.args
        self.assertEqual(args[0], 'shell')
        self.assertIn("'" + link + "'", args[1])

    def test_new_tablet_share_flow_sends_only_to_filehelper_then_opens_link(self):
        link = '#小程序://班兰/QWrl0vfR4c04F3j'
        screens = [
            [('分享方式', False), ('发送给朋友', False), ('仅此一次', True)],
            [('分享方式', False), ('发送给朋友', False), ('仅此一次', True)],
            [('选择一个聊天', False), ('搜索', True)],
            [('文件传输助手', False), ('微信号: filehelper', False)],
            [('文件传输助手', True), (link, False), ('发送', True)],
            [('已发送', False), ('留在微信', True)],
            [(link, True)],
            [('即将打开"班兰"小程序', False), ('允许', True)],
        ]

        class FakeDevice:
            def __init__(self): self.index = 0; self.taps = []; self.search = []
            def open_link(self, value): self.link = value
            def input_ascii(self, value): self.search.append(value)
            def tap(self, x, y): self.taps.append((x, y)); self.index += 1
            def hierarchy(self):
                import xml.etree.ElementTree as ET
                root = ET.Element('hierarchy')
                for i, (label, clickable) in enumerate(screens[min(self.index, len(screens) - 1)]):
                    ET.SubElement(root, 'node', text=label, clickable=str(clickable).lower(), bounds=f'[{i * 10},0][{i * 10 + 9},9]')
                return ET.tostring(root, encoding='utf-8')

        device = FakeDevice()
        with patch('capture.platforms.android.time.sleep'):
            open_shared_text_in_self_chat(device, link)
        self.assertEqual(device.link, link)
        self.assertEqual(device.search, ['filehelper'])
        self.assertEqual(len(device.taps), 8)

    def test_invalid_wechat_login_stops_before_recipient_or_send(self):
        class FakeDevice:
            def __init__(self): self.taps = []
            def open_link(self, value): pass
            def hierarchy(self):
                return '<hierarchy><node text="账号状态异常，本次登录已失效" clickable="false" bounds="[0,0][300,100]"/></hierarchy>'.encode()
            def tap(self, x, y): self.taps.append((x, y))
        device = FakeDevice()
        with patch('capture.platforms.android.time.sleep'):
            with self.assertRaisesRegex(RuntimeError, 'session is restored'):
                open_shared_text_in_self_chat(device, '#小程序://班兰/QWrl0vfR4c04F3j')
        self.assertEqual(device.taps, [])

    def test_one_page_capture_writes_png_xml_and_manifest_on_e(self):
        class FakeDevice:
            def screenshot(self): return b'\x89PNG\r\n\x1a\n' + b'\x00' * 8 + (400).to_bytes(4, 'big') + (800).to_bytes(4, 'big')
            def hierarchy(self): return SAMPLE_UI
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            output = Path(temp)
            state = explore(FakeDevice(), output, max_pages=1, max_depth=0)
            self.assertEqual(len(state['pages']), 1)
            self.assertTrue((output / state['pages'][0]['screenshot']).is_file())
            self.assertTrue((output / state['pages'][0]['ui']).is_file())
            self.assertEqual(json.loads((output / 'capture.json').read_text(encoding='utf-8'))['pages'][0]['texts'], ['Pay now', 'Products'])

    def test_android_swipe_uses_selected_adb_device(self):
        device = AndroidDevice('adb.exe', 'test-serial')
        with patch.object(device, '_run', return_value=b'') as run:
            device.swipe(200, 640, 200, 200, 350)
        self.assertEqual(run.call_args.args, ('shell', 'input', 'swipe', '200', '640', '200', '200', '350'))

    def test_capture_cli_uses_coverage_explorer_and_preserves_resume_input(self):
        import argparse
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            output = Path(temp) / 'brand' / 'runs' / 'capture'
            output.mkdir(parents=True)
            source = {'link': 'weixin://dl/business/?t=abc123', 'kind': 'wechat_scheme', 'serial': 'test-serial'}
            (output / 'input.json').write_text(json.dumps(source), encoding='utf-8')
            (output / 'capture.json').write_text(json.dumps({'kind': 'visible-miniapp-capture'}), encoding='utf-8')
            marker = Path(temp) / 'absent-pause.txt'
            argv = ['android_capture.py', 'capture', '--link', source['link'], '--output', str(output), '--no-ocr']
            with patch('sys.argv', argv), patch('android_capture.ACCOUNT_PAUSE', marker), \
                 patch('android_capture.AndroidDevice') as device, patch('android_capture.explore_visible', return_value={'screens': [], 'attempts': [], 'stopReason': 'test'}) as explore, \
                 patch('android_capture.verify_capture', return_value={'observedScopeVerified': True, 'pendingControls': 0}):
                device.return_value.select.return_value = 'test-serial'
                main()
            self.assertEqual(json.loads((output / 'input.json').read_text(encoding='utf-8')), source)
            explore.assert_called_once()

    def test_account_pause_blocks_new_capture_before_adb_or_output(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            marker = Path(temp) / 'ACCOUNT-AUTOMATION-PAUSED.txt'
            marker.write_text('paused', encoding='utf-8')
            output = Path(temp) / 'brand' / 'runs' / 'new'
            argv = ['android_capture.py', 'capture', '--link', '#小程序://班兰/QWrl0vfR4c04F3j', '--output', str(output)]
            with patch('sys.argv', argv), patch('android_capture.ACCOUNT_PAUSE', marker), \
                 patch('android_capture.AndroidDevice') as device:
                with self.assertRaisesRegex(RuntimeError, 'paused'):
                    main()
                device.assert_not_called()
            self.assertFalse(output.exists())

    def test_link_only_allocates_separate_brand_run_after_device_preflight(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp) / '班兰' / 'runs' / 'new'
            run.mkdir(parents=True)
            (run / 'input.json').write_text(json.dumps({'brand': '班兰', 'link': '#小程序://班兰/QWrl0vfR4c04F3j'}), encoding='utf-8')
            argv = ['android_capture.py', 'capture', '--link', '#小程序://班兰/QWrl0vfR4c04F3j', '--no-ocr']
            with patch('sys.argv', argv), patch('android_capture.ACCOUNT_PAUSE', Path(temp) / 'absent'), \
                 patch('android_capture.AndroidDevice') as device, \
                 patch('android_capture.create_brand_run', return_value=run) as create, \
                 patch('android_capture.open_shared_text_in_self_chat'), \
                 patch('android_capture.explore_visible', return_value={'screens': [], 'attempts': [], 'stopReason': 'test'}), \
                 patch('android_capture.verify_capture', return_value={'observedScopeVerified': True, 'pendingControls': 0}):
                device.return_value.select.return_value = 'test-serial'
                main()
            self.assertEqual(create.call_args.args[1], '班兰')
            self.assertEqual(json.loads((run / 'input.json').read_text(encoding='utf-8'))['serial'], 'test-serial')

    def test_capture_cli_reports_unfinished_after_independent_verification(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            output = Path(temp) / 'new-run'
            argv = ['android_capture.py', 'capture', '--link', 'weixin://dl/business/?t=abc123', '--output', str(output), '--no-ocr']
            with patch('sys.argv', argv), patch('android_capture.ACCOUNT_PAUSE', Path(temp) / 'absent'), \
                 patch('android_capture.AndroidDevice') as device, \
                 patch('android_capture.explore_visible', return_value={'screens': [], 'attempts': [], 'stopReason': 'limit'}), \
                 patch('android_capture.verify_capture', return_value={'observedScopeVerified': False, 'pendingControls': 1}):
                device.return_value.select.return_value = 'test-serial'
                with self.assertRaisesRegex(RuntimeError, 'unfinished'):
                    main()

    def test_visual_only_page_uses_ocr_and_reports_navigation_limit(self):
        class FakeDevice:
            def screenshot(self): return b'\x89PNG\r\n\x1a\n' + b'\x00' * 8 + (400).to_bytes(4, 'big') + (800).to_bytes(4, 'big')
            def hierarchy(self): return b'<hierarchy><node text="" clickable="false" bounds="[0,0][400,800]"/></hierarchy>'
        class FakeOcr:
            def recognize(self, image): return [{'text': '产品分类', 'score': 0.99, 'bounds': [100, 10, 200, 40], 'center': [150, 25]}]
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            state = explore(FakeDevice(), temp, max_pages=2, max_depth=1, ocr=FakeOcr())
            self.assertEqual(state['pages'][0]['mode'], 'ocr')
            self.assertEqual(state['pages'][0]['texts'], ['产品分类'])
            self.assertIn('no accessible click targets', state['stopReason'])
            self.assertEqual(state['pages'][0]['controls'][0]['status'], 'unverified_visual_text')
            self.assertEqual(state['coverage']['unverifiedVisualTexts'], 1)
            self.assertFalse(state['complete'])

    def test_capture_ledger_distinguishes_clicked_and_skipped_controls(self):
        root = b'<hierarchy><node text="Products" clickable="true" bounds="[0,0][100,100]"/><node text="Pay now" clickable="true" bounds="[0,100][100,200]"/></hierarchy>'
        child = b'<hierarchy><node text="Detail" clickable="false" bounds="[0,0][100,100]"/></hierarchy>'

        class FakeDevice:
            def __init__(self): self.current = root
            def screenshot(self): return b'\x89PNG\r\n\x1a\n' + b'\x00' * 8 + (400).to_bytes(4, 'big') + (800).to_bytes(4, 'big')
            def hierarchy(self): return self.current
            def tap(self, x, y): self.current = child
            def back(self): self.current = root

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.platforms.android.time.sleep'):
            state = explore(FakeDevice(), temp, max_pages=3, max_depth=1)
            self.assertEqual(state['coverage']['attemptedActions'], 1)
            self.assertEqual(state['coverage']['skippedControls'], 1)
            self.assertEqual(state['attempts'][0]['status'], 'changed_page')
            self.assertEqual([item['status'] for item in state['pages'][0]['controls']], ['eligible', 'skipped'])
            self.assertFalse(state['complete'])


if __name__ == '__main__':
    unittest.main()
