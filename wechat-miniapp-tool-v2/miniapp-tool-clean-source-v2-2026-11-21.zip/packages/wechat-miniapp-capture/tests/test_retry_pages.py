import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from capture.verification.reconcile_data import reconcile_data
from capture.verification.retry_pages import retry_missing_pages
from tests.test_data_reconciliation import save_response
from tests.test_retry_assets import Response


class RetryPagesTests(unittest.TestCase):
    def test_get_pagination_retrieves_missing_page_and_reconciles(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            url = 'https://api.example/products?category=sofa&start=0&limit=2&total=3'
            save_response(run, 'list.json', url, 'json',
                          b'{"data":{"total":3,"items":[{"id":"p1"},{"id":"p2"}]}}')
            lines = (run / 'responses.jsonl').read_text(encoding='utf-8').splitlines()
            entry = json.loads(lines[0]); entry['requestMethod'] = 'GET'
            (run / 'responses.jsonl').write_text(json.dumps(entry) + '\n', encoding='utf-8')
            for ident in ('p1', 'p2', 'p3'):
                save_response(run, f'{ident}.json', f'https://api.example/products/{ident}', 'json',
                              json.dumps({'product': {'id': ident, 'description': f'{ident} detail'}}).encode())
            before = reconcile_data(run)
            self.assertEqual(before['paginationGaps'][0]['missingCount'], 1)
            seen = []
            def open_url(request, timeout):
                seen.append(request.full_url)
                self.assertIn('start=2', request.full_url)
                return Response(b'{"data":{"total":3,"items":[{"id":"p3"}]}}',
                                'application/json', request.full_url)
            with patch('capture.verification.retry_pages.urlopen', side_effect=open_url):
                retry = retry_missing_pages(run, before)
            self.assertEqual(retry['saved'], 1)
            self.assertEqual(len(seen), 1)
            self.assertEqual(reconcile_data(run)['paginationGaps'], [])

    def test_missing_request_method_prevents_guessed_replay(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json', 'https://api.example/products?start=0&limit=2', 'json',
                          b'{"data":{"total":3,"items":[{"id":"p1"},{"id":"p2"}]}}')
            before = reconcile_data(run)
            with patch('capture.verification.retry_pages.urlopen') as open_url:
                retry = retry_missing_pages(run, before)
            open_url.assert_not_called()
            self.assertEqual(retry['saved'], 0)
            self.assertEqual(retry['skipped'], 1)
            self.assertEqual(len(reconcile_data(run)['paginationGaps']), 1)


if __name__ == '__main__':
    unittest.main()
