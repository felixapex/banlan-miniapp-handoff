import json
import hashlib
from pathlib import Path
import tempfile
import unittest

from capture.verification.sku_audit import build_selection_plan, run_selection_audit


def _detail():
    return {
        "good": {
            "id": "product-1",
            "title": "Test sofa",
            "specs": [{
                "id": "root",
                "children": [
                    {
                        "id": "group-model",
                        "name": "Model",
                        "children": [{
                            "id": "model-family",
                            "name": "Sofa",
                            "children": [
                                {"id": "model-a", "name": "A", "file_url": "a.jpg"},
                                {"id": "model-b", "name": "B", "file_url": "b.jpg"},
                            ],
                        }],
                    },
                    {
                        "id": "group-material",
                        "name": "Material",
                        "children": [
                            {"id": "material-x", "name": "X", "file_url": "x.jpg"},
                            {"id": "material-y", "name": "Y", "file_url": "y.jpg"},
                        ],
                    },
                ],
            }],
        }
    }


class SkuAuditTests(unittest.TestCase):
    def test_plan_executes_every_discovered_button_across_every_combination(self):
        plan = build_selection_plan(_detail())

        self.assertEqual(plan["buttonCount"], 4)
        self.assertEqual(plan["combinationCount"], 4)
        self.assertEqual(plan["selectionEventCount"], 8)
        self.assertEqual(
            plan["combinations"][0]["ids"],
            ["model-a", "material-x"],
        )
        self.assertEqual(
            plan["combinations"][0]["clicks"],
            [
                {
                    "groupIndex": 0,
                    "groupId": "group-model",
                    "groupName": "Model",
                    "buttonId": "model-a",
                    "buttonName": "A",
                    "beforeIds": [],
                    "afterIds": ["model-a"],
                },
                {
                    "groupIndex": 1,
                    "groupId": "group-material",
                    "groupName": "Material",
                    "buttonId": "material-x",
                    "buttonName": "X",
                    "beforeIds": ["model-a"],
                    "afterIds": ["model-a", "material-x"],
                },
            ],
        )

    def test_audit_is_complete_when_every_button_and_combination_is_resolved(self):
        def resolver(gid, ids):
            price = 0 if ids == ["model-b", "material-y"] else 100
            return {
                "code": "0",
                "priceObj": {
                    "gid": gid,
                    "ids": json.dumps(ids),
                    "price": price,
                    "price_id": "price-" + "-".join(ids),
                    "file_url": ids[0] + ".jpg",
                },
                "message": "ok",
            }

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            report = run_selection_audit(_detail(), Path(temp), resolver)
            saved = json.loads((Path(temp) / "sku-selection-audit.json").read_text(encoding="utf-8"))

            self.assertTrue(report["complete"])
            self.assertEqual(report["summary"]["attemptedCombinations"], 4)
            self.assertEqual(report["summary"]["validCombinations"], 3)
            self.assertEqual(report["summary"]["invalidCombinations"], 1)
            self.assertEqual(report["summary"]["failedCombinations"], 0)
            self.assertEqual(report["summary"]["executedSelectionEvents"], 8)
            self.assertEqual(report["summary"]["coveredButtonIds"], [
                "material-x", "material-y", "model-a", "model-b",
            ])
            self.assertTrue(saved["complete"])
            self.assertEqual(len(list((Path(temp) / "responses").glob("*.json"))), 4)

    def test_audit_records_failure_and_refuses_to_report_complete(self):
        def resolver(_gid, ids):
            if ids == ["model-a", "material-y"]:
                raise TimeoutError("request timed out")
            return {"code": "0", "priceObj": {"price": 100, "price_id": 1}}

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            report = run_selection_audit(_detail(), Path(temp), resolver)

            self.assertFalse(report["complete"])
            self.assertEqual(report["summary"]["failedCombinations"], 1)
            failed = [item for item in report["combinations"] if item["status"] == "failed"]
            self.assertEqual(failed[0]["ids"], ["model-a", "material-y"])
            self.assertEqual(failed[0]["error"], "request timed out")

    def test_required_button_images_must_exist_and_match_catalog_bytes(self):
        def resolver(_gid, _ids):
            return {"code": "0", "priceObj": {"price": 100, "price_id": 1}}

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp)
            asset_dir = root / "assets"
            asset_dir.mkdir()
            files = {}
            for name in ("a.jpg", "b.jpg", "x.jpg", "y.jpg"):
                body = ("image-" + name).encode("utf-8")
                path = asset_dir / name
                path.write_bytes(body)
                files[name] = {
                    "urlOrPath": name,
                    "localFile": f"assets/{name}",
                    "sha256": hashlib.sha256(body).hexdigest(),
                }
            catalog = {"productEntries": [{"images": list(files.values())}]}

            report = run_selection_audit(
                _detail(), root / "complete", resolver,
                asset_catalog=catalog, asset_root=root, require_assets=True,
            )
            self.assertTrue(report["complete"])
            self.assertTrue(report["summary"]["allButtonImagesVerified"])
            self.assertEqual(report["summary"]["buttonsWithVerifiedImage"], 4)

            (asset_dir / "y.jpg").unlink()
            incomplete = run_selection_audit(
                _detail(), root / "incomplete", resolver,
                asset_catalog=catalog, asset_root=root, require_assets=True,
            )
            self.assertFalse(incomplete["complete"])
            self.assertEqual(incomplete["summary"]["missingButtonImageIds"], ["material-y"])

    def test_report_response_paths_remain_readable_when_output_argument_is_relative(self):
        def resolver(_gid, _ids):
            return {"code": "0", "priceObj": {"price": 100, "price_id": 1}}

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            relative_output = Path(temp).relative_to(Path.cwd()) / "result"
            report = run_selection_audit(_detail(), relative_output, resolver)

            response_path = Path(report["combinations"][0]["responseFile"])
            self.assertTrue(response_path.is_absolute())
            self.assertTrue(response_path.is_file())

    def test_verified_response_cache_resumes_without_repeating_network_requests(self):
        first_calls = []

        def first_resolver(gid, ids):
            first_calls.append((gid, tuple(ids)))
            return {
                "code": "0",
                "priceObj": {
                    "gid": gid,
                    "ids": json.dumps(ids),
                    "price": 100,
                    "price_id": "price-" + "-".join(ids),
                },
                "message": "ok",
            }

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            output = Path(temp)
            first = run_selection_audit(_detail(), output, first_resolver)
            self.assertEqual(len(first_calls), 4)

            def forbidden_resolver(_gid, _ids):
                raise AssertionError("verified cache must be reused")

            resumed = run_selection_audit(_detail(), output, forbidden_resolver)

            self.assertTrue(first["complete"])
            self.assertTrue(resumed["complete"])
            self.assertEqual(resumed["summary"]["cachedResponses"], 4)
            self.assertEqual(resumed["summary"]["networkResponses"], 0)
            self.assertTrue(all(
                item["responseSource"] == "cache" for item in resumed["combinations"]
            ))

    def test_invalid_cached_identity_is_replaced_and_network_calls_are_rate_limited(self):
        calls = []
        sleeps = []

        def resolver(gid, ids):
            calls.append((gid, tuple(ids)))
            return {
                "code": "0",
                "priceObj": {
                    "gid": gid,
                    "ids": json.dumps(ids),
                    "price": 100,
                    "price_id": "price-" + "-".join(ids),
                },
                "message": "ok",
            }

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            output = Path(temp)
            response_dir = output / "responses"
            response_dir.mkdir()
            (response_dir / "0001-model-a-material-x.json").write_text(
                json.dumps({
                    "code": "0",
                    "priceObj": {
                        "gid": "wrong-product",
                        "ids": json.dumps(["model-a", "material-x"]),
                        "price": 100,
                    },
                }),
                encoding="utf-8",
            )

            report = run_selection_audit(
                _detail(), output, resolver, request_delay=0.25, sleeper=sleeps.append,
            )

            self.assertTrue(report["complete"])
            self.assertEqual(len(calls), 4)
            self.assertEqual(sleeps, [0.25, 0.25, 0.25])
            self.assertEqual(report["summary"]["cachedResponses"], 0)
            self.assertEqual(report["summary"]["networkResponses"], 4)


if __name__ == "__main__":
    unittest.main()
