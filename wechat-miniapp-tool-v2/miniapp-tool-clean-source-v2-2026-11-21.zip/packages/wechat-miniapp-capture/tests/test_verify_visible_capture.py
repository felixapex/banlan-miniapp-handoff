import json
import hashlib
from copy import deepcopy
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from capture.core.visual_explorer import explore_visible
from capture.core.visual_explorer import _controls, _sha
from capture.platforms.android import parse_nodes
from capture.verification.verify_visible_capture import verify_capture
from tests.test_visual_explorer import FakeDevice


class VerifyVisibleCaptureTests(unittest.TestCase):
    def test_archived_banlan_screens_put_every_detected_candidate_in_failure_ledger(self):
        archive = Path(__file__).resolve().parent / 'fixtures/banlan-android-visual-proof'
        if not (archive / 'home.png').is_file():
            self.skipTest('archived Banlan screenshot is unavailable')
        detector = Path(__file__).resolve().parents[1] / 'capture/core/icon_candidates.mjs'
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            (run / 'screenshots').mkdir()
            (run / 'ui').mkdir()
            screens = []
            for name in ('home', 'products'):
                image = (archive / f'{name}.png').read_bytes()
                hierarchy = (archive / f'{name}.xml').read_bytes()
                words = json.loads((archive / f'{name}.ocr.json').read_text(encoding='utf-8'))
                boxes = [{'bounds': word['bounds']} for word in words if 'bounds' in word]
                icons = json.loads(subprocess.run(['node', str(detector), json.dumps(boxes)],
                                              input=image, capture_output=True, check=True).stdout)
                width, height = int.from_bytes(image[16:20], 'big'), int.from_bytes(image[20:24], 'big')
                controls = _controls(parse_nodes(hierarchy), words, width, height, icons)
                fingerprint = _sha(image)
                for control in controls:
                    control['id'] = _sha(f"{fingerprint}:{control['label']}:{control['x']}:{control['y']}".encode())[:20]
                screenshot, ui = f'screenshots/{name}.png', f'ui/{name}.xml'
                (run / screenshot).write_bytes(image)
                (run / ui).write_bytes(hierarchy)
                screens.append({'fingerprint': fingerprint, 'screenshot': screenshot,
                                'screenshotSha256': _sha(image), 'ui': ui, 'uiSha256': _sha(hierarchy),
                                'texts': [word['text'] for word in words], 'controls': controls})
            (run / 'capture.json').write_text(json.dumps({'kind': 'visible-miniapp-capture',
                'screens': screens, 'attempts': [], 'scrolls': [], 'errors': [], 'stopReason': None}), encoding='utf-8')
            report = verify_capture(run)
            expected = sum(len(screen['controls']) for screen in screens)
            self.assertEqual(len(report['controlLedger']), expected)
            self.assertEqual(report['pendingControls'], expected)
            self.assertTrue(any(item['source'] == 'visual-icon' and item['screen'].endswith('home.png')
                                for item in report['retryQueue']))
            self.assertTrue(all(item['reason'] for item in report['retryQueue']))
            self.assertFalse(report['observedScopeVerified'])

    def test_audit_lists_blocked_and_unfinished_controls(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2, max_scrolls=5, max_actions=1)
            report = verify_capture(temp)
            self.assertEqual(report['fileErrors'], [])
            self.assertGreater(report['pendingControls'], 0)
            self.assertEqual(report['blockedControls'], 1)
            self.assertEqual(len(report['controlLedger']), report['pendingControls'])
            self.assertTrue(any(item['reason'] == 'sensitive_action' for item in report['retryQueue']))
            self.assertTrue(all('screen' in item and 'id' in item and 'reason' in item
                                for item in report['retryQueue']))
            self.assertFalse(report['observedScopeVerified'])

    def test_manifest_cannot_forge_completion_without_a_captured_response(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            state = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2, max_scrolls=5, max_actions=1)
            state['attempts'][0]['branchComplete'] = True
            state['attempts'][0]['responseCapture'] = 'available'
            (Path(temp) / 'capture.json').write_text(json.dumps(state), encoding='utf-8')
            report = verify_capture(temp)
            self.assertTrue(any(item['id'] == state['attempts'][0]['action']['id'] and
                                item['reason'] == 'no_response_observed' for item in report['retryQueue']))
            self.assertFalse(report['observedScopeVerified'])

    def test_each_entered_page_requires_two_scroll_checks_at_bottom(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            run = Path(temp)
            state = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2, max_scrolls=5)
            state['scrolls'] = [{'from': state['screens'][0]['fingerprint'],
                                 'after': state['screens'][0], 'status': 'end',
                                 'responseCapture': 'available', 'responses': [],
                                 'dataFiles': [], 'imageFiles': []}]
            (run / 'capture.json').write_text(json.dumps(state), encoding='utf-8')
            report = verify_capture(run)
            self.assertGreater(len(report['scrollCoverageGaps']), 0)
            self.assertFalse(report['observedScopeVerified'])

    def test_successful_retry_resolves_a_prior_failed_response_for_same_button(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            run = Path(temp)
            state = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2, max_scrolls=5, max_actions=1)
            first = state['attempts'][0]
            first['responses'] = [{'status': 'capture-error', 'error': 'old collector failure'}]
            first['responseCapture'] = 'available'
            body = b'{"title":"recovered"}'
            (run / 'responses').mkdir()
            (run / 'responses' / 'new.json').write_bytes(body)
            response = {'status': 'verified', 'kind': 'json', 'url': 'https://api.example/recovered',
                        'file': 'responses/new.json',
                        'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}
            (run / 'responses.jsonl').write_text(json.dumps({**response, 'status': 'saved'}) + '\n')
            retry = deepcopy(first)
            retry.update(responses=[response], dataFiles=['responses/new.json'], imageFiles=[],
                         branchComplete=True, failureReason=None)
            state['attempts'].append(retry)
            (run / 'capture.json').write_text(json.dumps(state), encoding='utf-8')
            report = verify_capture(temp)
            control = next(item for item in report['controlLedger'] if item['id'] == first['action']['id'])
            self.assertEqual(control['result'], 'verified')
            self.assertEqual(control['attemptCount'], 2)

    def test_response_file_without_collector_ledger_entry_cannot_complete_button(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            run = Path(temp)
            state = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2, max_scrolls=5, max_actions=1)
            attempt = state['attempts'][0]
            body = b'{"title":"unattributed"}'
            (run / 'responses').mkdir()
            (run / 'responses' / 'unattributed.json').write_bytes(body)
            response = {'status': 'verified', 'kind': 'json', 'url': 'https://api.example/unattributed',
                        'file': 'responses/unattributed.json',
                        'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}
            (run / 'responses.jsonl').write_text('', encoding='utf-8')
            attempt.update(responseCapture='available', responses=[response], dataFiles=[response['file']],
                           imageFiles=[], branchComplete=True, failureReason=None)
            (run / 'capture.json').write_text(json.dumps(state), encoding='utf-8')
            report = verify_capture(run)
            control = next(item for item in report['controlLedger'] if item['id'] == attempt['action']['id'])
            self.assertEqual(control['reason'], 'response_not_verified')
            self.assertTrue((Path(temp) / 'verification.json').is_file())

    def test_audit_detects_a_modified_screenshot_independently(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp, patch('capture.core.visual_explorer.time.sleep'):
            state = explore_visible(FakeDevice(), temp, max_screens=20, max_depth=2, max_scrolls=5)
            path = Path(temp) / state['attempts'][0]['before']['screenshot']
            path.write_bytes(b'corrupted')
            report = verify_capture(temp)
            self.assertTrue(any(error['file'] == state['attempts'][0]['before']['screenshot'] for error in report['fileErrors']))
            self.assertFalse(report['observedScopeVerified'])


if __name__ == '__main__':
    unittest.main()
