import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import MagicMock, patch
import sys

from pc_share_capture import _run_path, capture_pc, explore_until_reconciled, main, wait_collector_ready


class PcShareCaptureTests(unittest.TestCase):
    def test_retries_incomplete_observed_buttons_before_data_audit(self):
        passes = [
            {'coverage': {'incompleteControls': 2}, 'observedControlsDone': False, 'stopReason': None},
            {'coverage': {'incompleteControls': 0}, 'observedControlsDone': True, 'stopReason': None},
        ]
        with patch('pc_share_capture.explore_visible', side_effect=passes) as explore:
            state = explore_until_reconciled(object(), Path('E:/unused'), max_passes=3)
        self.assertEqual(explore.call_count, 2)
        self.assertEqual(state['explorationPasses'], 2)

    def test_account_pause_stops_before_bridge_or_wechat_input(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            marker = Path(temp) / 'ACCOUNT-AUTOMATION-PAUSED.txt'
            marker.write_text('paused', encoding='utf-8')
            with patch('pc_share_capture.ACCOUNT_PAUSE', marker), \
                 patch.dict(os.environ, {'WECHAT_ALLOW_FOREGROUND_INPUT': '1'}), \
                 patch('pc_share_capture.subprocess.Popen') as process, \
                 patch('pc_share_capture.run_link') as opener:
                with self.assertRaisesRegex(RuntimeError, 'paused'):
                    capture_pc('#小程序://班兰/QWrl0vfR4c04F3j')
                process.assert_not_called()
                opener.assert_not_called()

    def test_foreground_input_requires_explicit_isolated_session(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            with patch('pc_share_capture.ACCOUNT_PAUSE', Path(temp) / 'absent'), \
                 patch.dict(os.environ, {'WECHAT_ALLOW_FOREGROUND_INPUT': '0'}), \
                 patch('pc_share_capture.subprocess.Popen') as process:
                with self.assertRaisesRegex(RuntimeError, 'isolated'):
                    capture_pc('#小程序://班兰/QWrl0vfR4c04F3j')
                process.assert_not_called()

    def test_ready_wait_rejects_wrong_session_and_accepts_exact_appid(self):
        class Process:
            def poll(self): return None

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            ready = run / 'collector-ready.json'
            ready.write_text(json.dumps({'sessionId': 'a' * 32, 'appId': 'wx0123456789abcdef'}), encoding='utf-8')
            with self.assertRaisesRegex(RuntimeError, 'session'):
                wait_collector_ready(run, Process(), 'b' * 32, timeout=0.1)
            self.assertEqual(wait_collector_ready(run, Process(), 'a' * 32, timeout=0.1), 'wx0123456789abcdef')

    def test_joins_link_window_collector_and_verification_without_live_wechat(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            (run / 'input.json').write_text(json.dumps({'link': '#小程序://班兰/QWrl0vfR4c04F3j'}), encoding='utf-8')
            process = MagicMock()
            process.poll.return_value = None
            events = []
            observer = MagicMock()
            observer.channel_verified = True
            retry_screenshots = MagicMock(return_value={'saved': 1, 'failed': 0, 'skipped': 0})
            stop = MagicMock()
            def launch_process(command, **kwargs):
                events.append(Path(command[1]).name)
                return process
            def open_link(link, directory):
                events.append('open-link')
                return {'windowTitle': '班兰'}
            def explore(*args, **kwargs):
                self.assertIs(kwargs['observer'], observer)
                self.assertTrue(kwargs['allow_prepared_run'])
                (run / 'capture.json').write_text('{}', encoding='utf-8')
                return {'coverage': {'observedScreens': 1}, 'observedControlsDone': False}
            with patch('pc_share_capture.ACCOUNT_PAUSE', run / 'absent'), \
                 patch.dict(os.environ, {'WECHAT_ISOLATED_SESSION': '1', 'WECHAT_ALLOW_FOREGROUND_INPUT': '1'}), \
                 patch('pc_share_capture.runtime_preflight'), \
                 patch('pc_share_capture._require_no_open_miniapp'), \
                 patch('pc_share_capture.ScreenshotOcr'), \
                 patch('pc_share_capture._run_path', return_value=(run, False)), \
                 patch('pc_share_capture.subprocess.Popen', side_effect=launch_process) as launch, \
                 patch('pc_share_capture._wait_bridge'), \
                 patch('pc_share_capture.run_link', side_effect=open_link), \
                 patch('pc_share_capture._unique_miniapp_window', return_value=123), \
                 patch('pc_share_capture.wait_collector_ready', return_value='wx0123456789abcdef'), \
                 patch('pc_share_capture.ActiveResponseObserver', return_value=observer), \
                 patch('pc_share_capture.PcVisualDevice'), \
                 patch('pc_share_capture.explore_visible', side_effect=explore), \
                 patch('pc_share_capture.reconcile_data', side_effect=[
                     {'kind': 'miniapp-data-reconciliation', 'status': 'reconciled',
                      'paginationGaps': [], 'missingProductDetails': [{'id': 'p2'}],
                      'missingProductScreenshots': [], 'missingImageReferences': []},
                     {'kind': 'miniapp-data-reconciliation', 'status': 'reconciled',
                      'paginationGaps': [{'endpoint': '/products'}], 'missingImageReferences': []},
                     {'kind': 'miniapp-data-reconciliation', 'status': 'reconciled',
                      'paginationGaps': [], 'missingProductDetails': [{'id': 'p2'}],
                      'missingImageReferences': []},
                     {'kind': 'miniapp-data-reconciliation', 'status': 'reconciled',
                      'paginationGaps': [], 'missingProductDetails': [],
                      'missingImageReferences': [{'url': 'https://img.example/missing.jpg'}]},
                 ]) as audit, \
                 patch.multiple('pc_share_capture', retry_missing_product_screenshots=retry_screenshots,
                                _stop_owned=stop), \
                 patch('pc_share_capture.retry_missing_pages', return_value={'saved': 1, 'failed': 0}) as retry_pages, \
                 patch('pc_share_capture.retry_missing_details', return_value={'saved': 1, 'failed': 0}) as retry_details, \
                 patch('pc_share_capture.retry_missing_images', return_value={'saved': 1, 'failed': 0}) as retry_images, \
                 patch('pc_share_capture.verify_capture', return_value={'observedScopeVerified': False, 'pendingControls': 2,
                                                                       'dataAudit': {'retryQueue': [{'kind': 'image'}]}}):
                result = capture_pc('#小程序://班兰/QWrl0vfR4c04F3j')
            self.assertEqual(launch.call_count, 2)
            self.assertIn('generic-collector.mjs', str(launch.call_args_list[1]))
            self.assertEqual(events, ['server.mjs', 'generic-collector.mjs', 'open-link'])
            self.assertEqual(stop.call_count, 2)
            self.assertEqual(audit.call_count, 4)
            retry_screenshots.assert_called_once()
            retry_pages.assert_called_once()
            retry_details.assert_called_once()
            retry_images.assert_called_once()
            self.assertEqual(result['pagesRecovered'], 1)
            self.assertEqual(result['detailsRecovered'], 1)
            self.assertEqual(result['imagesRecovered'], 1)
            self.assertEqual(result['detailScreenshotsRecovered'], 1)
            self.assertEqual(result['pendingControls'], 2)
            self.assertEqual(result['dataGaps'], 1)
            self.assertFalse(result['observedScopeVerified'])
            self.assertFalse(result['completeMiniapp'])

    def test_new_brand_starts_without_other_brand_data(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp) / 'brands'
            old = root / 'NatuzziItalia' / 'runs' / 'old'
            old.mkdir(parents=True)
            (old / 'responses.jsonl').write_text('old brand data', encoding='utf-8')
            with patch('pc_share_capture.BRANDS', root):
                new, resumed = _run_path('#小程序://新品牌/abcdefgh', '新品牌', None)
            self.assertFalse(resumed)
            self.assertEqual({item.name for item in new.iterdir()}, {'input.json'})
            self.assertNotEqual(new.parent.parent, old.parent.parent)
            self.assertEqual(json.loads((new / 'input.json').read_text(encoding='utf-8'))['link'],
                             '#小程序://新品牌/abcdefgh')

    def test_cli_does_not_signal_full_success_when_only_observed_scope_passed(self):
        result = {'observedScopeVerified': True, 'completeMiniapp': False,
                  'initialResponseCoverage': 'unverified', 'dataGaps': 0}
        with patch.object(sys, 'argv', ['pc_share_capture.py', '--link', '#小程序://新品牌/abcdefgh']), \
             patch('pc_share_capture.capture_pc', return_value=result):
            with self.assertRaises(SystemExit) as raised:
                main()
        self.assertEqual(raised.exception.code, 2)


if __name__ == '__main__':
    unittest.main()
