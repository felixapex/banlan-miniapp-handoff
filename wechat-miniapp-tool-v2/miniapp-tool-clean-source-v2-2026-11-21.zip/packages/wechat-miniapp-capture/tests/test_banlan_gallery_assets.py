import unittest

from capture.adapters.banlan.banlan_gallery_assets import image_suffix, references


class GalleryAssetTests(unittest.TestCase):
    def test_chinese_comma_separates_two_original_images(self):
        host = "https://mp-banlan-product.oss-cn-shenzhen.aliyuncs.com"
        posts = [{"id": "one", "img_urls": f"{host}/first.jpg，{host}/second.png"}]
        refs, unresolved, inferred = references(posts)
        self.assertEqual(len(refs), 2)
        self.assertEqual(unresolved, [])
        self.assertEqual(inferred, [])
        self.assertTrue(all(post_ids == {"one"} for post_ids in refs.values()))

    def test_relative_image_uses_unique_same_post_directory(self):
        host = "https://mp-banlan-product.oss-cn-shenzhen.aliyuncs.com"
        posts = [{"id": "one", "img_urls": f"{host}/drying/sofa/one.jpg,sofa/two.jpg"}]
        refs, unresolved, inferred = references(posts)
        self.assertEqual(len(refs), 2)
        self.assertEqual(unresolved, [])
        self.assertEqual(inferred[0]["resolvedUrl"], f"{host}/drying/sofa/two.jpg")

    def test_unknown_image_bytes_are_rejected(self):
        with self.assertRaises(ValueError):
            image_suffix(b"<html>missing</html>")


if __name__ == "__main__":
    unittest.main()
