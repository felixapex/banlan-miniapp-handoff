import hashlib
from pathlib import Path
import struct
import tempfile
import unittest

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from capture.core.wxapkg_extract import decrypt_v1mmwx, extract_wxapkg, parse_wxapkg


APP_ID = "wx0420724502f5f662"


def _plain_package(entries):
    names = [(name.encode("utf-8"), payload) for name, payload in entries]
    index_size = 4 + sum(4 + len(name) + 8 for name, _payload in names)
    body_offset = 14 + index_size
    cursor = body_offset
    rows = [struct.pack(">I", len(names))]
    body = bytearray()
    for name, payload in names:
        rows.append(struct.pack(">I", len(name)) + name + struct.pack(">II", cursor, len(payload)))
        body.extend(payload)
        cursor += len(payload)
    index = b"".join(rows)
    return b"\xbe" + b"\x00" * 4 + struct.pack(">II", len(index), len(body)) + b"\xed" + index + bytes(body)


def _encrypt_for_windows_cache(plain, app_id=APP_ID):
    if len(plain) < 1023:
        plain += b"\x00" * (1023 - len(plain))
    key = hashlib.pbkdf2_hmac("sha1", app_id.encode(), b"saltiest", 1000, dklen=32)
    encryptor = Cipher(algorithms.AES(key), modes.CBC(b"the iv: 16 bytes")).encryptor()
    encrypted_head = encryptor.update(plain[:1023] + b"\x01") + encryptor.finalize()
    xor_key = app_id.encode()[-2]
    encrypted_tail = bytes(value ^ xor_key for value in plain[1023:])
    return b"V1MMWX" + encrypted_head + encrypted_tail


class WxapkgExtractTests(unittest.TestCase):
    def test_decrypts_windows_cache_and_extracts_verified_members(self):
        plain = _plain_package([
            ("/app-config.json", b'{"pages":["pages/good/detail"]}'),
            ("/pages/good/detail.json", b'{"navigationBarTitleText":"product detail"}'),
            ("/padding.bin", b"x" * 1400),
        ])
        encrypted = _encrypt_for_windows_cache(plain)

        decrypted = decrypt_v1mmwx(encrypted, APP_ID)
        self.assertEqual(decrypted, plain)
        members = parse_wxapkg(decrypted)
        self.assertEqual(
            [member.name for member in members],
            ["app-config.json", "pages/good/detail.json", "padding.bin"],
        )

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            manifest = extract_wxapkg(encrypted, APP_ID, Path(temp))
            page = Path(temp) / "pages" / "good" / "detail.json"
            self.assertEqual(page.read_bytes(), b'{"navigationBarTitleText":"product detail"}')
            self.assertEqual(manifest[1]["sha256"], hashlib.sha256(page.read_bytes()).hexdigest())

    def test_rejects_member_that_escapes_output_directory(self):
        plain = _plain_package([("/../outside.txt", b"no"), ("/padding.bin", b"x" * 1400)])
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            with self.assertRaisesRegex(ValueError, "unsafe member path"):
                extract_wxapkg(_encrypt_for_windows_cache(plain), APP_ID, Path(temp))


if __name__ == "__main__":
    unittest.main()
