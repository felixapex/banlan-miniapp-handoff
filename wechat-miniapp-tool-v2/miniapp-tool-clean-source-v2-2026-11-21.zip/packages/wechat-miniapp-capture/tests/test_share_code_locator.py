"""Regression checks for moving WeChat search rows and sent messages."""

import struct
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from capture.platforms.open_share_code import locate_newest_sent_link, locate_self_result, run_link


def bmp(width, height, pixels):
    offset = 54
    data = bytearray(offset + width * height * 4)
    data[:2] = b"BM"
    struct.pack_into("<I", data, 2, len(data))
    struct.pack_into("<I", data, 10, offset)
    struct.pack_into("<I", data, 14, 40)
    struct.pack_into("<ii", data, 18, width, height)
    struct.pack_into("<H", data, 26, 1)
    struct.pack_into("<H", data, 28, 32)
    for x, y, color in pixels:
        start = offset + (height - 1 - y) * width * 4 + x * 4
        data[start:start + 4] = bytes((*color, 255))
    return data


class ShareCodeLocatorTests(unittest.TestCase):
    def test_account_pause_stops_before_wechat_window_lookup(self):
        with tempfile.TemporaryDirectory() as folder:
            marker = Path(folder) / 'ACCOUNT-AUTOMATION-PAUSED.txt'
            marker.write_text('paused', encoding='utf-8')
            with patch('capture.platforms.open_share_code.ACCOUNT_PAUSE', marker), patch('capture.platforms.open_share_code._windows') as windows:
                with self.assertRaisesRegex(RuntimeError, 'paused'):
                    run_link('#小程序://班兰/QWrl0vfR4c04F3j', Path(folder))
                windows.assert_not_called()

    def test_self_chat_result_can_move_between_search_sections(self):
        top = [14, 18, 20, 22, 24, 26, 28, 23, 21]
        bottom = [28, 26, 24, 22, 20, 18, 14]
        with tempfile.TemporaryDirectory() as folder:
            for y in (56, 258):
                pixels = []
                for offset, count in enumerate(top):
                    pixels.extend((x, y + offset, (0, 200, 0)) for x in range(35, 35 + count))
                for offset, count in enumerate(bottom):
                    pixels.extend((x, y + 25 + offset, (0, 200, 0)) for x in range(35, 35 + count))
                path = Path(folder) / f"search-{y}.bmp"
                path.write_bytes(bmp(368, 519, pixels))
                self.assertEqual(locate_self_result(path), y + 16)

    def test_sent_link_can_move_up_when_chat_content_changes(self):
        with tempfile.TemporaryDirectory() as folder:
            for y in (363, 383):
                pixels = [(x, row, (159, 242, 157)) for row in range(y, y + 36) for x in range(395, 635)]
                path = Path(folder) / f"sent-{y}.bmp"
                path.write_bytes(bmp(718, 582, pixels))
                self.assertEqual(locate_newest_sent_link(path), y + 17)


if __name__ == "__main__":
    unittest.main()
