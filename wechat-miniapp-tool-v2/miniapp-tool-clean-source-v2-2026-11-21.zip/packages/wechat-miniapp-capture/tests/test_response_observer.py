import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from capture.verification.response_observer import ActiveResponseObserver, ResponseObserver


class ResponseObserverTests(unittest.TestCase):
    def test_new_json_and_image_files_are_attributed_and_hash_checked(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            (run / 'responses').mkdir()
            (run / 'responses.jsonl').write_text('', encoding='utf-8')
            observer = ResponseObserver(run)
            cursor = observer.checkpoint()
            records = []
            for index, (kind, body) in enumerate((('json', b'{"name":"Sofa"}'), ('image', b'original-image'))):
                name = f'responses/{index}.bin'
                (run / name).write_bytes(body)
                records.append({'status': 'saved', 'kind': kind, 'url': f'https://example.com/{index}',
                                'file': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
            with (run / 'responses.jsonl').open('a', encoding='utf-8') as file:
                for record in records: file.write(json.dumps(record) + '\n')
            result = observer.changes(cursor)
            self.assertEqual([item['status'] for item in result], ['verified', 'verified'])
            self.assertEqual([item['kind'] for item in result], ['json', 'image'])
            self.assertEqual(observer.changes(observer.checkpoint()), [])

    def test_missing_and_modified_files_cannot_be_reported_as_captured(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            (run / 'responses').mkdir()
            (run / 'responses' / 'bad.png').write_bytes(b'changed')
            entries = [
                {'status': 'saved', 'kind': 'image', 'file': 'responses/bad.png', 'sha256': hashlib.sha256(b'original').hexdigest(), 'bytes': 8},
                {'status': 'saved', 'kind': 'json', 'file': 'responses/missing.json', 'sha256': '0' * 64, 'bytes': 2},
                {'status': 'saved', 'kind': 'image', 'file': '../other.png', 'sha256': '0' * 64, 'bytes': 2},
            ]
            (run / 'responses.jsonl').write_text(''.join(json.dumps(entry) + '\n' for entry in entries), encoding='utf-8')
            result = ResponseObserver(run).changes(0)
            self.assertEqual([item['status'] for item in result], ['invalid', 'invalid', 'invalid'])

    def test_absent_ledger_is_unavailable(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            observer = ResponseObserver(Path(temp))
            self.assertFalse(observer.available)
            self.assertIsNone(observer.checkpoint())
            self.assertEqual(observer.changes(None), [])

    def test_live_channel_requires_matching_app_session_heartbeat_and_process(self):
        from datetime import datetime, timezone, timedelta

        class Process:
            exit_code = None
            def poll(self): return self.exit_code

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            (run / 'responses.jsonl').write_text('', encoding='utf-8')
            session = 'c' * 32
            app = 'wx0123456789abcdef'
            ready = {'sessionId': session, 'appId': app, 'brand': 'test'}
            heartbeat = {'sessionId': session, 'appId': app, 'heartbeatAt': datetime.now(timezone.utc).isoformat(),
                         'inFlight': 0, 'pendingBodies': 0}
            (run / 'collector-ready.json').write_text(json.dumps(ready), encoding='utf-8')
            beat = run / 'collector-heartbeat.json'
            beat.write_text(json.dumps(heartbeat), encoding='utf-8')
            process = Process()
            observer = ActiveResponseObserver(run, process, session, app)
            self.assertTrue(observer.channel_verified)
            self.assertEqual(observer.checkpoint(), 0)
            process.exit_code = 1
            self.assertFalse(observer.channel_verified)
            with self.assertRaisesRegex(RuntimeError, 'collector'):
                observer.checkpoint()
            process.exit_code = None
            heartbeat['heartbeatAt'] = (datetime.now(timezone.utc) - timedelta(seconds=30)).isoformat()
            beat.write_text(json.dumps(heartbeat), encoding='utf-8')
            self.assertFalse(observer.channel_verified)
            heartbeat['heartbeatAt'] = datetime.now(timezone.utc).isoformat()
            heartbeat['sessionId'] = 'd' * 32
            beat.write_text(json.dumps(heartbeat), encoding='utf-8')
            self.assertFalse(observer.channel_verified)

    def test_settle_marks_pending_response_body_as_incomplete(self):
        from datetime import datetime, timezone

        class Process:
            def poll(self): return None

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            session = 'e' * 32
            app = 'wx0123456789abcdef'
            (run / 'responses').mkdir()
            (run / 'responses.jsonl').write_text('', encoding='utf-8')
            (run / 'collector-ready.json').write_text(json.dumps({'sessionId': session, 'appId': app}), encoding='utf-8')
            beat = run / 'collector-heartbeat.json'
            heartbeat = {'sessionId': session, 'appId': app, 'heartbeatAt': datetime.now(timezone.utc).isoformat(),
                         'inFlight': 0, 'pendingBodies': 1}
            beat.write_text(json.dumps(heartbeat), encoding='utf-8')
            observer = ActiveResponseObserver(run, Process(), session, app)
            self.assertEqual(observer.settle(0, timeout=.12, min_wait=.02, quiet=.02)[-1]['status'], 'capture-error')
            body = b'{"product":"ready"}'
            (run / 'responses' / 'one.json').write_bytes(body)
            (run / 'responses.jsonl').write_text(json.dumps({'status': 'saved', 'kind': 'json',
                'file': 'responses/one.json', 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}) + '\n', encoding='utf-8')
            heartbeat['pendingBodies'] = 0
            heartbeat['heartbeatAt'] = datetime.now(timezone.utc).isoformat()
            beat.write_text(json.dumps(heartbeat), encoding='utf-8')
            self.assertEqual(observer.settle(0, timeout=.3, min_wait=.02, quiet=.02)[0]['status'], 'verified')

    def test_command_reply_must_match_owned_app_and_session(self):
        from datetime import datetime, timezone

        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            session = 'f' * 32
            app = 'wx0123456789abcdef'
            (run / 'responses.jsonl').write_text('', encoding='utf-8')
            (run / 'commands').mkdir()
            (run / 'collector-ready.json').write_text(json.dumps({'sessionId': session, 'appId': app}))
            (run / 'collector-heartbeat.json').write_text(json.dumps({
                'sessionId': session, 'appId': app, 'heartbeatAt': datetime.now(timezone.utc).isoformat(),
                'inFlight': 0, 'pendingBodies': 0}))

            class Pipe:
                wrong_app = False
                def write(self, data):
                    command = json.loads(data)
                    answer = {'id': command['id'], 'status': 'ok', 'sessionId': session,
                              'appId': 'wxaaaaaaaaaaaaaaaa' if self.wrong_app else app, 'pages': []}
                    (run / 'commands' / f"{command['id']}.json").write_text(json.dumps(answer))
                def flush(self): pass

            class Process:
                stdin = Pipe()
                def poll(self): return None

            observer = ActiveResponseObserver(run, Process(), session, app)
            self.assertEqual(observer.command('inspectPages')['pages'], [])
            Process.stdin.wrong_app = True
            with self.assertRaisesRegex(RuntimeError, 'another session'):
                observer.command('inspectPages')


if __name__ == '__main__':
    unittest.main()
