import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from capture.core.source_inventory import inspect_project, write_inventory


class SourceInventoryTests(unittest.TestCase):
    def make_project(self, root):
        project = root / 'own-miniapp'
        project.mkdir()
        (project / 'app.json').write_text(json.dumps({
            'pages': ['pages/home/index', 'pages/about/index'],
            'subPackages': [{'root': 'shop', 'pages': ['pages/detail/index']}],
        }), encoding='utf-8')
        (project / 'project.config.json').write_text('{}', encoding='utf-8')
        (project / 'images').mkdir()
        (project / 'images' / 'hero.png').write_bytes(b'hero-original-bytes')
        (project / 'images' / 'icons.svg').write_text('<svg/>', encoding='utf-8')
        (project / 'node_modules').mkdir()
        (project / 'node_modules' / 'skip.png').write_bytes(b'skip')
        (project / '.cache').mkdir()
        (project / '.cache' / 'skip.jpg').write_bytes(b'skip')
        return project

    def test_pages_and_original_assets_are_indexed_without_cache(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temporary:
            project = self.make_project(Path(temporary))
            data = inspect_project(project)
            self.assertEqual(data['pages'], ['pages/home/index', 'pages/about/index', 'shop/pages/detail/index'])
            self.assertTrue(data['projectConfigPresent'])
            self.assertEqual([asset['path'] for asset in data['assets']], ['images/hero.png', 'images/icons.svg'])
            self.assertEqual(data['assets'][0]['sha256'], hashlib.sha256(b'hero-original-bytes').hexdigest())

    def test_invalid_route_and_missing_app_fail_before_output(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temporary:
            root = Path(temporary)
            project = self.make_project(root)
            output = root / 'export'
            (project / 'app.json').write_text('{"pages":["../outside"]}', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'route'):
                write_inventory(project, output)
            self.assertFalse(output.exists())
            (project / 'app.json').write_text('{broken', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'invalid app.json'):
                write_inventory(project, output)
            self.assertFalse(output.exists())
            (project / 'app.json').unlink()
            with self.assertRaisesRegex(ValueError, 'app.json'):
                write_inventory(project, output)
            self.assertFalse(output.exists())

    def test_output_is_new_e_directory_outside_source(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temporary:
            root = Path(temporary)
            project = self.make_project(root)
            with self.assertRaisesRegex(ValueError, 'outside'):
                write_inventory(project, project / 'generated')
            with self.assertRaisesRegex(ValueError, 'E:'):
                write_inventory(project, Path('C:/unsafe-export'))
            output = root / 'export'
            result = write_inventory(project, output)
            self.assertEqual(result, output / 'source-inventory.json')
            saved = json.loads(result.read_text(encoding='utf-8'))
            self.assertEqual(saved['assetCount'], 2)
            with self.assertRaisesRegex(ValueError, 'new'):
                write_inventory(project, output)

    def test_real_devtools_layout_uses_miniprogram_root_from_project_config(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temporary:
            project = Path(temporary) / 'official-layout'
            project.mkdir()
            (project / 'project.config.json').write_text('{"miniprogramRoot":"miniprogram/"}', encoding='utf-8')
            source = project / 'miniprogram'
            source.mkdir()
            (source / 'app.json').write_text('{"pages":["pages/index/index"]}', encoding='utf-8')
            (source / 'logo.png').write_bytes(b'real-layout-logo')
            data = inspect_project(project)
            self.assertEqual(data['sourceRoot'], 'miniprogram')
            self.assertTrue(data['projectConfigPresent'])
            self.assertEqual(data['pages'], ['pages/index/index'])
            self.assertEqual([item['path'] for item in data['assets']], ['logo.png'])


if __name__ == '__main__':
    unittest.main()
