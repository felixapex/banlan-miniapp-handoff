import importlib
from pathlib import Path
import unittest


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
CAPTURE_ROOT = PACKAGE_ROOT / "capture"


class ArchitectureTests(unittest.TestCase):
    def test_public_cli_entrypoints_stay_at_package_root(self):
        for name in (
            "android_capture.py",
            "miniapp_capture.py",
            "pc_share_capture.py",
            "source_inventory.py",
        ):
            self.assertTrue((PACKAGE_ROOT / name).is_file(), name)

    def test_internal_modules_are_split_by_responsibility(self):
        modules = (
            "capture.core.config",
            "capture.core.export",
            "capture.platforms.android",
            "capture.platforms.windows_ui",
            "capture.adapters.banlan.banlan_public_catalog",
            "capture.adapters.banlan.grid_crawler",
            "capture.verification.reconcile_data",
            "capture.verification.verify_visible_capture",
        )
        for module in modules:
            with self.subTest(module=module):
                importlib.import_module(module)

    def test_flat_capture_directory_contains_no_implementation_modules(self):
        flat_modules = sorted(
            path.name
            for path in CAPTURE_ROOT.glob("*.py")
            if path.name != "__init__.py"
        )
        self.assertEqual(flat_modules, [])

    def test_wmpf_runtime_is_under_platform_directory(self):
        self.assertTrue((PACKAGE_ROOT / "platforms" / "wmpf" / "bridge" / "server.mjs").is_file())
        self.assertTrue((PACKAGE_ROOT / "platforms" / "wmpf" / "cdp" / "collector.mjs").is_file())
        self.assertFalse((PACKAGE_ROOT / "bridge").exists())
        self.assertFalse((PACKAGE_ROOT / "cdp").exists())


if __name__ == "__main__":
    unittest.main()
