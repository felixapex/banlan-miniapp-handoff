"""Offline route and screenshot retry tests; no WeChat process is started."""

import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from capture.verification.retry_screenshots import retry_missing_product_screenshots
from capture.verification.reconcile_data import reconcile_data


def png(label):
    return b"\x89PNG\r\n\x1a\n" + b"\x00" * 8 + (400).to_bytes(4, "big") + (800).to_bytes(4, "big") + label.encode()


class ScreenshotRetryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.addCleanup(self.temp.cleanup)
        self.run = Path(self.temp.name)
        (self.run / "responses").mkdir()
        self.app = "wx0123456789abcdef"
        self.session = "a" * 32
        (self.run / "input.json").write_text(json.dumps({"appId": self.app}), encoding="utf-8")
        body = b'{"product":{"id":"p1","name":"Sofa one"}}'
        (self.run / "responses" / "p1.json").write_bytes(body)
        entry = {"status": "saved", "kind": "json", "url": "https://shop.example/products/p1",
                 "file": "responses/p1.json", "sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body)}
        (self.run / "responses.jsonl").write_text(json.dumps(entry) + "\n", encoding="utf-8")
        listing = b'{"items":[{"id":"p1"},{"id":"p2"}],"total":2}'
        (self.run / "responses" / "list.json").write_bytes(listing)
        list_entry = {"status": "saved", "kind": "json", "url": "https://shop.example/products",
                      "file": "responses/list.json", "sha256": hashlib.sha256(listing).hexdigest(), "bytes": len(listing)}
        with (self.run / "responses.jsonl").open("a", encoding="utf-8") as ledger:
            ledger.write(json.dumps(list_entry) + "\n")
        attempt = {"after": {"pages": [{"route": "pages/product/detail", "options": {"id": "p1"}}]},
                   "responses": [{"status": "verified", "kind": "json", "file": "responses/p1.json"}]}
        (self.run / "capture.json").write_text(json.dumps({"attempts": [attempt]}), encoding="utf-8")
        self.audit = {"kind": "miniapp-data-reconciliation", "status": "reconciled",
                      "missingProductDetails": [{"id": "p2"}], "missingProductScreenshots": []}

    def test_revisits_verified_detail_route_and_saves_matched_response_and_screenshot(self):
        run = self.run

        class Device:
            count = 0
            def screenshot(self):
                self.count += 1
                return png("before" if self.count == 1 else "after")
            def hierarchy(self): return b"<hierarchy/>"

        class Observer:
            app_id = self.app
            session_id = self.session
            channel_verified = True
            def checkpoint(self): return 0
            def command(self, action, **arguments):
                if action == "openObservedDetail":
                    assert arguments == {"route": "pages/product/detail", "paramKey": "id", "productId": "p2"}
                    return {"status": "ok"}
                return {"pages": [{"route": "pages/product/detail", "options": {"id": "p2"}}]}
            def settle(self, cursor):
                body = b'{"product":{"id":"p2","name":"Sofa two"}}'
                (run / "responses" / "p2.json").write_bytes(body)
                entry = {"status": "saved", "kind": "json", "url": "https://shop.example/products/p2",
                         "file": "responses/p2.json", "sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body)}
                with (run / "responses.jsonl").open("a", encoding="utf-8") as ledger:
                    ledger.write(json.dumps(entry) + "\n")
                return [{"status": "verified", "kind": "json", "file": "responses/p2.json",
                         "sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body)}]

        class Ocr:
            def recognize(self, image): return [{"text": "Sofa two"}]

        with patch("capture.verification.retry_screenshots.time.sleep"):
            result = retry_missing_product_screenshots(self.run, self.audit, Observer(), Device(), ocr=Ocr())
        self.assertEqual((result["saved"], result["failed"]), (1, 0))
        attempt = result["attempts"][0]
        self.assertEqual(attempt["detailJson"], ["responses/p2.json"])
        self.assertTrue((self.run / attempt["screenshot"]).is_file())
        self.assertEqual(json.loads((self.run / "screenshot-retries.json").read_text())["attempts"][0]["id"], "p2")
        audit = reconcile_data(self.run)
        self.assertNotIn("p2", [item["id"] for item in audit["missingProductScreenshots"]])
        self.assertNotIn("p2", [item["id"] for item in audit["missingProductDetails"]])
        proof = json.loads((self.run / "screenshot-retries.json").read_text())
        proof["attempts"][0]["texts"] = ["unrelated page"]
        (self.run / "screenshot-retries.json").write_text(json.dumps(proof), encoding="utf-8")
        changed = reconcile_data(self.run)
        self.assertIn("p2", [item["id"] for item in changed["missingProductScreenshots"]])

    def test_unknown_route_is_skipped_without_navigation(self):
        source = json.loads((self.run / "capture.json").read_text())
        source["attempts"][0]["after"]["pages"][0]["options"] = {"other": "p99"}
        (self.run / "capture.json").write_text(json.dumps(source), encoding="utf-8")

        class Observer:
            app_id = self.app
            session_id = self.session
            channel_verified = True
            def command(self, *args, **kwargs): raise AssertionError("navigation attempted")

        result = retry_missing_product_screenshots(self.run, self.audit, Observer(), object())
        self.assertEqual((result["saved"], result["skipped"]), (0, 1))


if __name__ == "__main__":
    unittest.main()
