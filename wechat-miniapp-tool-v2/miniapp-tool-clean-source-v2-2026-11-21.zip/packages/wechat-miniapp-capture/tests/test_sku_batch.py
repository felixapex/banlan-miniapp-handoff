import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from capture.verification.sku_batch import audit_local_product, run_batch, select_products


def _batch_detail():
    return {
        "code": "0",
        "good": {
            "id": "p1",
            "title": "Chair",
            "specs": [{
                "id": "root",
                "children": [
                    {"id": "g1", "name": "Model", "children": [
                        {"id": "a", "name": "A", "file_url": "a.jpg"},
                        {"id": "b", "name": "B", "file_url": "b.jpg"},
                    ]},
                    {"id": "g2", "name": "Material", "children": [
                        {"id": "x", "name": "X", "file_url": "x.jpg"},
                        {"id": "y", "name": "Y", "file_url": "y.jpg"},
                    ]},
                ],
            }],
        },
    }


def _write_batch_fixture(root):
    root = Path(root).resolve()
    (root / "detail.json").write_text(json.dumps(_batch_detail()), encoding="utf-8")
    (root / "screen.bmp").write_bytes(b"bitmap")
    images = []
    for name in ("a.jpg", "b.jpg", "x.jpg", "y.jpg"):
        (root / name).write_bytes(("image-" + name).encode("utf-8"))
        images.append({"urlOrPath": name, "localFile": name})
    entry = {
        "id": "p1",
        "title": "Chair",
        "fullDetailJson": "detail.json",
        "screenshot": "screen.bmp",
        "images": images,
        "primaryCategory": {"id": 1, "parent": "Furniture", "name": "Chair"},
    }
    return entry, {"productEntries": [entry]}


class SkuBatchSelectionTests(unittest.TestCase):
    def test_blank_child_category_uses_parent_name(self):
        selected = select_products(
            [{"id": "p1", "title": "Artwork"}],
            {"p1": [{"id": 90, "parent": "班兰画廊", "name": ""}]},
            1,
        )

        self.assertEqual(selected[0]["primaryCategory"]["name"], "班兰画廊")

    def test_selection_is_exact_unique_deterministic_and_category_balanced(self):
        entries = [
            {"id": f"p{index:02d}", "title": f"Product {index:02d}"}
            for index in range(60)
        ]
        memberships = {
            entry["id"]: [{"id": index % 5, "parent": "Furniture", "name": f"Category {index % 5}"}]
            for index, entry in enumerate(entries)
        }

        first = select_products(entries, memberships, 50, required_ids=["p59", "p58"])
        second = select_products(entries, memberships, 50, required_ids=["p59", "p58"])

        self.assertEqual(first, second)
        self.assertEqual(len(first), 50)
        self.assertEqual(len({item["id"] for item in first}), 50)
        self.assertEqual([item["id"] for item in first[:2]], ["p59", "p58"])
        covered = {item["primaryCategory"]["name"] for item in first}
        self.assertEqual(covered, {f"Category {index}" for index in range(5)})

    def test_local_audit_hashes_detail_screenshot_and_every_declared_image(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp).resolve()
            detail = {"code": "0", "good": {"id": "p1", "title": "Chair", "specs": []}}
            (root / "detail.json").write_text(json.dumps(detail), encoding="utf-8")
            (root / "screen.bmp").write_bytes(b"bitmap")
            (root / "image.jpg").write_bytes(b"image-bytes")
            entry = {
                "id": "p1",
                "title": "Chair",
                "fullDetailJson": "detail.json",
                "screenshot": "screen.bmp",
                "images": [{"urlOrPath": "source.jpg", "localFile": "image.jpg"}],
            }

            audit = audit_local_product(entry, root)

            self.assertTrue(audit["complete"])
            self.assertEqual(audit["productId"], "p1")
            self.assertEqual(audit["detail"]["sha256"], hashlib.sha256(
                (root / "detail.json").read_bytes()).hexdigest())
            self.assertEqual(audit["screenshot"]["bytes"], 6)
            self.assertEqual(audit["images"][0]["bytes"], 11)
            self.assertEqual(audit["missing"], [])

    def test_local_audit_rejects_missing_empty_and_outside_files(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp).resolve()
            (root / "detail.json").write_text(
                json.dumps({"good": {"id": "p1", "title": "Chair"}}), encoding="utf-8")
            (root / "empty.bmp").write_bytes(b"")
            entry = {
                "id": "p1",
                "title": "Chair",
                "fullDetailJson": "detail.json",
                "screenshot": "empty.bmp",
                "images": [
                    {"urlOrPath": "missing.jpg", "localFile": "missing.jpg"},
                    {"urlOrPath": "outside.jpg", "localFile": "../outside.jpg"},
                ],
            }

            audit = audit_local_product(entry, root)

            self.assertFalse(audit["complete"])
            self.assertEqual(
                {item["kind"] for item in audit["missing"]},
                {"empty", "missing", "outside-root"},
            )


class SkuBatchExecutionTests(unittest.TestCase):
    def test_batch_resumes_verified_combinations_without_repeating_requests(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp).resolve()
            entry, catalog = _write_batch_fixture(root)
            output = root / "output"
            calls = []

            def resolver(gid, ids):
                calls.append((gid, tuple(ids)))
                return {
                    "code": "0",
                    "priceObj": {
                        "gid": gid,
                        "ids": json.dumps(ids),
                        "price": 100,
                        "price_id": "-".join(ids),
                    },
                    "message": "ok",
                }

            first = run_batch([entry], root, output, catalog, resolver=resolver)
            resumed = run_batch(
                [entry], root, output, catalog,
                resolver=lambda _gid, _ids: self.fail("cache was not reused"),
            )

            self.assertTrue(first["complete"])
            self.assertTrue(resumed["complete"])
            self.assertEqual(len(calls), 4)
            self.assertEqual(resumed["summary"]["cachedResponses"], 4)
            self.assertEqual(resumed["summary"]["networkResponses"], 0)
            self.assertEqual(resumed["products"][0]["skuStatus"], "complete")

    def test_batch_local_failure_skips_network_and_stays_incomplete(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp).resolve()
            entry, catalog = _write_batch_fixture(root)
            (root / "screen.bmp").unlink()
            calls = []

            report = run_batch(
                [entry], root, root / "output", catalog,
                resolver=lambda gid, ids: calls.append((gid, ids)),
            )

            self.assertFalse(report["complete"])
            self.assertEqual(calls, [])
            self.assertEqual(report["products"][0]["skuStatus"], "not-run")
            self.assertIn("local-files-incomplete", report["products"][0]["failures"])

    def test_batch_records_product_with_no_buttons_as_explicit_no_specification(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp).resolve()
            entry, catalog = _write_batch_fixture(root)
            detail = _batch_detail()
            detail["good"]["specs"] = []
            (root / "detail.json").write_text(json.dumps(detail), encoding="utf-8")

            report = run_batch(
                [entry], root, root / "output", catalog,
                resolver=lambda _gid, _ids: self.fail("no SKU request expected"),
            )

            self.assertTrue(report["complete"])
            self.assertEqual(report["products"][0]["skuStatus"], "no-specification")
            self.assertEqual(report["products"][0]["buttonCount"], 0)
            self.assertEqual(report["products"][0]["combinationCount"], 0)


if __name__ == "__main__":
    unittest.main()
