from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from miniapp_capture import main as windows_capture_main

from capture.platforms.runner import choose_unique, bridge_preflight, matching_responses, wait_for_response


class RunnerSafetyTests(unittest.TestCase):
    def test_account_pause_stops_windows_capture_before_bridge(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            marker = Path(temp) / 'ACCOUNT-AUTOMATION-PAUSED.txt'
            marker.write_text('paused', encoding='utf-8')
            argv = ['miniapp_capture.py', 'capture', '--config', 'config/natuzzi.json', '--output', str(Path(temp) / 'run')]
            with patch('sys.argv', argv), patch('miniapp_capture.ACCOUNT_PAUSE', marker), \
                 patch('miniapp_capture.runtime_preflight') as bridge:
                with self.assertRaisesRegex(RuntimeError, 'paused'):
                    windows_capture_main()
                bridge.assert_not_called()

    def test_choose_unique_rejects_ambiguous_or_missing_windows(self):
        for candidates in ([], [1, 2]):
            with self.assertRaises(ValueError):
                choose_unique(candidates, "WeChat")
        self.assertEqual(choose_unique([7], "WeChat"), 7)

    def test_bridge_preflight_requires_own_files_and_matching_version(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp)
            bridge = root / "platforms/wmpf/bridge"
            bridge.mkdir(parents=True)
            (bridge / "windows-wmpf-26506.json").write_text('{"version":26506}', encoding="utf-8")
            with self.assertRaises(FileNotFoundError):
                bridge_preflight(root, 26506)
            for name in ("agent.js", "server.mjs", "wire.mjs", "sockets.mjs"):
                (bridge / name).write_text("", encoding="utf-8")
            self.assertEqual(bridge_preflight(root, 26506)["version"], 26506)
            (bridge / "windows-wmpf-26134.json").write_text('{"version":26134}', encoding="utf-8")
            self.assertEqual(bridge_preflight(root, 26134)["version"], 26134)
            with self.assertRaisesRegex(ValueError, "unsupported"):
                bridge_preflight(root, 26509)

    def test_waits_for_new_product_response_instead_of_old_file(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp)
            (root / "old.json").write_text('{"path":"/v2/ec/searchProducts","data":{}}', encoding="utf-8")
            before = matching_responses(root, "/v2/ec/searchProducts")
            with self.assertRaisesRegex(RuntimeError, "not observed"):
                wait_for_response(root, "/v2/ec/searchProducts", before, 0.1)
            (root / "new.json").write_text('{"path":"/v2/ec/searchProducts","data":{}}', encoding="utf-8")
            self.assertEqual(wait_for_response(root, "/v2/ec/searchProducts", before, 0.1), "new.json")


if __name__ == "__main__":
    unittest.main()
