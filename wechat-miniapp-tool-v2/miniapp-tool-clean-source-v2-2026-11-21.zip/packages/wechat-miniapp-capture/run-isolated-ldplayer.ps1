param(
    [ValidateSet('Status', 'Start', 'Stop')]
    [string]$Action = 'Status'
)

$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$root = [IO.Path]::GetFullPath((Join-Path $workspace 'artifacts\isolated-android'))
if (-not $workspace.StartsWith('E:\', [StringComparison]::OrdinalIgnoreCase) -or
    -not $root.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'The isolated Android files must remain inside the E-drive workspace.'
}

if (-not (Test-Path -LiteralPath 'X:\')) {
    & subst.exe X: $root
    if ($LASTEXITCODE -ne 0) { throw 'Could not map X: to the E-drive Android directory.' }
}
$marker = 'X:\ascii-alias-root.txt'
if (-not (Test-Path -LiteralPath $marker) -or
    (Get-Content -LiteralPath $marker -Raw).Trim() -ne $root -or
    -not (Test-Path -LiteralPath 'X:\ldplayer-installed\ldconsole.exe')) {
    throw 'X: does not point to this isolated Android installation.'
}

$env:LOCALAPPDATA = 'X:\appdata-local'
$env:APPDATA = 'X:\appdata-roaming'
$env:TEMP = 'X:\tmp'
$env:TMP = $env:TEMP
$env:USERPROFILE = 'X:\'
$env:HOME = 'X:\'
$env:ANDROID_USER_HOME = 'X:\avd'
$env:ANDROID_SDK_HOME = 'X:\avd'
$console = 'X:\ldplayer-installed\ldconsole.exe'
$adb = 'X:\sdk\platform-tools\adb.exe'
$config = 'X:\ldplayer-installed\vms\config\leidian0.config'
$settings = Get-Content -LiteralPath $config -Raw | ConvertFrom-Json
if ($settings.'statusSettings.playerName' -ne 'CodexWeChat' -or
    $settings.'basicSettings.adbDebug' -ne 1 -or
    $settings.'advancedSettings.cpuCount' -ne 2 -or
    $settings.'advancedSettings.memorySize' -ne 2048) {
    throw 'The dedicated emulator configuration changed; inspect it before launch.'
}
$instance = @(& $console list2 | Where-Object { $_ -match '^0,CodexWeChat,' })
if ($LASTEXITCODE -ne 0 -or $instance.Count -ne 1) { throw 'Expected exactly one CodexWeChat instance at index 0.' }

function Hide-OwnWindow([string]$Line) {
    $handle = [long](($Line -split ',')[2])
    if ($handle -le 0) { return $false }
    if (-not ('OwnWindow' -as [type])) {
        Add-Type 'using System; using System.Runtime.InteropServices; public class OwnWindow { [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int command); [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h); }'
    }
    $window = [IntPtr]$handle
    if ([OwnWindow]::IsWindowVisible($window)) { [void][OwnWindow]::ShowWindow($window, 0) }
    return -not [OwnWindow]::IsWindowVisible($window)
}

if ($Action -eq 'Stop') {
    & $console quit --index 0
    if ($LASTEXITCODE -ne 0) { throw 'Could not stop CodexWeChat.' }
    Write-Host 'CodexWeChat stop requested; virtual disk preserved on E.'
    exit 0
}

if ($Action -eq 'Start') {
    $driver = Get-Service -Name LD9BoxSup -ErrorAction SilentlyContinue
    if (-not $driver -or $driver.Status -ne 'Running') { throw 'LD9BoxSup driver is not running; no VM started.' }
    if ([int](($instance[0] -split ',')[5]) -le 0) {
        $process = Start-Process -FilePath 'X:\ldplayer-installed\dnplayer.exe' -ArgumentList @('--index', '0') -WorkingDirectory 'X:\ldplayer-installed' -WindowStyle Hidden -PassThru
        try { $process.PriorityClass = [Diagnostics.ProcessPriorityClass]::BelowNormal } catch { }
        Write-Host "CodexWeChat start requested: PID $($process.Id)"
    }
}

$deadline = (Get-Date).AddSeconds($(if ($Action -eq 'Start') { 90 } else { 2 }))
do {
    $instance = @(& $console list2 | Where-Object { $_ -match '^0,CodexWeChat,' })
    if ($instance.Count -eq 1) { [void](Hide-OwnWindow $instance[0]) }
    $devices = & $adb devices -l
    if ($devices -match '^emulator-5554\s+device\b') {
        Write-Host 'ADB ready: emulator-5554; LDPlayer window hidden.'
        exit 0
    }
    Start-Sleep -Seconds 2
} while ((Get-Date) -lt $deadline)

if ($Action -eq 'Start') { throw 'CodexWeChat did not become available through ADB within 90 seconds.' }
Write-Host 'CodexWeChat is not currently online in ADB.'
