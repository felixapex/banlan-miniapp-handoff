import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';

import { captureOwned, validateOwnedOptions } from './owned_capture.mjs';

const packageDir = path.dirname(fileURLToPath(import.meta.url));
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScL/nwAAAABJRU5ErkJggg==', 'base64');

function fixture(t) {
  const root = fs.mkdtempSync(path.join(packageDir, '.owned-capture-test-'));
  t.after(() => {
    if (!path.resolve(root).startsWith(packageDir + path.sep)) throw new Error('unsafe temp cleanup path');
    fs.rmSync(root, { recursive: true, force: true });
  });
  const project = path.join(root, 'project');
  fs.mkdirSync(project);
  fs.writeFileSync(path.join(project, 'project.config.json'), JSON.stringify({ appid: 'wx0123456789abcdef' }));
  const inventoryPath = path.join(root, 'source-inventory.json');
  fs.writeFileSync(inventoryPath, JSON.stringify({ kind: 'own-miniapp-source', project, pages: ['pages/home/index', 'pages/product/index'], pageCount: 2 }));
  return { root, inventoryPath, output: path.join(root, 'brand', 'runs', 'capture') };
}

function fakeAutomator(appId = 'wx0123456789abcdef') {
  const calls = { routes: [], disconnected: false, closeCalled: false, launchCalled: false };
  const mini = {
    evaluate: async () => appId,
    reLaunch: async route => {
      calls.routes.push(route);
      return { path: route, waitFor: async () => {}, data: async () => ({ route, title: route.includes('product') ? '测试商品' : '首页' }) };
    },
    screenshot: async ({ path: destination }) => fs.writeFileSync(destination, png),
    disconnect: async () => { calls.disconnected = true; },
    close: async () => { calls.closeCalled = true; throw new Error('must not close DevTools'); },
  };
  return { calls, automator: { connect: async () => mini, launch: async () => { calls.launchCalled = true; throw new Error('must not launch DevTools'); } } };
}

test('preflight accepts only new E output and explicit loopback endpoint', t => {
  const options = fixture(t);
  assert.throws(() => validateOwnedOptions({ ...options, wsEndpoint: 'ws://example.com:9420' }), /loopback/i);
  assert.throws(() => validateOwnedOptions({ ...options, wsEndpoint: 'ws://127.0.0.1:9420', output: 'C:\\bad' }), /E:/);
  assert.equal(validateOwnedOptions({ ...options, wsEndpoint: 'ws://127.0.0.1:9420' }).pages.length, 2);
});

test('owned-project adapter saves two PNGs and page data without launching or closing DevTools', async t => {
  const options = fixture(t);
  const { calls, automator } = fakeAutomator();
  const manifest = await captureOwned({ ...options, wsEndpoint: 'ws://127.0.0.1:9420', automator });
  assert.deepEqual(calls.routes, ['/pages/home/index', '/pages/product/index']);
  assert.equal(manifest.pages.length, 2);
  assert.equal(manifest.pages[0].status, 'saved');
  assert.equal(manifest.pages[1].status, 'saved');
  assert.ok(fs.readFileSync(path.join(options.output, manifest.pages[0].screenshot)).subarray(0, 8).equals(png.subarray(0, 8)));
  assert.equal(JSON.parse(fs.readFileSync(path.join(options.output, manifest.pages[1].data), 'utf8')).title, '测试商品');
  for (const page of manifest.pages) {
    assert.equal(page.screenshotSha256, crypto.createHash('sha256').update(fs.readFileSync(path.join(options.output, page.screenshot))).digest('hex'));
    assert.equal(page.dataSha256, crypto.createHash('sha256').update(fs.readFileSync(path.join(options.output, page.data))).digest('hex'));
  }
  assert.equal(manifest.success, true);
  assert.equal(calls.disconnected, true);
  assert.equal(calls.closeCalled, false);
  assert.equal(calls.launchCalled, false);
});

test('AppID mismatch disconnects before any page navigation', async t => {
  const options = fixture(t);
  const { calls, automator } = fakeAutomator('wx9999999999999999');
  await assert.rejects(captureOwned({ ...options, wsEndpoint: 'ws://127.0.0.1:9420', automator }), /AppID mismatch/);
  assert.deepEqual(calls.routes, []);
  assert.equal(calls.disconnected, true);
});

test('invalid screenshot is recorded as a failed page and never counted as captured', async t => {
  const options = fixture(t);
  const { calls, automator } = fakeAutomator();
  const originalConnect = automator.connect;
  automator.connect = async params => {
    const mini = await originalConnect(params);
    mini.screenshot = async ({ path: destination }) => fs.writeFileSync(destination, 'not a PNG');
    return mini;
  };
  const manifest = await captureOwned({ ...options, wsEndpoint: 'ws://127.0.0.1:9420', automator, maxPages: 1 });
  assert.equal(manifest.pages[0].status, 'error');
  assert.match(manifest.pages[0].error, /not a PNG/);
  assert.equal(manifest.success, false);
  assert.equal(calls.disconnected, true);
});
