import fs from 'node:fs';
import path from 'node:path';
import WebSocket from 'ws';
import { cleanAssetUrl, isProductUrl, saveProductBody } from './policy.mjs';

function option(name, fallback) {
  const index = process.argv.indexOf(name);
  return index < 0 ? fallback : process.argv[index + 1];
}

const appId = option('--app-id');
const outputDir = option('--output');
const cdpUrl = option('--url', 'ws://127.0.0.1:62000');
const timeoutMs = Number(option('--timeout', '30000'));
if (!/^wx[0-9a-f]{16}$/i.test(appId || '')) throw new Error('valid --app-id is required');
if (!outputDir || !path.win32.isAbsolute(outputDir) || path.win32.parse(outputDir).root.slice(0, 2).toUpperCase() !== 'E:')
  throw new Error('--output must be an absolute E: directory');
const parsedCdp = new URL(cdpUrl);
if (parsedCdp.protocol !== 'ws:' || !['127.0.0.1', 'localhost'].includes(parsedCdp.hostname))
  throw new Error('CDP URL must be local loopback');
if (!Number.isInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > 120000)
  throw new Error('invalid --timeout');

fs.mkdirSync(outputDir, { recursive: true });
fs.rmSync(path.join(outputDir, 'ready.json'), { force: true });
const ws = new WebSocket(cdpUrl);
let validated = false;
let identityValidated = false;
let contextId = 0;
let nextId = 10000;
const pending = new Map();
const productRequests = new Map();
const assets = new Set();
let commandBuffer = '';
const timeout = setTimeout(() => {
  if (!validated) {
    console.error(`target AppID ${appId} was not found within ${timeoutMs} ms`);
    process.exitCode = 1;
    ws.close();
  }
}, timeoutMs);

function call(method, params = {}, waitMs = 5000) {
  return new Promise((resolve, reject) => {
    if (ws.readyState !== WebSocket.OPEN) return reject(new Error('CDP disconnected'));
    const id = nextId++;
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error(`${method} timed out`));
    }, waitMs);
    pending.set(id, { resolve, reject, timer });
    ws.send(JSON.stringify({ id, method, params }));
  });
}

async function captureBody(requestId, meta) {
  try {
    const result = await call('Network.getResponseBody', { requestId }, 10000);
    const body = result.base64Encoded
      ? Buffer.from(result.body, 'base64').toString('utf8')
      : result.body;
    const filename = saveProductBody(outputDir, meta, body);
    console.log(`saved ${filename} ${new URL(meta.url).pathname}`);
  } catch (error) {
    console.error(`body capture failed ${new URL(meta.url).pathname}: ${error.message}`);
  }
}

ws.on('message', (bytes) => {
  let message;
  try { message = JSON.parse(bytes.toString()); } catch { return; }
  const pendingCall = pending.get(message.id);
  if (pendingCall) {
    clearTimeout(pendingCall.timer);
    pending.delete(message.id);
    if (message.error) pendingCall.reject(new Error(JSON.stringify(message.error)));
    else pendingCall.resolve(message.result);
    return;
  }
  if (!identityValidated) return;
  const params = message.params || {};
  if (message.method === 'Network.responseReceived') {
    const response = params.response || {};
    if (response.status === 200 && isProductUrl(response.url))
      productRequests.set(params.requestId, { url: response.url, status: response.status });
    const asset = response.status === 200 && cleanAssetUrl(response.url);
    if (asset && !assets.has(asset)) {
      assets.add(asset);
      fs.appendFileSync(path.join(outputDir, 'image-urls.txt'), `${asset}\n`);
    }
  } else if (message.method === 'Network.loadingFinished') {
    const meta = productRequests.get(params.requestId);
    productRequests.delete(params.requestId);
    if (meta) void captureBody(params.requestId, meta);
  } else if (message.method === 'Network.loadingFailed') {
    productRequests.delete(params.requestId);
  }
});

ws.on('open', async () => {
  try {
    await call('Runtime.enable', {}, 1000).catch(() => {});
    const probe = '(function(){try{return wx.getAccountInfoSync().miniProgram.appId}catch(_){return ""}})()';
    const deadline = Date.now() + timeoutMs;
    while (!contextId && Date.now() < deadline && ws.readyState === WebSocket.OPEN) {
      for (let id = 1; id <= 12; id += 1) {
        try {
          const result = await call('Runtime.evaluate', { expression: probe, contextId: id, returnByValue: true }, 2000);
          if (result?.result?.value === appId) { contextId = id; break; }
        } catch { /* Absent context or navigation in progress. */ }
      }
      if (!contextId) await new Promise((resolve) => setTimeout(resolve, 750));
    }
    if (!contextId) throw new Error(`target AppID ${appId} not found`);
    identityValidated = true;
    await call('Network.enable');
    validated = true;
    fs.writeFileSync(path.join(outputDir, 'ready.json'), JSON.stringify({ appId, contextId, connectedAt: new Date().toISOString() }, null, 2));
    clearTimeout(timeout);
    console.log(`ready ${appId} context=${contextId}`);
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
    ws.close();
  }
});

process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  commandBuffer += chunk;
  let newline;
  while ((newline = commandBuffer.indexOf('\n')) >= 0) {
    const line = commandBuffer.slice(0, newline);
    commandBuffer = commandBuffer.slice(newline + 1);
    void handleCommand(line);
  }
});

async function handleCommand(line) {
  let command;
  try {
    command = JSON.parse(line);
    if (!validated || !Number.isInteger(command.id)) throw new Error('invalid or premature command');
    if (command.action === 'openProduct') {
      if (!/^[0-9a-f]{24}$/i.test(command.productId)) throw new Error('invalid product ID');
      const expression = `wx.navigateTo({url:"/pages/product-detail/index",query:{productId:${JSON.stringify(command.productId)}}}); "sent"`;
      const result = await call('Runtime.evaluate', { expression, contextId, returnByValue: true }, 10000);
      if (result.exceptionDetails || result.result?.value !== 'sent')
        throw new Error(`miniapp navigation failed: ${JSON.stringify(result.exceptionDetails || result.result)}`);
    } else if (command.action === 'readCampaignSetting') {
      const expression = 'JSON.stringify(require("mai-mall/engine/index").Util._implCampaignSettings["natuzzi-data-source"] || null)';
      const result = await call('Runtime.evaluate', { expression, contextId, returnByValue: true }, 10000);
      if (result.exceptionDetails || typeof result.result?.value !== 'string')
        throw new Error(`campaign setting read failed: ${JSON.stringify(result.exceptionDetails || result.result)}`);
      const data = JSON.parse(result.result.value);
      if (!data || typeof data !== 'object') throw new Error('campaign setting is not cached in miniapp');
      fs.writeFileSync(path.join(outputDir, 'campaign-setting.json'), JSON.stringify({ source: 'signed-in miniapp runtime cache', data }, null, 2));
    } else {
      throw new Error('unsupported command');
    }
    fs.writeFileSync(path.join(outputDir, 'command-result.json'), JSON.stringify({ id: command.id, ok: true }));
  } catch (error) {
    fs.writeFileSync(path.join(outputDir, 'command-result.json'), JSON.stringify({ id: command?.id ?? null, ok: false, error: error.message }));
  }
}

ws.on('close', () => {
  clearTimeout(timeout);
  for (const item of pending.values()) { clearTimeout(item.timer); item.reject(new Error('CDP disconnected')); }
  pending.clear();
});
ws.on('error', (error) => { console.error(error.message); process.exitCode = 1; });
