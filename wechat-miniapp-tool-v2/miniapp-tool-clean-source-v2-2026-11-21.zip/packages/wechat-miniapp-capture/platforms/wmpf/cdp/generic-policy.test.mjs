import assert from 'node:assert/strict';
import test from 'node:test';
import path from 'node:path';
import { classifyResponse, validateBrandRunPath } from './generic-policy.mjs';

const root = path.resolve('E:/miniapp-capture-tests/artifacts/brands');

test('accepts only a run inside one brand directory', () => {
  const output = path.join(root, 'new-brand', 'runs', '20261118T010000Z');
  assert.deepEqual(validateBrandRunPath(output, root), { brand: 'new-brand', run: '20261118T010000Z', output });
  assert.throws(() => validateBrandRunPath('C:/Temp/result', root), /brand run/);
  assert.throws(() => validateBrandRunPath(path.join(root, 'new-brand', 'other'), root), /brand run/);
  assert.throws(() => validateBrandRunPath(path.join(root, '..', 'escape', 'runs', 'x'), root), /brand run/);
});

test('classifies response bodies without Natuzzi host assumptions', () => {
  assert.deepEqual(classifyResponse('https://api.example.org/items?id=1', 200, 'application/json'), { kind: 'json', extension: '.json' });
  assert.deepEqual(classifyResponse('https://cdn.other.org/hero.webp?width=750', 200, 'image/webp'), { kind: 'image', extension: '.webp' });
  assert.deepEqual(classifyResponse('https://api.example.org/items', 400, 'application/json'), { kind: 'json', extension: '.json' });
  assert.equal(classifyResponse('http://api.example.org/items', 200, 'application/json'), null);
  assert.equal(classifyResponse('data:image/png;base64,abc', 200, 'image/png'), null);
});
