import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

import { createSessionStatus } from './session-status.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));

test('collector session writes identity and heartbeat, then removes live markers on close', t => {
  const run = fs.mkdtempSync(path.join(here, '.session-status-test-'));
  t.after(() => {
    if (!path.resolve(run).startsWith(here + path.sep)) throw new Error('unsafe cleanup path');
    fs.rmSync(run, { recursive: true, force: true });
  });
  const status = createSessionStatus(run, { sessionId: 'a'.repeat(32), appId: 'wx0123456789abcdef', contextId: 3, brand: '测试' });
  status.ready();
  const identity = JSON.parse(fs.readFileSync(path.join(run, 'collector-ready.json'), 'utf8'));
  assert.equal(identity.sessionId, 'a'.repeat(32));
  assert.equal(identity.appId, 'wx0123456789abcdef');
  assert.equal(fs.readFileSync(path.join(run, 'responses.jsonl'), 'utf8'), '');
  status.pulse({ inFlight: 2, pendingBodies: 1 });
  const heartbeat = JSON.parse(fs.readFileSync(path.join(run, 'collector-heartbeat.json'), 'utf8'));
  assert.equal(heartbeat.sessionId, identity.sessionId);
  assert.equal(heartbeat.inFlight, 2);
  assert.equal(heartbeat.pendingBodies, 1);
  assert.ok(Date.parse(heartbeat.heartbeatAt));
  status.close();
  assert.equal(fs.existsSync(path.join(run, 'collector-ready.json')), false);
  assert.equal(fs.existsSync(path.join(run, 'collector-heartbeat.json')), false);
});

test('rejects malformed identity before writing files', t => {
  const run = fs.mkdtempSync(path.join(here, '.session-status-test-'));
  t.after(() => {
    if (!path.resolve(run).startsWith(here + path.sep)) throw new Error('unsafe cleanup path');
    fs.rmSync(run, { recursive: true, force: true });
  });
  assert.throws(() => createSessionStatus(run, { sessionId: '../wrong', appId: 'wx0123456789abcdef', contextId: 3, brand: '测试' }), /sessionId/);
  assert.deepEqual(fs.readdirSync(run), []);
});
