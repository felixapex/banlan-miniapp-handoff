/** Live identity marker for one local miniapp response collector. */
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

function writeJsonAtomically(file, value) {
  const temporary = `${file}.${process.pid}.${randomUUID()}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2), 'utf8');
  try {
    for (let attempt = 0; attempt < 25; attempt += 1) {
      try {
        fs.renameSync(temporary, file);
        return;
      } catch (error) {
        if (!['EPERM', 'EACCES', 'EBUSY'].includes(error.code) || attempt === 24) throw error;
        // Windows may briefly hold the destination open while an audit reads it.
        Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10);
      }
    }
  } finally {
    fs.rmSync(temporary, { force: true });
  }
}

export function createSessionStatus(run, { sessionId, appId, contextId, brand }) {
  if (!/^[0-9a-f]{32}$/i.test(sessionId || '')) throw new Error('invalid sessionId');
  if (!/^wx[0-9a-f]{16}$/i.test(appId || '')) throw new Error('invalid appId');
  if (!Number.isInteger(contextId) || contextId < 1 || contextId > 1000) throw new Error('invalid contextId');
  if (typeof brand !== 'string' || !brand || brand.length > 80) throw new Error('invalid brand');
  const root = path.resolve(run);
  const readyFile = path.join(root, 'collector-ready.json');
  const heartbeatFile = path.join(root, 'collector-heartbeat.json');
  const identity = { sessionId, appId, contextId, brand, startedAt: new Date().toISOString() };
  return {
    ready() {
      fs.closeSync(fs.openSync(path.join(root, 'responses.jsonl'), 'a'));
      writeJsonAtomically(readyFile, identity);
    },
    pulse({ inFlight = 0, pendingBodies = 0 } = {}) {
      if (![inFlight, pendingBodies].every(value => Number.isSafeInteger(value) && value >= 0))
        throw new Error('invalid collector activity counters');
      writeJsonAtomically(heartbeatFile, {
        sessionId, appId, heartbeatAt: new Date().toISOString(), inFlight, pendingBodies,
      });
    },
    close() {
      fs.rmSync(heartbeatFile, { force: true });
      fs.rmSync(readyFile, { force: true });
    },
  };
}
