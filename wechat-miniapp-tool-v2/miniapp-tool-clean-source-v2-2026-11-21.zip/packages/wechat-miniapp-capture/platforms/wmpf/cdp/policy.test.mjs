import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { isProductUrl, cleanAssetUrl, saveProductBody } from './policy.mjs';

test('allowlist accepts product endpoints and rejects account endpoints', () => {
  assert.equal(isProductUrl('https://consumer-api.quncrm.com/v2/ec/products/123?token=private'), true);
  assert.equal(isProductUrl('https://consumer-api.quncrm.com/v2/ec/searchProducts'), true);
  assert.equal(isProductUrl('https://consumer-api.quncrm.com/v2/ec/weappPages/68ae75e965d8eb0028e0ee18'), true);
  assert.equal(isProductUrl('https://consumer-api.quncrm.com/v2/ec/weappPages/../account'), false);
  assert.equal(isProductUrl('https://consumer-api.quncrm.com/modules/implcommon/setting/detail?campaignId=natuzzi-data-source'), true);
  assert.equal(isProductUrl('https://consumer-api.quncrm.com/modules/implcommon/setting/detail?campaignId=account'), false);
  assert.equal(isProductUrl('https://consumer-api.quncrm.com/apps/forum/articles/searchFromDB'), true);
  assert.equal(isProductUrl('https://consumer-api.quncrm.com/v2/memberEventLogs'), false);
  assert.equal(isProductUrl('https://other.example/v2/ec/products/123'), false);
});

test('asset URLs strip query parameters', () => {
  assert.equal(cleanAssetUrl('https://statics.maiscrm.com/a.jpg?x-oss-process=resize'), 'https://statics.maiscrm.com/a.jpg');
  assert.equal(cleanAssetUrl('https://other.example/a.jpg'), null);
});

test('save keeps full product body and omits request headers', () => {
  const scratch = path.resolve('.test-tmp');
  fs.mkdirSync(scratch, { recursive: true });
  const root = fs.mkdtempSync(path.join(scratch, 'miniapp-capture-'));
  try {
    const large = 'x'.repeat(150000);
    const filename = saveProductBody(root, {
      url: 'https://consumer-api.quncrm.com/v2/ec/products/123?token=private',
      status: 200,
      requestHeaders: { 'X-Access-Token': 'secret' },
    }, JSON.stringify({ product: { id: '123', description: large } }));
    const saved = JSON.parse(fs.readFileSync(path.join(root, filename), 'utf8'));
    assert.equal(saved.data.product.description.length, large.length);
    assert.equal(saved.path, '/v2/ec/products/123');
    assert.equal(fs.readFileSync(path.join(root, filename), 'utf8').includes('secret'), false);
    assert.equal(fs.readFileSync(path.join(root, filename), 'utf8').includes('token=private'), false);
  } finally {
    if (!path.resolve(root).startsWith(scratch + path.sep)) throw new Error('unsafe cleanup target');
    fs.rmSync(root, { recursive: true, force: true });
  }
});
