import path from 'node:path';

const BRAND_NAME = /^[\p{L}\p{N}][\p{L}\p{N}-]{0,63}$/u;
const RUN_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$/;

export function validateBrandRunPath(value, brandsRoot) {
  const root = path.resolve(brandsRoot);
  const output = path.resolve(value);
  const parts = path.relative(root, output).split(path.sep);
  if (path.parse(output).root.slice(0, 2).toUpperCase() !== 'E:' ||
      parts.length !== 3 || parts[1] !== 'runs' ||
      !BRAND_NAME.test(parts[0]) || !RUN_NAME.test(parts[2])) {
    throw new Error('output must be one E: brand run directory');
  }
  return { brand: parts[0], run: parts[2], output };
}

export function classifyResponse(value, status, mimeType) {
  let url;
  try { url = new URL(value); } catch { return null; }
  if (url.protocol !== 'https:' || !Number.isInteger(status) || status < 200 || status > 599) return null;
  const mime = String(mimeType || '').split(';', 1)[0].trim().toLowerCase();
  if (mime === 'application/json' || mime.endsWith('+json')) return { kind: 'json', extension: '.json' };
  if (mime.startsWith('image/')) {
    const extensions = { jpeg: '.jpg', png: '.png', webp: '.webp', gif: '.gif', svg: '.svg', 'svg+xml': '.svg', avif: '.avif', bmp: '.bmp' };
    return { kind: 'image', extension: extensions[mime.slice(6)] || '.img' };
  }
  if (mime === 'text/html') return { kind: 'html', extension: '.html' };
  if (mime.startsWith('text/')) return { kind: 'text', extension: '.txt' };
  if (mime.includes('javascript')) return { kind: 'script', extension: '.js' };
  if (mime === 'application/xml' || mime.endsWith('+xml')) return { kind: 'xml', extension: '.xml' };
  return { kind: 'binary', extension: '.bin' };
}
