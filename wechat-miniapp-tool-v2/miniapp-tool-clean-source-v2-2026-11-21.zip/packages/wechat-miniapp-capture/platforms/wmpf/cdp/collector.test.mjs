import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { WebSocketServer } from 'ws';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

test('collector waits for AppID and saves full allowlisted body', async () => {
  const scratch = path.resolve('.test-tmp');
  fs.mkdirSync(scratch, { recursive: true });
  const root = fs.mkdtempSync(path.join(scratch, 'cdp-'));
  const server = new WebSocketServer({ host: '127.0.0.1', port: 0 });
  await new Promise((resolve) => server.once('listening', resolve));
  const port = server.address().port;
  const appId = 'wx8bbfe86bc49963ff';
  let child;
  server.on('connection', (socket) => {
    socket.on('message', (bytes) => {
      const message = JSON.parse(bytes.toString());
      const reply = (result) => socket.send(JSON.stringify({ id: message.id, result }));
      if (message.method === 'Runtime.enable') return; // WMPF can omit this optional reply.
      if (message.method === 'Runtime.evaluate')
        reply({ result: { value: message.params.contextId === 4 ? appId : '' } });
      else if (message.method === 'Network.enable') {
        reply({});
        setTimeout(() => {
          socket.send(JSON.stringify({ method: 'Network.responseReceived', params: { requestId: 'r1', response: { url: 'https://consumer-api.quncrm.com/v2/ec/products/123?token=private', status: 200, requestHeaders: { secret: 'no-save' } } } }));
          socket.send(JSON.stringify({ method: 'Network.loadingFinished', params: { requestId: 'r1' } }));
        }, 30);
      } else if (message.method === 'Network.getResponseBody')
        reply({ body: JSON.stringify({ product: { id: '123', description: 'x'.repeat(90000) } }), base64Encoded: false });
      else reply({});
    });
  });
  try {
    child = spawn(process.execPath, ['platforms/wmpf/cdp/collector.mjs', '--app-id', appId, '--output', root, '--url', `ws://127.0.0.1:${port}`, '--timeout', '5000'], { cwd: process.cwd(), stdio: 'pipe' });
    let files = [];
    for (let n = 0; n < 100; n += 1) {
      files = fs.readdirSync(root).filter((name) => name.endsWith('.json') && name !== 'ready.json');
      if (files.length) break;
      await delay(50);
    }
    assert.equal(files.length, 1);
    assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'ready.json'), 'utf8')).appId, appId);
    const body = fs.readFileSync(path.join(root, files[0]), 'utf8');
    assert.equal(JSON.parse(body).data.product.description.length, 90000);
    assert.equal(body.includes('private'), false);
    assert.equal(body.includes('no-save'), false);
  } finally {
    child?.kill();
    await new Promise((resolve) => server.close(resolve));
    if (!path.resolve(root).startsWith(scratch + path.sep)) throw new Error('unsafe cleanup target');
    fs.rmSync(root, { recursive: true, force: true });
  }
});

test('stale ready file cannot bypass AppID gate', async () => {
  const scratch = path.resolve('.test-tmp');
  fs.mkdirSync(scratch, { recursive: true });
  const root = fs.mkdtempSync(path.join(scratch, 'stale-ready-'));
  fs.writeFileSync(path.join(root, 'ready.json'), '{"appId":"stale"}');
  const server = new WebSocketServer({ host: '127.0.0.1', port: 0 });
  await new Promise((resolve) => server.once('listening', resolve));
  let child;
  server.on('connection', (socket) => {
    socket.on('message', (bytes) => {
      const message = JSON.parse(bytes.toString());
      const result = message.method === 'Runtime.evaluate'
        ? { result: { value: 'wrong-app' } }
        : message.method === 'Network.getResponseBody'
          ? { body: '{"product":{"id":"123"}}', base64Encoded: false }
          : {};
      socket.send(JSON.stringify({ id: message.id, result }));
      if (message.method === 'Runtime.enable') {
        socket.send(JSON.stringify({ method: 'Network.responseReceived', params: { requestId: 'r1', response: { url: 'https://consumer-api.quncrm.com/v2/ec/products/123', status: 200 } } }));
        socket.send(JSON.stringify({ method: 'Network.loadingFinished', params: { requestId: 'r1' } }));
      }
    });
  });
  try {
    child = spawn(process.execPath, ['platforms/wmpf/cdp/collector.mjs', '--app-id', 'wx8bbfe86bc49963ff', '--output', root, '--url', `ws://127.0.0.1:${server.address().port}`, '--timeout', '1000'], { cwd: process.cwd(), stdio: 'pipe' });
    await delay(400);
    assert.equal(fs.readdirSync(root).filter((name) => name.endsWith('.json') && name !== 'ready.json').length, 0);
  } finally {
    child?.kill();
    await new Promise((resolve) => server.close(resolve));
    if (!path.resolve(root).startsWith(scratch + path.sep)) throw new Error('unsafe cleanup target');
    fs.rmSync(root, { recursive: true, force: true });
  }
});
