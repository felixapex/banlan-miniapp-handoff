import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const productPath = /^\/v2\/ec\/(?:products\/[^/]+$|weappPages\/[0-9a-f]{24}$|searchStoreProducts$|searchProducts$|storeProducts$)|^\/apps\/natuzziorder\/(?:product\/|productSlice\/)/;

export function isProductUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.hostname !== 'consumer-api.quncrm.com') return false;
    if (productPath.test(url.pathname)) return true;
    if (url.pathname === '/modules/implcommon/setting/detail')
      return url.searchParams.get('campaignId') === 'natuzzi-data-source';
    return ['/apps/forum/articles/searchFromDB', '/modules/forum/content-tag-groups'].includes(url.pathname);
  } catch { return false; }
}

export function cleanAssetUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.hostname !== 'statics.maiscrm.com') return null;
    if (!/\.(?:jpe?g|png|webp|gif|svg)$/i.test(url.pathname)) return null;
    return `${url.origin}${url.pathname}`;
  } catch { return null; }
}

export function saveProductBody(outputDir, meta, body) {
  if (meta.status !== 200 || !isProductUrl(meta.url)) throw new Error('response is outside product allowlist');
  const data = JSON.parse(body);
  fs.mkdirSync(outputDir, { recursive: true });
  const filename = `${new Date().toISOString().replace(/[:.]/g, '-')}-${randomUUID()}.json`;
  const pathname = new URL(meta.url).pathname;
  fs.writeFileSync(path.join(outputDir, filename), JSON.stringify({ path: pathname, status: meta.status, data }, null, 2), { flag: 'wx' });
  return filename;
}
