import assert from 'node:assert/strict';
import test from 'node:test';
import { readRequestedVersion, selectRuntime } from './runtime.mjs';

const root = { pid: 30, name: 'WeChatAppEx.exe', parameters: { ppid: 2n, argv: ['--flue-runtime-dir=C:\\Tencent\\RadiumWMPF\\26506\\extracted\\runtime'] } };
const child = { pid: 31, name: 'WeChatAppEx.exe', parameters: { ppid: 30n, argv: root.parameters.argv } };

test('selects one WMPF root and its exact supported version', () => {
  assert.deepEqual(selectRuntime([child, root], 26506), { pid: 30, version: 26506 });
  assert.throws(() => selectRuntime([root], 26509), /unsupported version/);
  assert.throws(() => selectRuntime([root, { ...root, pid: 40 }], 26506), /one WMPF root/);
});

test('accepts only explicitly supported WMPF versions', () => {
  assert.equal(readRequestedVersion(['node', 'server.mjs']), 26506);
  assert.equal(readRequestedVersion(['node', 'server.mjs', '--version', '26134']), 26134);
  assert.throws(() => readRequestedVersion(['node', 'server.mjs', '--version', '26509']), /unsupported version/);
  assert.throws(() => readRequestedVersion(['node', 'server.mjs', '--version']), /unsupported version/);
});
