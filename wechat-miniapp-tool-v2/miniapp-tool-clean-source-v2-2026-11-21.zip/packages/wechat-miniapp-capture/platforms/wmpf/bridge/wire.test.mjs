import assert from 'node:assert/strict';
import { deflateSync } from 'node:zlib';
import test from 'node:test';
import { decodeResult, encodeCommand, encodeEnvelope } from './wire.mjs';

const referenceCommand = '08011a0e6368726f6d65446576746f6f6c73221a080712147b226964223a312c22726573756c74223a7b7d7d1a0028003000';
const referenceResult = '08011a146368726f6d65446576746f6f6c73526573756c74221a080712147b226964223a312c22726573756c74223a7b7d7d1a0028003000';

test('encodes a CDP command using the observed WMPF wire format', () => {
  assert.equal(encodeCommand('{"id":1,"result":{}}', 1, 7).toString('hex'), referenceCommand);
});

test('decodes a CDP response and ignores unrelated categories', () => {
  assert.equal(decodeResult(Buffer.from(referenceResult, 'hex')), '{"id":1,"result":{}}');
  assert.equal(decodeResult(Buffer.from(referenceCommand, 'hex')), null);
});

test('accepts compressed response and rejects malformed payload', () => {
  const inner = Buffer.from('12147b226964223a312c22726573756c74223a7b7d7d', 'hex');
  const compressed = encodeEnvelope('chromeDevtoolsResult', deflateSync(inner), 1, 1, inner.length);
  assert.equal(decodeResult(compressed), '{"id":1,"result":{}}');
  assert.throws(() => decodeResult(Buffer.from('1a05', 'hex')), /truncated/);
});
