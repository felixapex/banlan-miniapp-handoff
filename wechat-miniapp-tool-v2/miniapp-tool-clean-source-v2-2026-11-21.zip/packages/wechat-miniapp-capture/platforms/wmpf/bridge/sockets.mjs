import WebSocket, { WebSocketServer } from 'ws';
import { decodeResult, encodeCommand } from './wire.mjs';

const MAX_FRAME = 16 * 1024 * 1024;

function listening(server) {
  return new Promise((resolve, reject) => {
    if (server.address()) return resolve();
    server.once('listening', resolve);
    server.once('error', reject);
  });
}

function closeServer(server) {
  for (const client of server.clients) client.terminate();
  return new Promise((resolve) => server.close(resolve));
}

export async function createSockets({ miniappPort = 9421, cdpPort = 62000, log = () => {} } = {}) {
  const miniappServer = new WebSocketServer({ host: '127.0.0.1', port: miniappPort, maxPayload: MAX_FRAME });
  const cdpServer = new WebSocketServer({ host: '127.0.0.1', port: cdpPort, maxPayload: MAX_FRAME });
  try {
    await Promise.all([listening(miniappServer), listening(cdpServer)]);
  } catch (error) {
    await Promise.allSettled([closeServer(miniappServer), closeServer(cdpServer)]);
    throw error;
  }
  let miniapp = null;
  let cdp = null;
  let sequence = 0;
  let operationId = 0;
  const setupCommands = new Map();

  function forwardCommand(command) {
    sequence += 1;
    operationId += 1;
    miniapp.send(encodeCommand(command, sequence, operationId));
  }

  miniappServer.on('connection', (socket) => {
    if (miniapp?.readyState === WebSocket.OPEN) {
      socket.close(1013, 'another miniapp is connected');
      return;
    }
    miniapp = socket;
    log('miniapp connected');
    for (const command of setupCommands.values()) forwardCommand(command);
    socket.on('message', (frame) => {
      try {
        const result = decodeResult(frame);
        if (result !== null && cdp?.readyState === WebSocket.OPEN) cdp.send(result);
      } catch (error) { log(`miniapp frame rejected: ${error.message}`); }
    });
    socket.on('close', () => {
      if (miniapp === socket) {
        miniapp = null;
        if (cdp?.readyState === WebSocket.OPEN) cdp.close(1011, 'miniapp disconnected');
      }
      log('miniapp disconnected');
    });
    socket.on('error', (error) => log(`miniapp socket error: ${error.message}`));
  });

  cdpServer.on('connection', (socket) => {
    if (cdp?.readyState === WebSocket.OPEN) {
      socket.close(1013, 'CDP client is already connected');
      return;
    }
    cdp = socket;
    setupCommands.clear();
    log('CDP client connected');
    socket.on('message', (frame) => {
      try {
        const command = frame.toString('utf8');
        const parsed = JSON.parse(command);
        if (!Number.isSafeInteger(parsed.id) || typeof parsed.method !== 'string') return;
        if (parsed.method === 'Network.enable' || parsed.method === 'Runtime.enable')
          setupCommands.set(parsed.method, command);
        if (miniapp?.readyState === WebSocket.OPEN) forwardCommand(command);
      } catch (error) { log(`CDP command rejected: ${error.message}`); }
    });
    socket.on('close', () => {
      if (cdp === socket) { cdp = null; setupCommands.clear(); }
      log('CDP client disconnected');
    });
    socket.on('error', (error) => log(`CDP socket error: ${error.message}`));
  });

  return {
    miniappPort: miniappServer.address().port,
    cdpPort: cdpServer.address().port,
    close: () => Promise.all([closeServer(miniappServer), closeServer(cdpServer)]),
  };
}
