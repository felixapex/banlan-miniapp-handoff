import { inflateSync } from 'node:zlib';

const MAX_MESSAGE = 16 * 1024 * 1024;

function varint(value) {
  if (!Number.isSafeInteger(value) || value < 0) throw new RangeError('invalid wire integer');
  let remaining = BigInt(value);
  const bytes = [];
  do {
    let byte = Number(remaining & 0x7fn);
    remaining >>= 7n;
    if (remaining) byte |= 0x80;
    bytes.push(byte);
  } while (remaining);
  return Buffer.from(bytes);
}

function numberField(field, value) {
  return Buffer.concat([varint(field * 8), varint(value)]);
}

function bytesField(field, value) {
  const bytes = Buffer.from(value);
  return Buffer.concat([varint(field * 8 + 2), varint(bytes.length), bytes]);
}

function readVarint(buffer, cursor) {
  let value = 0n;
  for (let shift = 0n; shift < 70n; shift += 7n) {
    if (cursor.index >= buffer.length) throw new Error('truncated wire integer');
    const byte = buffer[cursor.index++];
    value |= BigInt(byte & 0x7f) << shift;
    if (!(byte & 0x80)) {
      if (value > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('wire integer too large');
      return Number(value);
    }
  }
  throw new Error('wire integer too long');
}

function readFields(input) {
  const buffer = Buffer.from(input);
  if (buffer.length > MAX_MESSAGE) throw new Error('wire message too large');
  const fields = new Map();
  const cursor = { index: 0 };
  while (cursor.index < buffer.length) {
    const tag = readVarint(buffer, cursor);
    const field = Math.floor(tag / 8);
    const kind = tag & 7;
    if (!field) throw new Error('invalid wire field');
    let value;
    if (kind === 0) value = readVarint(buffer, cursor);
    else if (kind === 2) {
      const length = readVarint(buffer, cursor);
      if (length > buffer.length - cursor.index) throw new Error('truncated wire bytes');
      value = buffer.subarray(cursor.index, cursor.index + length);
      cursor.index += length;
    } else if (kind === 1 || kind === 5) {
      const length = kind === 1 ? 8 : 4;
      if (length > buffer.length - cursor.index) throw new Error('truncated wire value');
      cursor.index += length;
      continue;
    } else throw new Error('unsupported wire type');
    fields.set(field, value);
  }
  return fields;
}

export function encodeEnvelope(category, data, sequence, compression = 0, originalSize = 0) {
  return Buffer.concat([
    numberField(1, sequence),
    bytesField(3, Buffer.from(category, 'utf8')),
    bytesField(4, data),
    numberField(5, compression),
    numberField(6, originalSize),
  ]);
}

export function encodeCommand(json, sequence, operationId) {
  if (typeof json !== 'string') throw new TypeError('CDP command must be text');
  const payload = Buffer.concat([
    numberField(1, operationId),
    bytesField(2, Buffer.from(json, 'utf8')),
    bytesField(3, Buffer.alloc(0)),
  ]);
  return encodeEnvelope('chromeDevtools', payload, sequence);
}

export function decodeResult(frame) {
  const envelope = readFields(frame);
  if (envelope.get(3)?.toString('utf8') !== 'chromeDevtoolsResult') return null;
  let data = envelope.get(4);
  if (!Buffer.isBuffer(data)) throw new Error('CDP response payload missing');
  const compression = envelope.get(5) || 0;
  if (compression & 1) data = inflateSync(data, { maxOutputLength: MAX_MESSAGE });
  else if (compression) throw new Error('unsupported CDP compression');
  const expected = envelope.get(6) || 0;
  if (expected && data.length !== expected) throw new Error('CDP size mismatch');
  const payload = readFields(data).get(2);
  if (!Buffer.isBuffer(payload)) throw new Error('CDP result text missing');
  return payload.toString('utf8');
}
