import assert from 'node:assert/strict';
import test from 'node:test';
import WebSocket from 'ws';
import { createSockets } from './sockets.mjs';

const referenceResult = Buffer.from('08011a146368726f6d65446576746f6f6c73526573756c74221a080712147b226964223a312c22726573756c74223a7b7d7d1a0028003000', 'hex');
const referenceCommand = '08011a0e6368726f6d65446576746f6f6c732228080112227b226964223a312c226d6574686f64223a2252756e74696d652e656e61626c65227d1a0028003000';

function connect(port) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`);
    socket.once('open', () => resolve(socket));
    socket.once('error', reject);
  });
}

test('local proxy carries CDP in both directions without logging content', async () => {
  const bridge = await createSockets({ miniappPort: 0, cdpPort: 0, log() {} });
  let miniapp;
  let cdp;
  try {
    miniapp = await connect(bridge.miniappPort);
    cdp = await connect(bridge.cdpPort);
    const fromMiniapp = new Promise((resolve) => cdp.once('message', (bytes) => resolve(bytes.toString())));
    miniapp.send(referenceResult);
    assert.equal(await fromMiniapp, '{"id":1,"result":{}}');
    const toMiniapp = new Promise((resolve) => miniapp.once('message', (bytes) => resolve(bytes.toString('hex'))));
    cdp.send('{"id":1,"method":"Runtime.enable"}');
    assert.equal(await toMiniapp, referenceCommand);
  } finally {
    miniapp?.close();
    cdp?.close();
    await bridge.close();
  }
});

test('replays network subscription when miniapp connects after collector', { timeout: 3000 }, async () => {
  const bridge = await createSockets({ miniappPort: 0, cdpPort: 0, log() {} });
  let miniapp;
  let cdp;
  try {
    cdp = await connect(bridge.cdpPort);
    cdp.send('{"id":17,"method":"Network.enable"}');
    await new Promise(resolve => setTimeout(resolve, 30));
    miniapp = new WebSocket(`ws://127.0.0.1:${bridge.miniappPort}`);
    const firstMessage = new Promise(resolve => miniapp.once('message', resolve));
    await new Promise((resolve, reject) => {
      miniapp.once('open', resolve);
      miniapp.once('error', reject);
    });
    const frame = await Promise.race([
      firstMessage,
      new Promise((_, reject) => setTimeout(() => reject(new Error('subscription was not replayed')), 500)),
    ]);
    assert.ok(frame.includes(Buffer.from('"method":"Network.enable"')));
  } finally {
    miniapp?.close();
    cdp?.close();
    await bridge.close();
  }
});
