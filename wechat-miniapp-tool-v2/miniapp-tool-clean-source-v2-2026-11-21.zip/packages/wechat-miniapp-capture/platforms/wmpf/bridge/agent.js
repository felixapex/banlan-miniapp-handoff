// Offset data is supplied only for an explicitly verified WMPF version.
const settings = __SETTINGS__;
const moduleInfo = Process.findModuleByName('flue.dll');
if (!moduleInfo) throw new Error('flue.dll is not loaded');

function location(hex) {
  const offset = Number.parseInt(hex, 16);
  if (!Number.isSafeInteger(offset) || offset < 0 || offset >= moduleInfo.size)
    throw new Error('hook offset is outside flue.dll');
  return moduleInfo.base.add(offset);
}

function follow(start, offsets) {
  let current = start;
  for (const offset of offsets) {
    current = current.add(offset).readPointer();
    if (current.isNull()) throw new Error('null WMPF configuration pointer');
  }
  return current;
}

const launchScenes = new Set([1000, 1005, 1007, 1008, 1011, 1012, 1027, 1035, 1037, 1053, 1074, 1145, 1178, 1183, 1256, 1260, 1302, 1308]);
const localUrl = 'ws://127.0.0.1:9421';
const observedScenes = new Set();

function enableDebugging(args) {
  const launch = follow(args[0], settings.launchPointers);
  const debug = follow(launch, settings.debugPointers);
  const scene = debug.add(settings.scene);
  const observed = scene.readS32();
  if (!observedScenes.has(observed)) {
    observedScenes.add(observed);
    send({ type: 'miniapp-scene-observed', scene: observed, supported: launchScenes.has(observed) });
  }
  if (!launchScenes.has(observed)) return;

  const address = launch.add(settings.backChannel);
  if (address.add(23).readS8() < 0) {
    address.readPointer().writeUtf8String(localUrl);
    address.add(8).writeU64(localUrl.length);
  } else {
    address.writeUtf8String(localUrl);
    address.add(23).writeU8(localUrl.length);
  }
  debug.add(settings.debugMode).writeS32(1);
  scene.writeS32(1101);
  args[1] = args[1].and(ptr('0xffffffffffffff00')).or(ptr(1));
  send({ type: 'miniapp-debug-enabled', scene: observed });
}

const cast = new NativeFunction(location(settings.cborToJson), 'pointer', ['pointer', 'pointer']);
const replacement = new NativeCallback((self, output, input) => {
  cast(output, input);
  return output;
}, 'pointer', ['pointer', 'pointer', 'pointer']);
globalThis.__miniappFilterReplacement = replacement;
Interceptor.replace(location(settings.cdpFilter), replacement);
Interceptor.attach(location(settings.loadEntry), {
  onEnter(args) {
    try { enableDebugging(args); }
    catch (error) { send({ type: 'miniapp-hook-error', message: String(error) }); }
  },
});
send({ type: 'agent-ready' });
