import { readFile } from 'node:fs/promises';
import * as frida from 'frida';
import { createSockets } from './sockets.mjs';
import { readRequestedVersion, selectRuntime } from './runtime.mjs';

const requestedVersion = readRequestedVersion(process.argv);
const offsets = JSON.parse(await readFile(new URL(`./windows-wmpf-${requestedVersion}.json`, import.meta.url), 'utf8'));
if (offsets.version !== requestedVersion) throw new Error('WMPF offset file version mismatch');

async function detect(device) {
  const processes = await device.enumerateProcesses({ scope: frida.Scope.Metadata });
  return selectRuntime(processes, offsets.version);
}

async function start() {
  const device = await frida.getLocalDevice();
  const target = await detect(device);
  if (process.argv.includes('--probe')) {
    console.log(`runtime ready version=${target.version} pid=${target.pid}`);
    return;
  }

  let sockets;
  let session;
  let script;
  try {
    sockets = await createSockets({ log: (message) => console.log(`bridge: ${message}`) });
    session = await device.attach(target.pid);
    const source = await readFile(new URL('./agent.js', import.meta.url), 'utf8');
    script = await session.createScript(source.replace('__SETTINGS__', JSON.stringify(offsets)));
    let ready = false;
    script.message.connect((message) => {
      if (message.type === 'error') {
        console.error(`agent error: ${message.description}`);
        return;
      }
      const payload = message.payload;
      if (payload?.type === 'agent-ready') ready = true;
      else if (payload?.type === 'miniapp-scene-observed') console.log(`bridge: miniapp scene ${payload.scene} observed supported=${payload.supported}`);
      else if (payload?.type === 'miniapp-debug-enabled') console.log(`bridge: miniapp scene ${payload.scene} enabled`);
      else if (payload?.type === 'miniapp-hook-error') console.error(`bridge: hook error ${payload.message}`);
    });
    await script.load();
    for (let attempt = 0; attempt < 20 && !ready; attempt += 1)
      await new Promise((resolve) => setTimeout(resolve, 100));
    if (!ready) throw new Error('native hook did not report ready');
    console.log(`bridge ready version=${target.version} pid=${target.pid} miniapp=${sockets.miniappPort} cdp=${sockets.cdpPort}`);
  } catch (error) {
    if (script) await script.unload().catch(() => {});
    if (session) await session.detach().catch(() => {});
    if (sockets) await sockets.close();
    throw error;
  }
  const stop = async () => {
    await sockets.close();
    await script.unload().catch(() => {});
    await session.detach().catch(() => {});
    process.exit(0);
  };
  process.once('SIGINT', () => { void stop(); });
  process.once('SIGTERM', () => { void stop(); });
}

start().catch((error) => { console.error(`bridge error: ${error.message}`); process.exitCode = 1; });
