export function selectRuntime(processes, supportedVersion) {
  const candidates = processes.filter((process) => process.name === 'WeChatAppEx.exe');
  const pids = new Set(candidates.map((process) => Number(process.pid)));
  const roots = candidates.filter((process) => !pids.has(Number(process.parameters?.ppid)));
  if (roots.length !== 1) throw new Error(`expected one WMPF root process; found ${roots.length}`);
  const runtime = roots[0].parameters?.argv?.find((argument) => argument.startsWith('--flue-runtime-dir='));
  const match = runtime?.match(/[\\/]RadiumWMPF[\\/](\d+)[\\/]/i);
  const version = match ? Number(match[1]) : 0;
  if (version !== supportedVersion) throw new Error(`unsupported version ${version}; expected ${supportedVersion}`);
  return { pid: Number(roots[0].pid), version };
}

export function readRequestedVersion(argv) {
  const index = argv.indexOf('--version');
  const version = index < 0 ? 26506 : Number(argv[index + 1]);
  if (!Number.isInteger(version) || ![26134, 26506].includes(version)) {
    throw new Error(`unsupported version ${version}`);
  }
  return version;
}
