import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';

import { capturePublic, validateOptions } from './public_web_capture.mjs';

const packageDir = path.dirname(fileURLToPath(import.meta.url));
const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScL/nwAAAABJRU5ErkJggg==', 'base64');

test('preflight rejects share codes, Edge, C drive output and credential URLs', () => {
  const output = path.join(packageDir, 'new-public-output');
  assert.throws(() => validateOptions({ url: '#小程序://班兰/QWrl0vfR4c04F3j', output, chromePath }), /HTTP/i);
  assert.throws(() => validateOptions({ url: 'https://example.com/', output, chromePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe' }), /Chrome/i);
  assert.throws(() => validateOptions({ url: 'https://example.com/', output: 'C:\\unsafe', chromePath }), /E:/);
  assert.throws(() => validateOptions({ url: 'https://user:pass@example.com/', output, chromePath }), /credential/i);
  assert.throws(() => validateOptions({ url: 'https://example.com/checkout', output, chromePath }), /unsafe/i);
});

test('isolated Chrome captures two public pages, their text, JSON and original image bytes', { timeout: 60000 }, async t => {
  if (!fs.existsSync(chromePath)) return t.skip('Google Chrome is not installed at the isolated test path');
  const root = fs.mkdtempSync(path.join(packageDir, '.public-capture-test-'));
  const server = http.createServer((request, response) => {
    if (request.url === '/api/products') {
      response.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
      response.end(JSON.stringify({ products: [{ id: 'p1', title: '测试沙发' }] }));
    } else if (request.url === '/image.png') {
      response.writeHead(200, { 'content-type': 'image/png' });
      response.end(png);
    } else if (request.url === '/item') {
      response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      response.end('<!doctype html><html><body><h1>商品详情</h1><p>测试沙发</p><img src="/image.png" alt="商品原图"></body></html>');
    } else {
      response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      response.end('<!doctype html><html><body><h1>商品列表</h1><a href="/item">商品详情</a><img src="/image.png" alt="封面"><script>fetch("/api/products").then(r=>r.json()).then(d=>document.body.insertAdjacentHTML("beforeend","<p>"+d.products[0].title+"</p>"))</script></body></html>');
    }
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(async () => {
    await new Promise(resolve => server.close(resolve));
    if (!path.resolve(root).startsWith(packageDir + path.sep)) throw new Error('unsafe temp cleanup path');
    fs.rmSync(root, { recursive: true, force: true });
  });
  const output = path.join(root, 'new-brand', 'runs', 'capture');
  const url = `http://127.0.0.1:${server.address().port}/`;
  const manifest = await capturePublic({ url, output, chromePath, maxPages: 2 });
  assert.equal(manifest.pages.length, 2);
  assert.notEqual(manifest.pages[0].screenshot, manifest.pages[1].screenshot);
  assert.match(JSON.parse(fs.readFileSync(path.join(output, manifest.pages[0].data), 'utf8')).text, /商品列表/);
  assert.match(JSON.parse(fs.readFileSync(path.join(output, manifest.pages[1].data), 'utf8')).text, /商品详情/);
  for (const page of manifest.pages) {
    const screenshot = fs.readFileSync(path.join(output, page.screenshot));
    const data = fs.readFileSync(path.join(output, page.data));
    assert.ok(screenshot.subarray(0, 8).equals(png.subarray(0, 8)));
    assert.equal(page.screenshotSha256, crypto.createHash('sha256').update(screenshot).digest('hex'));
    assert.equal(page.dataSha256, crypto.createHash('sha256').update(data).digest('hex'));
  }
  const image = manifest.responses.find(item => item.url.endsWith('/image.png') && item.file);
  const data = manifest.responses.find(item => item.url.endsWith('/api/products') && item.file);
  assert.ok(image);
  assert.ok(data);
  assert.deepEqual(fs.readFileSync(path.join(output, image.file)), png);
  assert.equal(image.sha256, crypto.createHash('sha256').update(png).digest('hex'));
  assert.equal(JSON.parse(fs.readFileSync(path.join(output, data.file), 'utf8')).products[0].title, '测试沙发');
  assert.equal(manifest.browserClosed, true);
  assert.equal(manifest.success, true);
});
