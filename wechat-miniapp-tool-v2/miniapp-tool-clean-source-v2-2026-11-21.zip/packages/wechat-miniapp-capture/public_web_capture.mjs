/** Capture only public web pages with a fresh, isolated Google Chrome profile. */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright-core';

const packageDir = path.dirname(fileURLToPath(import.meta.url));
const workspaceRoot = path.resolve(packageDir, '../..');
const blockedNavigation = /(?:^|[/?#-])(login|logout|signout|account|checkout|payment|pay|purchase|buy|delete|remove|unsubscribe|cart|order|register)(?:[/?#-]|$)/i;
const MAX_RESPONSE_BYTES = 15 * 1024 * 1024;
const MAX_TOTAL_BYTES = 250 * 1024 * 1024;
const MAX_RESPONSES = 300;

export function validateOptions({ url, output, chromePath, maxPages = 1 }) {
  let target;
  try { target = new URL(url); } catch { throw new Error('Expected an HTTP(S) public web URL, not a miniapp share code'); }
  const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(target.hostname);
  if (target.protocol !== 'https:' && !(target.protocol === 'http:' && loopback))
    throw new Error('Expected an HTTPS public web URL; HTTP is allowed only for a local test server');
  if (target.username || target.password) throw new Error('Credential URLs are not allowed');
  if (!target.hostname) throw new Error('URL must have a hostname');
  if (blockedNavigation.test(target.pathname)) throw new Error('Unsafe navigation path');
  if (typeof output !== 'string' || !/^[Ee]:[\\/]/.test(output)) throw new Error('Output must be an E: directory');
  const destination = path.resolve(output);
  if (!destination.startsWith(workspaceRoot + path.sep)) throw new Error('Output must be inside the E: workspace');
  if (fs.existsSync(destination)) throw new Error('Output must be a new directory');
  if (typeof chromePath !== 'string' || path.basename(chromePath).toLowerCase() !== 'chrome.exe' || !fs.existsSync(chromePath))
    throw new Error('An installed Google Chrome executable is required; Edge is forbidden');
  if (!Number.isInteger(maxPages) || maxPages < 1 || maxPages > 20) throw new Error('maxPages must be 1..20');
  target.hash = '';
  return { url: target.href, origin: target.origin, output: destination, chromePath: path.resolve(chromePath), maxPages };
}

function safePageLink(value, text, origin) {
  let target;
  try { target = new URL(value); } catch { return null; }
  if (target.origin !== origin || !['http:', 'https:'].includes(target.protocol)) return null;
  if (target.username || target.password || blockedNavigation.test(target.pathname) || blockedNavigation.test(text)) return null;
  target.hash = '';
  return target.href;
}

function extension(contentType) {
  if (/json/.test(contentType)) return 'json';
  if (/svg/.test(contentType)) return 'svg';
  if (/png/.test(contentType)) return 'png';
  if (/jpe?g/.test(contentType)) return 'jpg';
  if (/webp/.test(contentType)) return 'webp';
  if (/gif/.test(contentType)) return 'gif';
  if (/avif/.test(contentType)) return 'avif';
  return 'bin';
}

export async function capturePublic(options) {
  const selected = validateOptions(options);
  const { output, origin, maxPages } = selected;
  fs.mkdirSync(output, { recursive: true });
  for (const folder of ['screenshots', 'pages', 'assets', 'responses', 'browser-profile', 'tmp', 'appdata'])
    fs.mkdirSync(path.join(output, folder));
  const manifest = {
    kind: 'bounded-public-web-capture', sourceUrl: selected.url, pages: [], responses: [], errors: [],
    limits: { maxPages, maxResponses: MAX_RESPONSES, maxResponseBytes: MAX_RESPONSE_BYTES, maxTotalBytes: MAX_TOTAL_BYTES },
    completeMiniapp: false, browserClosed: false, stopReason: null, success: false,
  };
  let context;
  let totalBytes = 0;
  const pending = new Set();
  const seenResponse = new Set();
  const saveManifest = () => fs.writeFileSync(path.join(output, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
  async function saveResponse(response) {
    const request = response.request();
    if (request.method() !== 'GET' || response.status() !== 200) return;
    const responseUrl = response.url();
    if (!/^https?:/.test(responseUrl) || seenResponse.has(responseUrl) || manifest.responses.length >= MAX_RESPONSES) return;
    const contentType = (response.headers()['content-type'] || '').toLowerCase();
    const image = contentType.startsWith('image/');
    const json = contentType.includes('json');
    if (!image && !(json && new URL(responseUrl).origin === origin)) return;
    const length = Number(response.headers()['content-length']);
    if (Number.isFinite(length) && length > MAX_RESPONSE_BYTES) return;
    try {
      const bytes = await response.body();
      if (bytes.length > MAX_RESPONSE_BYTES || totalBytes + bytes.length > MAX_TOTAL_BYTES) return;
      const hash = crypto.createHash('sha256').update(bytes).digest('hex');
      const file = `${image ? 'assets' : 'responses'}/${hash}.${extension(contentType)}`;
      const location = path.join(output, file);
      if (!fs.existsSync(location)) await fs.promises.writeFile(location, bytes);
      seenResponse.add(responseUrl);
      totalBytes += bytes.length;
      manifest.responses.push({ url: responseUrl, status: 200, contentType, file, bytes: bytes.length, sha256: hash });
    } catch (error) {
      manifest.errors.push({ url: responseUrl, error: String(error.message || error) });
    }
  }
  try {
    context = await chromium.launchPersistentContext(path.join(output, 'browser-profile'), {
      executablePath: selected.chromePath, headless: true, viewport: { width: 390, height: 844 },
      serviceWorkers: 'block', acceptDownloads: false,
      args: ['--no-first-run', '--disable-extensions', '--disable-sync', '--disable-background-networking'],
      env: { ...process.env, TEMP: path.join(output, 'tmp'), TMP: path.join(output, 'tmp'), LOCALAPPDATA: path.join(output, 'appdata') },
    });
    context.on('response', response => {
      const work = saveResponse(response).finally(() => pending.delete(work));
      pending.add(work);
    });
    const page = context.pages()[0] || await context.newPage();
    const queue = [selected.url];
    const seenPages = new Set();
    while (queue.length && manifest.pages.length < maxPages) {
      const target = queue.shift();
      if (seenPages.has(target)) continue;
      seenPages.add(target);
      try {
        await page.goto(target, { waitUntil: 'domcontentloaded', timeout: 25000 });
        const finalUrl = new URL(page.url());
        if (finalUrl.origin !== origin || blockedNavigation.test(finalUrl.pathname))
          throw new Error('Navigation redirected outside the safe public origin or path');
        await page.waitForTimeout(500);
        for (let step = 0; step < 20; step++) {
          const moved = await page.evaluate(() => {
            const previous = scrollY;
            scrollBy(0, Math.max(300, innerHeight * 0.8));
            return scrollY > previous;
          });
          if (!moved) break;
          await page.waitForTimeout(120);
        }
        await page.evaluate(() => scrollTo(0, 0));
        await page.waitForTimeout(150);
        const number = String(manifest.pages.length + 1).padStart(4, '0');
        const screenshot = `screenshots/${number}.png`;
        const dataFile = `pages/${number}.json`;
        await page.screenshot({ path: path.join(output, screenshot), fullPage: true, animations: 'disabled' });
        const data = await page.evaluate(() => ({
          url: location.href, title: document.title, text: document.body?.innerText || '',
          images: Array.from(document.images, item => ({ src: item.currentSrc || item.src, alt: item.alt, width: item.naturalWidth, height: item.naturalHeight })),
          links: Array.from(document.querySelectorAll('a[href]'), item => ({ href: item.href, text: item.innerText.trim() })),
        }));
        const dataBytes = Buffer.from(JSON.stringify(data, null, 2), 'utf8');
        fs.writeFileSync(path.join(output, dataFile), dataBytes);
        const screenshotBytes = fs.readFileSync(path.join(output, screenshot));
        manifest.pages.push({ requestedUrl: target, finalUrl: data.url, title: data.title, screenshot, data: dataFile,
          screenshotSha256: crypto.createHash('sha256').update(screenshotBytes).digest('hex'),
          dataSha256: crypto.createHash('sha256').update(dataBytes).digest('hex') });
        if (new URL(data.url).origin === origin) {
          for (const link of data.links) {
            const next = safePageLink(link.href, link.text, origin);
            if (next && !seenPages.has(next) && !queue.includes(next)) queue.push(next);
          }
        }
        await Promise.allSettled([...pending]);
        saveManifest();
      } catch (error) {
        manifest.errors.push({ url: target, error: String(error.message || error) });
        saveManifest();
      }
    }
    manifest.stopReason = queue.length ? 'page_limit' : 'no_more_safe_links';
    await Promise.allSettled([...pending]);
  } catch (error) {
    manifest.errors.push({ error: String(error.message || error) });
    manifest.stopReason = 'browser_error';
    throw error;
  } finally {
    if (context) {
      await context.close();
      manifest.browserClosed = true;
    }
    manifest.success = manifest.browserClosed && manifest.pages.length > 0 && manifest.errors.length === 0;
    saveManifest();
  }
  return manifest;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = Object.fromEntries(process.argv.slice(2).filter((_, index) => index % 2 === 0)
    .map((name, index) => [name, process.argv[3 + index * 2]]));
  capturePublic({ url: args['--url'], output: args['--output'],
    chromePath: args['--chrome'] || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    maxPages: Number(args['--max-pages'] || 1) })
    .then(result => { console.log(JSON.stringify({ pages: result.pages.length, responses: result.responses.length,
      errors: result.errors.length, stopReason: result.stopReason, success: result.success }));
      if (!result.success) process.exitCode = 1; })
    .catch(error => { console.error(`public capture error: ${error.message}`); process.exitCode = 1; });
}
