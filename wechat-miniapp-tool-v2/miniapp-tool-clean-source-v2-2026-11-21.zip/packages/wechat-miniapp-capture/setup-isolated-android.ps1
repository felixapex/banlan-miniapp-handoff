param(
    [ValidateSet('DownloadTools', 'AcceptLicenses', 'CheckAcceleration', 'InstallSdk', 'InstallImage', 'InstallArmImage', 'DownloadWeChat', 'CreateAvd', 'CreateArmAvd', 'LaunchHeadless', 'LaunchArmHeadless')]
    [string]$Step = 'DownloadTools'
)

$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\artifacts\isolated-android'))
if (-not $workspace.StartsWith('E:\', [StringComparison]::OrdinalIgnoreCase) -or
    -not $root.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'The isolated Android environment must stay on E:.'
}
$downloads = Join-Path $root 'downloads'
$sdk = Join-Path $root 'sdk'
$avd = Join-Path $root 'avd'
$tempDir = Join-Path $root 'tmp'
foreach ($dir in @($root, $downloads, $sdk, $avd, $tempDir)) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
}
$env:TEMP = $tempDir
$env:TMP = $tempDir
$env:USERPROFILE = $root
$env:HOME = $root
$env:HOMEDRIVE = 'E:'
$env:HOMEPATH = $root.Substring(2)
$env:ANDROID_HOME = $sdk
$env:ANDROID_SDK_ROOT = $sdk
$env:ANDROID_USER_HOME = $avd
$env:ANDROID_EMULATOR_HOME = $avd
$env:ANDROID_AVD_HOME = Join-Path $avd 'avd'
New-Item -ItemType Directory -Path $env:ANDROID_AVD_HOME -Force | Out-Null

function Ensure-AsciiAlias {
    $marker = Join-Path $root 'ascii-alias-root.txt'
    if (-not (Test-Path -LiteralPath 'X:\')) {
        & subst.exe X: $root
        if ($LASTEXITCODE -ne 0) { throw 'Could not map X: to the E: Android directory.' }
        [IO.File]::WriteAllText($marker, $root, [Text.UTF8Encoding]::new($false))
    }
    $mappedMarker = 'X:\ascii-alias-root.txt'
    if (-not (Test-Path -LiteralPath 'X:\sdk\emulator\emulator.exe') -or
        -not (Test-Path -LiteralPath $mappedMarker) -or
        (Get-Content -LiteralPath $mappedMarker -Raw).Trim() -ne $root) {
        throw 'X: is occupied by another directory; no emulator started.'
    }
    return 'X:\'
}

function Download-Verified([string]$Url, [string]$Name, [string]$Checksum, [string]$Algorithm = 'SHA256') {
    $path = Join-Path $downloads $Name
    if ((Test-Path -LiteralPath $path) -and (Get-FileHash -LiteralPath $path -Algorithm $Algorithm).Hash -ieq $Checksum) {
        Write-Host "Already verified: $Name"
        return $path
    }
    $part = "$path.part"
    & curl.exe --fail --location --retry 3 --retry-all-errors --retry-delay 3 --continue-at - --silent --show-error --output $part $Url
    if ($LASTEXITCODE -ne 0) { throw "Download failed: $Name" }
    $actual = (Get-FileHash -LiteralPath $part -Algorithm $Algorithm).Hash
    if ($actual -ine $Checksum) { throw "$Algorithm mismatch for $Name : $actual" }
    Move-Item -LiteralPath $part -Destination $path -Force
    Write-Host "Verified: $Name"
    return $path
}

function Download-RangedVerified([string]$Url, [string]$Name, [string]$Checksum, [long]$ExpectedLength) {
    $path = Join-Path $downloads $Name
    if ((Test-Path -LiteralPath $path) -and (Get-FileHash -LiteralPath $path -Algorithm SHA1).Hash -ieq $Checksum) {
        Write-Host "Already verified: $Name"
        return $path
    }
    $partCount = 4
    $chunkSize = [long][Math]::Ceiling($ExpectedLength / $partCount)
    $parts = @()
    $arguments = @('--parallel', '--parallel-immediate', '--parallel-max', '4')
    $queued = 0
    for ($index = 0; $index -lt $partCount; $index++) {
        $start = [long]$index * $chunkSize
        $end = [long][Math]::Min($ExpectedLength - 1, $start + $chunkSize - 1)
        $part = "$path.part$index"
        $expectedPartLength = $end - $start + 1
        $parts += [pscustomobject]@{ Path = $part; ExpectedLength = $expectedPartLength }
        if (-not (Test-Path -LiteralPath $part) -or (Get-Item -LiteralPath $part).Length -ne $expectedPartLength) {
            if ($queued -gt 0) { $arguments += '--next' }
            $arguments += @('--fail', '--location', '--retry', '3', '--retry-all-errors', '--silent', '--show-error',
                '--range', "$start-$end", '--output', $part, '--url', $Url)
            $queued++
        }
    }
    if ($queued -gt 0) {
        & curl.exe @arguments
        if ($LASTEXITCODE -ne 0) { throw "Ranged download failed: $Name" }
    }
    foreach ($part in $parts) {
        if (-not (Test-Path -LiteralPath $part.Path) -or (Get-Item -LiteralPath $part.Path).Length -ne $part.ExpectedLength) {
            throw "Incomplete image segment: $($part.Path)"
        }
    }
    $assembled = "$path.assembling"
    $outputStream = [IO.FileStream]::new($assembled, [IO.FileMode]::Create, [IO.FileAccess]::Write)
    try {
        foreach ($part in $parts) {
            $inputStream = [IO.File]::OpenRead($part.Path)
            try { $inputStream.CopyTo($outputStream) }
            finally { $inputStream.Dispose() }
        }
    } finally { $outputStream.Dispose() }
    if ((Get-Item -LiteralPath $assembled).Length -ne $ExpectedLength) { throw "Wrong assembled length: $Name" }
    $actual = (Get-FileHash -LiteralPath $assembled -Algorithm SHA1).Hash
    if ($actual -ine $Checksum) { throw "SHA1 mismatch for $Name : $actual" }
    Move-Item -LiteralPath $assembled -Destination $path -Force
    Write-Host "Verified: $Name"
    return $path
}

$jdkArchive = 'microsoft-jdk-17.0.21.0.2-windows-x64.zip'
$cliArchive = 'commandlinetools-win-15859902_latest.zip'
$jdkPath = Join-Path $root 'jdk'
$sdkManager = Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
$emulator = Join-Path $sdk 'emulator\emulator.exe'

if ($Step -eq 'DownloadTools') {
    $jdkZip = Download-Verified 'https://aka.ms/download-jdk/microsoft-jdk-17.0.21.0.2-windows-x64.zip' $jdkArchive '49154292866386b2f4f09a3ecf3be07ab80a419149c84ec1d4419b9eec9e4b64'
    if (-not (Get-ChildItem -LiteralPath $jdkPath -Recurse -Filter java.exe -File -ErrorAction SilentlyContinue | Select-Object -First 1)) {
        Expand-Archive -LiteralPath $jdkZip -DestinationPath $jdkPath -Force
    }
    $cliZip = Download-Verified 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip' $cliArchive '90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'
    if (-not (Test-Path -LiteralPath $sdkManager)) {
        $unpack = Join-Path $root 'cmdline-unpack'
        Expand-Archive -LiteralPath $cliZip -DestinationPath $unpack -Force
        $dest = Join-Path $sdk 'cmdline-tools\latest'
        New-Item -ItemType Directory -Path (Split-Path $dest) -Force | Out-Null
        if (-not ([IO.Path]::GetFullPath($unpack)).StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or
            -not ([IO.Path]::GetFullPath($dest)).StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Unsafe Android CLI move path.'
        }
        Move-Item -LiteralPath (Join-Path $unpack 'cmdline-tools') -Destination $dest
    }
    Write-Host "Portable Java and Android CLI ready on E: $root"
    exit 0
}

$javaBinary = Get-ChildItem -LiteralPath $jdkPath -Recurse -Filter java.exe -File -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $javaBinary) { throw 'Run DownloadTools first; portable Java is missing.' }
$env:JAVA_HOME = Split-Path $javaBinary.DirectoryName
$env:Path = $javaBinary.DirectoryName + ';' + $env:Path
if (-not (Test-Path -LiteralPath $sdkManager)) { throw 'Run DownloadTools first.' }

if ($Step -eq 'AcceptLicenses') {
    1..20 | ForEach-Object { 'y' } | & $sdkManager --sdk_root=$sdk --licenses |
        Out-File -LiteralPath (Join-Path $root 'sdk-licenses.log') -Encoding utf8
    if ($LASTEXITCODE -ne 0) { throw 'Android SDK license acceptance failed.' }
    Write-Host "Android SDK license prompts completed; see $root\sdk-licenses.log"
    exit 0
}

if ($Step -eq 'CheckAcceleration') {
    if (-not (Test-Path -LiteralPath $emulator)) { throw 'Run InstallSdk first.' }
    & $emulator -accel-check
    exit $LASTEXITCODE
}

if ($Step -eq 'InstallSdk') {
    $adbZip = Download-Verified 'https://dl.google.com/android/repository/platform-tools_r37.0.1-win.zip' 'platform-tools_r37.0.1-win.zip' 'e03e78b1d80b396f1c3358e31251cb31740e1110' 'SHA1'
    if (-not (Test-Path -LiteralPath (Join-Path $sdk 'platform-tools\adb.exe'))) {
        Expand-Archive -LiteralPath $adbZip -DestinationPath $sdk -Force
    }
    $emulatorZip = Download-Verified 'https://dl.google.com/android/repository/emulator-windows_x64-16740729.zip' 'emulator-windows_x64-16740729.zip' '4d7268aa7787c640ad892844e6c9a5f159e91ad3' 'SHA1'
    if (-not (Test-Path -LiteralPath $emulator)) {
        Expand-Archive -LiteralPath $emulatorZip -DestinationPath $sdk -Force
    }
    if (-not (Test-Path -LiteralPath (Join-Path $sdk 'platform-tools\adb.exe')) -or -not (Test-Path -LiteralPath $emulator)) {
        throw 'Android SDK installation incomplete.'
    }
    $emulatorRegistration = Join-Path $sdk 'emulator\package.xml'
    if (-not (Test-Path -LiteralPath $emulatorRegistration)) {
        $template = Get-Content -LiteralPath (Join-Path $sdk 'platform-tools\package.xml') -Raw
        foreach ($required in @('<localPackage path="platform-tools"', '<minor>0</minor>', '<micro>1</micro>', 'Android SDK Platform-Tools 37.0.1')) {
            if (-not $template.Contains($required)) { throw "Unexpected platform-tools package registration: $required" }
        }
        $registration = $template.Replace('<localPackage path="platform-tools"', '<localPackage path="emulator"').
            Replace('<minor>0</minor>', '<minor>2</minor>').
            Replace('<micro>1</micro>', '<micro>13</micro>').
            Replace('Android SDK Platform-Tools 37.0.1', 'Android Emulator 37.2.13')
        [IO.File]::WriteAllText($emulatorRegistration, $registration, [Text.UTF8Encoding]::new($false))
    }
    exit 0
}

if ($Step -eq 'InstallImage') {
    if (-not (Test-Path -LiteralPath $emulator)) { throw 'Run InstallSdk and CheckAcceleration first.' }
    & $emulator -accel-check
    if ($LASTEXITCODE -ne 0) { throw 'Android emulator acceleration is unavailable; system image not downloaded.' }
    $imageZip = Download-RangedVerified 'https://dl.google.com/android/repository/sys-img/google_apis/x86_64-30_r16.zip' 'x86_64-30_r16.zip' '6ae21030eaadc041078444d3798e4b399f3e787d' 1438186618
    Add-Type -AssemblyName System.IO.Compression
    $archive = [IO.Compression.ZipFile]::OpenRead($imageZip)
    try { $firstEntry = $archive.Entries | Where-Object { $_.FullName -and -not $_.FullName.EndsWith('/') } | Select-Object -First 1 -ExpandProperty FullName }
    finally { $archive.Dispose() }
    $parent = Join-Path $sdk 'system-images\android-30\google_apis'
    $destination = if ($firstEntry.StartsWith('x86_64/')) { $parent } else { Join-Path $parent 'x86_64' }
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    if (-not (Test-Path -LiteralPath (Join-Path $parent 'x86_64\source.properties'))) {
        Expand-Archive -LiteralPath $imageZip -DestinationPath $destination -Force
    }
    if (-not (Test-Path -LiteralPath (Join-Path $parent 'x86_64\source.properties'))) {
        throw 'Android system image installation incomplete.'
    }
    exit 0
}

if ($Step -eq 'InstallArmImage') {
    if (-not (Test-Path -LiteralPath $emulator)) { throw 'Run InstallSdk first.' }
    $imageZip = Download-RangedVerified 'https://dl.google.com/android/repository/sys-img/google_apis/arm64-v8a-30_r16.zip' 'arm64-v8a-30_r16.zip' '0e66987d6b4db2e278af83d453ce5d74a7e6ced3' 1244324730
    Add-Type -AssemblyName System.IO.Compression
    $archive = [IO.Compression.ZipFile]::OpenRead($imageZip)
    try { $firstEntry = $archive.Entries | Where-Object { $_.FullName -and -not $_.FullName.EndsWith('/') } | Select-Object -First 1 -ExpandProperty FullName }
    finally { $archive.Dispose() }
    $parent = Join-Path $sdk 'system-images\android-30\google_apis'
    $destination = if ($firstEntry.StartsWith('arm64-v8a/')) { $parent } else { Join-Path $parent 'arm64-v8a' }
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    if (-not (Test-Path -LiteralPath (Join-Path $parent 'arm64-v8a\source.properties'))) {
        Expand-Archive -LiteralPath $imageZip -DestinationPath $destination -Force
    }
    if (-not (Test-Path -LiteralPath (Join-Path $parent 'arm64-v8a\source.properties'))) {
        throw 'Native ARM64 Android image installation incomplete.'
    }
    exit 0
}

if ($Step -eq 'DownloadWeChat') {
    $apk = Download-Verified 'https://dldir1v6.qq.com/weixin/android/weixin8080android3220_0x28005032_arm64.apk' 'weixin8080android3220_0x28005032_arm64.apk' '9d9b6c516e8e07e437c81485fde21fe13ce4f61b37d19e793fff40c71be39c0e'
    if ((Get-Item -LiteralPath $apk).Length -ne 286319384) { throw 'WeChat APK length mismatch.' }
    Write-Host "Pinned official WeChat APK ready: $apk"
    exit 0
}

if ($Step -eq 'CreateAvd') {
    if (-not (Test-Path -LiteralPath $emulator)) { throw 'Run InstallSdk first.' }
    $manager = Join-Path $sdk 'cmdline-tools\latest\bin\avdmanager.bat'
    $avdPath = Join-Path $env:ANDROID_AVD_HOME 'CodexWeChat.avd'
    if (Test-Path -LiteralPath (Join-Path $avdPath 'config.ini')) {
        Write-Host "Existing AVD preserved: $avdPath"
        exit 0
    }
    & $manager create avd --name CodexWeChat --package 'system-images;android-30;google_apis;x86_64' --path $avdPath --device 'pixel_c'
    exit $LASTEXITCODE
}

if ($Step -eq 'CreateArmAvd') {
    $aliasRoot = Ensure-AsciiAlias
    $manager = Join-Path $sdk 'cmdline-tools\latest\bin\avdmanager.bat'
    $avdPath = Join-Path $env:ANDROID_AVD_HOME 'CodexWeChatArm.avd'
    if (Test-Path -LiteralPath (Join-Path $avdPath 'config.ini')) {
        Write-Host "Existing ARM64 AVD preserved: $avdPath"
        exit 0
    }
    & $manager create avd --name CodexWeChatArm --package 'system-images;android-30;google_apis;arm64-v8a' --path $avdPath --device 'pixel_c'
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $avdPath 'config.ini'))) { throw 'Native ARM64 AVD creation failed.' }
    $avdIni = Join-Path $env:ANDROID_AVD_HOME 'CodexWeChatArm.ini'
    $iniText = Get-Content -LiteralPath $avdIni -Raw
    $iniText = [regex]::Replace($iniText, '(?m)^path=.*$', 'path=X:\avd\avd\CodexWeChatArm.avd')
    [IO.File]::WriteAllText($avdIni, $iniText, [Text.UTF8Encoding]::new($false))
    exit 0
}

if ($Step -eq 'LaunchHeadless') {
    $aliasRoot = Ensure-AsciiAlias
    $env:ANDROID_HOME = Join-Path $aliasRoot 'sdk'
    $env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
    $env:ANDROID_USER_HOME = Join-Path $aliasRoot 'avd'
    $env:ANDROID_EMULATOR_HOME = $env:ANDROID_USER_HOME
    $env:ANDROID_AVD_HOME = Join-Path $aliasRoot 'avd\avd'
    $env:ANDROID_SDK_HOME = $env:ANDROID_USER_HOME
    $env:TEMP = Join-Path $aliasRoot 'tmp'
    $env:TMP = $env:TEMP
    $env:USERPROFILE = $aliasRoot
    $env:HOME = $aliasRoot
    $env:HOMEDRIVE = 'X:'
    $env:HOMEPATH = '\'
    $env:LOCALAPPDATA = Join-Path $aliasRoot 'appdata-local'
    $env:APPDATA = Join-Path $aliasRoot 'appdata-roaming'
    New-Item -ItemType Directory -Path $env:LOCALAPPDATA, $env:APPDATA -Force | Out-Null
    $avdIni = Join-Path $env:ANDROID_AVD_HOME 'CodexWeChat.ini'
    $iniText = Get-Content -LiteralPath $avdIni -Raw
    if ($iniText -notmatch '(?m)^path=X:\\avd\\avd\\CodexWeChat\.avd$') {
        $backup = Join-Path $avd 'avd\CodexWeChat.ini.before-ascii-alias'
        if (-not (Test-Path -LiteralPath $backup)) { Copy-Item -LiteralPath $avdIni -Destination $backup }
        $iniText = [regex]::Replace($iniText, '(?m)^path=.*$', 'path=X:\avd\avd\CodexWeChat.avd')
        [IO.File]::WriteAllText($avdIni, $iniText, [Text.UTF8Encoding]::new($false))
    }
    $avdConfig = Join-Path $env:ANDROID_AVD_HOME 'CodexWeChat.avd\config.ini'
    if (-not (Test-Path -LiteralPath $avdConfig)) { throw 'Run CreateAvd first.' }
    if (Get-Process -Name emulator -ErrorAction SilentlyContinue) { throw 'An Android emulator is already running; no second instance started.' }
    $emulatorAlias = Join-Path $aliasRoot 'sdk\emulator\emulator.exe'
    & $emulatorAlias -accel-check
    if ($LASTEXITCODE -ne 0) { throw 'Android emulator acceleration is unavailable; nothing launched.' }
    $stdout = Join-Path $root 'emulator-stdout.log'
    $stderr = Join-Path $root 'emulator-stderr.log'
    $process = Start-Process -FilePath $emulatorAlias -ArgumentList @(
        '-avd', 'CodexWeChat', '-no-window', '-no-audio', '-no-boot-anim',
        '-no-snapshot', '-memory', '2048', '-cores', '2', '-gpu', 'swiftshader_indirect',
        '-feature', '-Vulkan', '-no-metrics'
    ) -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
    Write-Host "Headless Android emulator launched: PID $($process.Id); logs: $root"
    exit 0
}

if ($Step -eq 'LaunchArmHeadless') {
    if ([Runtime.InteropServices.RuntimeInformation]::OSArchitecture -ne [Runtime.InteropServices.Architecture]::Arm64) {
        throw 'This Android Emulator build does not run ARM64 system images on an x86_64 host. No VM started.'
    }
    $aliasRoot = Ensure-AsciiAlias
    $env:ANDROID_HOME = Join-Path $aliasRoot 'sdk'
    $env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
    $env:ANDROID_USER_HOME = Join-Path $aliasRoot 'avd'
    $env:ANDROID_EMULATOR_HOME = $env:ANDROID_USER_HOME
    $env:ANDROID_AVD_HOME = Join-Path $aliasRoot 'avd\avd'
    $env:ANDROID_SDK_HOME = $env:ANDROID_USER_HOME
    $env:TEMP = Join-Path $aliasRoot 'tmp'
    $env:TMP = $env:TEMP
    $env:USERPROFILE = $aliasRoot
    $env:HOME = $aliasRoot
    $env:HOMEDRIVE = 'X:'
    $env:HOMEPATH = '\'
    $env:LOCALAPPDATA = Join-Path $aliasRoot 'appdata-local'
    $env:APPDATA = Join-Path $aliasRoot 'appdata-roaming'
    New-Item -ItemType Directory -Path $env:LOCALAPPDATA, $env:APPDATA -Force | Out-Null
    $avdConfig = Join-Path $env:ANDROID_AVD_HOME 'CodexWeChatArm.avd\config.ini'
    $avdIni = Join-Path $env:ANDROID_AVD_HOME 'CodexWeChatArm.ini'
    if (-not (Test-Path -LiteralPath $avdConfig) -or -not (Test-Path -LiteralPath $avdIni)) { throw 'Run CreateArmAvd first.' }
    $iniText = Get-Content -LiteralPath $avdIni -Raw
    if ($iniText -notmatch '(?m)^path=X:\\avd\\avd\\CodexWeChatArm\.avd$') {
        $iniText = [regex]::Replace($iniText, '(?m)^path=.*$', 'path=X:\avd\avd\CodexWeChatArm.avd')
        [IO.File]::WriteAllText($avdIni, $iniText, [Text.UTF8Encoding]::new($false))
    }
    if (Get-Process -Name emulator -ErrorAction SilentlyContinue) { throw 'An Android emulator is already running; no second instance started.' }
    $emulatorAlias = Join-Path $aliasRoot 'sdk\emulator\emulator.exe'
    $stdout = Join-Path $root 'arm-emulator-stdout.log'
    $stderr = Join-Path $root 'arm-emulator-stderr.log'
    $process = Start-Process -FilePath $emulatorAlias -ArgumentList @(
        '-avd', 'CodexWeChatArm', '-no-window', '-no-audio', '-no-boot-anim',
        '-no-snapshot', '-memory', '2048', '-cores', '2', '-skin', '1280x800',
        '-gpu', 'swiftshader_indirect', '-feature', '-Vulkan', '-accel', 'off', '-no-metrics'
    ) -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
    try { $process.PriorityClass = [Diagnostics.ProcessPriorityClass]::BelowNormal } catch { }
    Write-Host "Headless ARM64 Android emulator launched: PID $($process.Id); logs: $root"
    exit 0
}
