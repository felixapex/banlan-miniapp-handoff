param(
    [string]$FridaBindingPath
)

$ErrorActionPreference = 'Stop'
$packageRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$nodeModules = [IO.Path]::GetFullPath((Join-Path $packageRoot 'node_modules'))
$prefix = 'E:' + [IO.Path]::DirectorySeparatorChar
if (-not $packageRoot.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or
    -not $nodeModules.StartsWith($packageRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Setup must run from this package on E:. No files were changed.'
}

$cache = Join-Path $packageRoot '.npm-cache'
New-Item -ItemType Directory -Path $cache -Force | Out-Null
$installedBinding = Join-Path $nodeModules 'frida\build\frida_binding.node'
$source = if ($FridaBindingPath) { [IO.Path]::GetFullPath($FridaBindingPath) } elseif (Test-Path -LiteralPath $installedBinding) { $installedBinding } else { $null }
$staged = Join-Path $cache 'frida-binding-17.18.0.node'
if ($source) {
    if (-not $source.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw 'Frida binding source must be an existing file on E:. No dependencies were changed.'
    }
    Copy-Item -LiteralPath $source -Destination $staged -Force
}

Push-Location $packageRoot
try {
    if ($source) {
        npm ci --ignore-scripts --no-audit --no-fund --cache $cache
    } else {
        npm ci --no-audit --no-fund --cache $cache
    }
    if ($LASTEXITCODE -ne 0) { throw 'npm ci failed. Supply -FridaBindingPath with a compatible Frida 17.18.0 binary on E: if this machine cannot compile it.' }
    if ($source) {
        Copy-Item -LiteralPath $staged -Destination $installedBinding -Force
        Remove-Item -LiteralPath $staged
    }
    node --input-type=module -e "import('frida').then(() => console.log('Frida 17.18.0 binding ready'))"
    if ($LASTEXITCODE -ne 0) { throw 'Frida native binding failed to load.' }
} finally {
    Pop-Location
}
