"""Offline inventory of a developer-owned WeChat miniapp source project."""

import argparse

from capture.core.source_inventory import write_inventory


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', required=True, help='E: directory containing app.json')
    parser.add_argument('--output', required=True, help='New E: workspace output directory')
    args = parser.parse_args()
    result = write_inventory(args.project, args.output)
    print(result)


if __name__ == '__main__':
    try:
        main()
    except ValueError as error:
        raise SystemExit(f'source inventory error: {error}') from None
