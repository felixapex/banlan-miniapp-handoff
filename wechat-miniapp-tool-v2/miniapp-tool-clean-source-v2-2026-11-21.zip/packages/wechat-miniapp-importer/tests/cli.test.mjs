import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { access, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'
import test from 'node:test'

import { runMiniappImport } from '../src/run-import.mjs'
import { completeAcceptance, completeCapture } from './fixtures.mjs'

async function fixture(t, mutateCapture = () => {}) {
  const root = await mkdtemp(path.join(process.cwd(), '.test-cli-'))
  t.after(() => rm(root, { recursive: true, force: true }))
  const captureDir = path.join(root, 'capture')
  const outputDir = path.join(root, 'output')
  await mkdir(path.join(captureDir, 'assets'), { recursive: true })
  const bytes = Buffer.from('hero-image-bytes')
  await writeFile(path.join(captureDir, 'assets/hero.jpg'), bytes)
  const capture = completeCapture()
  mutateCapture(capture)
  const resourceManifest = {
    baseUrl: 'https://miniapp.example/',
    discoveryComplete: true,
    rewritesComplete: true,
    unresolvedReferences: [],
    resources: [{
      id: 'hero-image', kind: 'image', sourceUrl: 'https://miniapp.example/assets/hero.jpg',
      localPath: 'assets/hero.jpg', sha256: createHash('sha256').update(bytes).digest('hex'),
      byteLength: bytes.length, status: 'frozen', critical: true,
      referencedBy: ['component:component-hero']
    }]
  }
  await writeFile(path.join(captureDir, 'capture.json'), JSON.stringify(capture))
  await writeFile(path.join(captureDir, 'resource-manifest.json'), JSON.stringify(resourceManifest))
  await writeFile(path.join(captureDir, 'acceptance.json'), JSON.stringify({ 'component-hero': completeAcceptance() }))
  return { root, captureDir, outputDir }
}

test('writes a self-contained accepted component and page from a complete capture directory', async (t) => {
  const { captureDir, outputDir } = await fixture(t)

  const result = await runMiniappImport({ captureDir, outputDir })

  assert.equal(result.exitCode, 0)
  assert.equal(result.verification.status, 'passed')
  await access(path.join(outputDir, 'components/component-hero.json'))
  await access(path.join(outputDir, 'pages/page-home.json'))
  await access(path.join(outputDir, 'assets/hero.jpg'))
  const verification = JSON.parse(await readFile(path.join(outputDir, 'verification.json'), 'utf8'))
  assert.equal(verification.status, 'passed')
})

test('writes failed evidence separately and never assembles an incomplete component', async (t) => {
  const { captureDir, outputDir } = await fixture(t, (capture) => {
    delete capture.pages[0].components[0].captured.spacing
    capture.pages[0].components[0].status = 'passed'
  })

  const result = await runMiniappImport({ captureDir, outputDir })

  assert.equal(result.exitCode, 2)
  assert.equal(result.verification.status, 'failed')
  await access(path.join(outputDir, 'rejected-components/component-hero.json'))
  await assert.rejects(access(path.join(outputDir, 'components/component-hero.json')))
  await assert.rejects(access(path.join(outputDir, 'pages/page-home.json')))
})

test('missing or tampered frozen files block transformation before output assembly', async (t) => {
  const { captureDir, outputDir } = await fixture(t)
  await writeFile(path.join(captureDir, 'assets/hero.jpg'), 'tampered')

  const result = await runMiniappImport({ captureDir, outputDir })

  assert.equal(result.exitCode, 2)
  assert.ok(result.verification.resources.failures.some((failure) => failure.type === 'resource-size-mismatch' || failure.type === 'resource-hash-mismatch'))
  await assert.rejects(access(path.join(outputDir, 'components/component-hero.json')))
})

test('freezes raw miniapp document dependencies when no resource manifest exists yet', async (t) => {
  const { captureDir, outputDir } = await fixture(t)
  await rm(path.join(captureDir, 'resource-manifest.json'))
  await writeFile(path.join(captureDir, 'documents.json'), JSON.stringify([{
    id: 'home', kind: 'wxml', sourceUrl: 'https://miniapp.example/pages/home/index.wxml',
    content: '<image src="/assets/hero.jpg" />'
  }]))

  const result = await runMiniappImport({
    captureDir,
    outputDir,
    fetchImpl: async (url) => ({
      ok: String(url) === 'https://miniapp.example/assets/hero.jpg',
      status: 200,
      headers: { get: () => 'image/jpeg' },
      arrayBuffer: async () => Buffer.from('hero-image-bytes')
    })
  })

  assert.equal(result.exitCode, 0)
  const manifest = JSON.parse(await readFile(path.join(outputDir, 'resource-manifest.json'), 'utf8'))
  assert.equal(manifest.resources.length, 1)
  assert.equal(manifest.resources[0].status, 'frozen')
  await access(path.join(outputDir, manifest.resources[0].localPath))
  await access(path.join(outputDir, 'rewritten-documents.json'))
})
