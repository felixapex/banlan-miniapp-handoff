import assert from 'node:assert/strict'
import test from 'node:test'

import { importMiniappCapture } from '../src/import-pipeline.mjs'
import { completeAcceptance, completeCapture } from './fixtures.mjs'

function resourceManifest() {
  return {
    baseUrl: 'https://miniapp.example/',
    discoveryComplete: true,
    rewritesComplete: true,
    unresolvedReferences: [],
    resources: [{
      id: 'hero-image', kind: 'image',
      sourceUrl: 'https://miniapp.example/assets/hero.jpg',
      localPath: 'assets/hero.jpg', sha256: 'c'.repeat(64), byteLength: 100,
      status: 'frozen', critical: true, referencedBy: ['component:component-hero']
    }]
  }
}

test('assembles a page only after capture, resources, transform, and acceptance pass', () => {
  const result = importMiniappCapture({
    capture: completeCapture(),
    resourceManifest: resourceManifest(),
    acceptanceByComponent: { 'component-hero': completeAcceptance() }
  })

  assert.equal(result.status, 'passed')
  assert.equal(result.components['component-hero'].status, 'passed')
  assert.deepEqual(result.pages[0].assembledComponentIds, ['component-hero'])
  assert.deepEqual(result.pages[0].excludedComponentIds, [])
})

test('an incomplete capture is excluded from assembly even if input declares passed', () => {
  const capture = completeCapture()
  delete capture.pages[0].components[0].captured.spacing
  capture.pages[0].components[0].status = 'passed'

  const result = importMiniappCapture({
    capture,
    resourceManifest: resourceManifest(),
    acceptanceByComponent: { 'component-hero': completeAcceptance() }
  })

  assert.equal(result.status, 'failed')
  assert.deepEqual(result.pages[0].assembledComponentIds, [])
  assert.deepEqual(result.pages[0].excludedComponentIds, ['component-hero'])
  assert.equal(result.components['component-hero'].layers.capture.status, 'failed')
})

test('acceptance failure excludes a transformed component from assembly', () => {
  const acceptance = completeAcceptance()
  acceptance.viewports.mobile.layoutMatch = false

  const result = importMiniappCapture({
    capture: completeCapture(),
    resourceManifest: resourceManifest(),
    acceptanceByComponent: { 'component-hero': acceptance }
  })

  assert.equal(result.components['component-hero'].layers.transform.status, 'passed')
  assert.equal(result.components['component-hero'].layers.acceptance.status, 'failed')
  assert.deepEqual(result.pages[0].assembledComponentIds, [])
})
