export function completeCapturedDomains() {
  const evidence = ['capture:page-home:component-hero']
  const wrap = (value) => ({ value, evidence })
  return {
    text: wrap([{ path: 'title', value: 'Example' }]),
    images: wrap([{
      path: 'hero.image',
      url: 'https://miniapp.example/assets/hero.jpg',
      resourceStatus: 'frozen',
      source: { width: 1200, height: 800 },
      displayed: { desktop: { width: 600, height: 400 }, mobile: { width: 360, height: 240 } },
      aspectRatio: 1.5,
      container: { desktop: { width: 600, height: 400 }, mobile: { width: 360, height: 240 } },
      objectFit: 'cover',
      objectPosition: '50% 50%'
    }]),
    typography: wrap([{ target: '.title', fontFamily: 'Demo', fontSize: '32px', fontWeight: 600, lineHeight: '40px', color: '#111111' }]),
    colors: wrap([{ target: '.hero', value: '#ffffff' }]),
    dimensions: wrap([{ target: '.hero', width: '100%', height: '400px' }]),
    ratios: wrap([{ target: '.hero', width: 3, height: 2, value: 1.5 }]),
    containers: wrap([{ target: '.hero', width: '100%', height: '400px', maxWidth: '1200px', display: 'grid', layout: 'grid', overflow: 'hidden' }]),
    spacing: wrap([{ target: '.hero', margin: '0', padding: '24px', gap: '16px', borderRadius: '12px' }]),
    alignment: wrap([{ target: '.hero', horizontal: 'center', vertical: 'center', text: 'left' }]),
    cropping: wrap([{ target: '.hero img', objectFit: 'cover', objectPosition: '50% 50%' }]),
    responsive: wrap({ desktop: { widthMode: 'fluid', columns: 3 }, mobile: { widthMode: 'fluid', columns: 1 }, rules: [] }),
    interactions: wrap([{ target: '.hero', event: 'tap', outcome: { type: 'route', target: '/pages/detail/index' } }]),
    links: wrap([{ target: '.hero', type: 'route', url: '/pages/detail/index' }]),
    editableFields: wrap([{ path: 'title', domain: 'text', type: 'string', label: 'Title' }])
  }
}

export function completeCapture() {
  return {
    schemaVersion: 1,
    platform: 'wechat-miniapp',
    baseUrl: 'https://miniapp.example/',
    pages: [{
      id: 'page-home',
      route: '/pages/home/index',
      components: [{
        id: 'component-hero',
        type: 'hero-carousel',
        status: 'passed',
        captured: completeCapturedDomains(),
        notApplicable: {}
      }]
    }]
  }
}

function acceptanceViewport(width) {
  return {
    measurements: [{
      target: '.hero',
      source: { x: 0, y: 20, width, height: 400, aspectRatio: width / 400 },
      rendered: { x: 0.5, y: 20.5, width: width - 0.5, height: 400.5, aspectRatio: (width - 0.5) / 400.5 }
    }],
    images: { expected: 1, results: [{ target: '.hero img', loaded: true, croppingMatch: true }] },
    typographyMatch: true,
    layoutMatch: true,
    adaptive: true
  }
}

export function completeAcceptance() {
  return {
    editorFieldsComplete: true,
    viewports: { desktop: acceptanceViewport(600), mobile: acceptanceViewport(360) }
  }
}
