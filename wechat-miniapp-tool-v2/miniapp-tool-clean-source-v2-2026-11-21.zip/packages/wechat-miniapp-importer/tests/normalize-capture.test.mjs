import assert from 'node:assert/strict'
import test from 'node:test'

import { normalizeMiniappCapture } from '../src/normalize-capture.mjs'
import { completeCapture } from './fixtures.mjs'

test('normalizes a brand-neutral miniapp capture into the shared editor contract', () => {
  const result = normalizeMiniappCapture(completeCapture())

  assert.equal(result.platform, 'wechat-miniapp')
  assert.equal(result.baseUrl, 'https://miniapp.example/')
  assert.equal(result.pages[0].route, '/pages/home/index')
  assert.equal(result.pages[0].verification.status, 'passed')
  assert.equal(result.pages[0].components[0].domains.images.status, 'captured')
})

test('does not invent missing image display facts or trust a declared passed status', () => {
  const capture = completeCapture()
  delete capture.pages[0].components[0].captured.images.value[0].objectPosition
  capture.pages[0].components[0].status = 'passed'

  const result = normalizeMiniappCapture(capture)
  const verification = result.pages[0].verification

  assert.equal(verification.status, 'failed')
  assert.ok(verification.failures.some((failure) => failure.domain === 'images' && failure.path.endsWith('objectPosition')))
})

test('missing required domains remain absent and block the page', () => {
  const capture = completeCapture()
  delete capture.pages[0].components[0].captured.responsive

  const result = normalizeMiniappCapture(capture)

  assert.equal(result.pages[0].verification.status, 'failed')
  assert.ok(result.pages[0].verification.failures.some((failure) => failure.domain === 'responsive' && failure.type === 'missing-domain'))
})

test('rejects captures for another platform instead of silently importing them', () => {
  const capture = completeCapture()
  capture.platform = 'android-app'
  assert.throws(() => normalizeMiniappCapture(capture), /platform must be wechat-miniapp/)
})
