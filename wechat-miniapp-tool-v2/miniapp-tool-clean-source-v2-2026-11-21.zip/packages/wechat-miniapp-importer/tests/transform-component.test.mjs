import assert from 'node:assert/strict'
import test from 'node:test'

import { normalizeMiniappCapture } from '../src/normalize-capture.mjs'
import { transformComponent } from '../src/transform-component.mjs'
import { completeCapture } from './fixtures.mjs'

function resourceManifest() {
  return {
    baseUrl: 'https://miniapp.example/',
    discoveryComplete: true,
    rewritesComplete: true,
    unresolvedReferences: [],
    resources: [{
      id: 'hero-image',
      kind: 'image',
      sourceUrl: 'https://miniapp.example/assets/hero.jpg',
      localPath: 'assets/hero.jpg',
      sha256: 'b'.repeat(64),
      byteLength: 100,
      status: 'frozen',
      critical: true,
      referencedBy: ['component:component-hero']
    }]
  }
}

function component() {
  return normalizeMiniappCapture(completeCapture()).pages[0].components[0]
}

test('writes image, container, text, typography, and responsive facts into schema/settings', () => {
  const result = transformComponent(component(), resourceManifest())

  assert.equal(result.status, 'passed')
  assert.equal(result.settings.images[0].aspectRatio, 1.5)
  assert.equal(result.settings.images[0].objectFit, 'cover')
  assert.equal(result.settings.images[0].objectPosition, '50% 50%')
  assert.equal(result.settings.images[0].sourceUrl, 'https://miniapp.example/assets/hero.jpg')
  assert.equal(result.settings.images[0].url, 'assets/hero.jpg')
  assert.equal(result.settings.images[0].sha256, 'b'.repeat(64))
  assert.equal(result.settings.containers[0].layout, 'grid')
  assert.equal(result.settings.spacing[0].gap, '16px')
  assert.equal(result.settings.typography[0].fontWeight, 600)
  assert.equal(result.settings.responsive.mobile.widthMode, 'fluid')
  assert.ok(result.schema.settings.some((setting) => setting.id === 'images.0.source.width'))
  assert.ok(result.schema.settings.some((setting) => setting.id === 'typography.0.fontSize'))
})

test('every generated schema field resolves to a real settings value', () => {
  const result = transformComponent(component(), resourceManifest())

  for (const definition of result.schema.settings) {
    const value = definition.valuePath.split('.').reduce((current, key) => current?.[key], result.settings)
    assert.notEqual(value, undefined, definition.id)
  }
})

test('resource failure or an unfrozen captured image blocks transformation', () => {
  const manifest = resourceManifest()
  manifest.resources[0].status = 'failed'
  manifest.resources[0].sha256 = ''
  manifest.resources[0].byteLength = 0

  const result = transformComponent(component(), manifest)

  assert.equal(result.status, 'failed')
  assert.equal(result.schema, undefined)
  assert.ok(result.failures.some((failure) => failure.layer === 'resources'))
})

test('a captured image URL must have a frozen resource record', () => {
  const manifest = resourceManifest()
  manifest.resources[0].sourceUrl = 'https://miniapp.example/assets/other.jpg'

  const result = transformComponent(component(), manifest)

  assert.equal(result.status, 'failed')
  assert.ok(result.failures.some((failure) => failure.type === 'captured-image-not-frozen'))
})

test('rejects a fixed whole-page width instead of pretending it is responsive', () => {
  const item = component()
  item.type = 'page-root'
  item.domains.containers.value[0].target = '.page-root'
  item.domains.containers.value[0].width = '750px'

  const result = transformComponent(item, resourceManifest())

  assert.equal(result.status, 'failed')
  assert.ok(result.failures.some((failure) => failure.type === 'fixed-page-width'))
})
