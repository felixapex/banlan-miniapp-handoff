import path from 'node:path'
import { fileURLToPath } from 'node:url'

import { runMiniappImport } from './src/run-import.mjs'

function argument(name) {
  const index = process.argv.indexOf(`--${name}`)
  return index >= 0 ? process.argv[index + 1] : null
}

export async function main() {
  const captureDir = argument('capture')
  const outputDir = argument('output')
  if (!captureDir || !outputDir) {
    throw new Error('Usage: node import-miniapp.mjs --capture <capture-dir> --output <new-output-dir>')
  }
  const result = await runMiniappImport({ captureDir, outputDir })
  process.stdout.write(`${JSON.stringify({ outputDir: result.outputDir, status: result.verification.status, summary: result.verification.summary }, null, 2)}\n`)
  process.exitCode = result.exitCode
}

const isEntry = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))
if (isEntry) main().catch((error) => {
  process.stderr.write(`${error.stack || error}\n`)
  process.exitCode = 1
})

