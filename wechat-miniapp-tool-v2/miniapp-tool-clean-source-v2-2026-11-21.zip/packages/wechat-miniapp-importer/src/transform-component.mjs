import { evaluateEditorComponent } from '../../import-foundation/editor-data-contract.mjs'
import { evaluateResourceManifest } from '../../import-foundation/resource-contract.mjs'

function leafType(value) {
  if (Array.isArray(value) || (value && typeof value === 'object')) return 'json'
  return typeof value
}

function flattenSettings(value, path = [], output = []) {
  if (Array.isArray(value)) {
    value.forEach((item, index) => flattenSettings(item, [...path, String(index)], output))
    return output
  }
  if (value && typeof value === 'object') {
    for (const [key, child] of Object.entries(value)) flattenSettings(child, [...path, key], output)
    return output
  }
  output.push({ path, value })
  return output
}

function editorLabels(component) {
  const fields = component.domains?.editableFields?.value
  return new Map((Array.isArray(fields) ? fields : []).map((field) => [field.path, field]))
}

function isFixedPageWidth(component) {
  if (!/(?:^|-)page(?:-|$)|page-root/i.test(component.type || '')) return false
  const containers = component.domains?.containers?.value
  return Array.isArray(containers) && containers.some((container) => /^\d+(?:\.\d+)?(?:px|rpx)$/i.test(String(container.width || '').trim()))
}

function capturedImageFailures(component, resourceManifest) {
  const frozenUrls = new Set(
    (resourceManifest.resources || [])
      .filter((resource) => resource.status === 'frozen')
      .map((resource) => resource.sourceUrl)
  )
  const images = component.domains?.images?.status === 'captured'
    ? component.domains.images.value
    : []
  return (Array.isArray(images) ? images : []).flatMap((image, index) => (
    frozenUrls.has(image.url)
      ? []
      : [{ layer: 'resources', type: 'captured-image-not-frozen', path: `images[${index}].url`, sourceUrl: image.url }]
  ))
}

function settingValue(domain, value, resourceManifest) {
  if (domain !== 'images') return structuredClone(value)
  const resources = new Map((resourceManifest.resources || []).map((resource) => [resource.sourceUrl, resource]))
  return value.map((image) => {
    const resource = resources.get(image.url)
    return {
      ...structuredClone(image),
      sourceUrl: image.url,
      url: resource.localPath,
      localPath: resource.localPath,
      sha256: resource.sha256,
      byteLength: resource.byteLength,
      resourceStatus: resource.status
    }
  })
}

export function transformComponent(component = {}, resourceManifest = {}) {
  const capture = evaluateEditorComponent(component)
  const resources = evaluateResourceManifest(resourceManifest)
  const failures = [
    ...capture.failures.map((failure) => ({ layer: 'capture', ...failure })),
    ...resources.failures.map((failure) => ({ layer: 'resources', ...failure }))
  ]
  if (resources.pass) failures.push(...capturedImageFailures(component, resourceManifest))
  if (capture.pass && isFixedPageWidth(component)) {
    failures.push({ layer: 'transform', type: 'fixed-page-width', componentId: component.id })
  }
  if (failures.length > 0) {
    return { id: component.id ?? null, pass: false, status: 'failed', failures }
  }

  const settings = {}
  const schemaSettings = []
  const labels = editorLabels(component)
  for (const [domain, descriptor] of Object.entries(component.domains || {})) {
    if (descriptor.status !== 'captured') continue
    settings[domain] = settingValue(domain, descriptor.value, resourceManifest)
    for (const leaf of flattenSettings(settings[domain])) {
      const relativePath = leaf.path.join('.')
      const explicit = labels.get(relativePath) || labels.get(leaf.path.at(-1))
      schemaSettings.push({
        id: `${domain}.${relativePath}`,
        valuePath: `${domain}.${relativePath}`,
        domain,
        type: explicit?.type || leafType(leaf.value),
        label: explicit?.label || relativePath,
        sourceEvidence: [...descriptor.evidence]
      })
    }
  }

  return {
    id: component.id,
    type: component.type,
    pass: true,
    status: 'passed',
    failures: [],
    schema: {
      version: 1,
      componentType: component.type,
      settings: schemaSettings
    },
    settings
  }
}

