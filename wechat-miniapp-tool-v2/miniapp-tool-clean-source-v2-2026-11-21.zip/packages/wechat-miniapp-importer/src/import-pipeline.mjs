import { evaluateComponentAcceptance } from '../../import-foundation/component-acceptance.mjs'
import { evaluateResourceManifest } from '../../import-foundation/resource-contract.mjs'
import { normalizeMiniappCapture } from './normalize-capture.mjs'
import { transformComponent } from './transform-component.mjs'

function componentResult(component, captureResult, resources, resourceManifest, acceptanceEvidence) {
  const transform = transformComponent(component, resourceManifest)
  const expectedTargets = (component.domains?.dimensions?.value || []).map((item) => item.target).filter(Boolean)
  const expectedImageCount = component.domains?.images?.status === 'captured'
    ? component.domains.images.value.length
    : 0
  const acceptance = evaluateComponentAcceptance(acceptanceEvidence, { expectedTargets, expectedImageCount })
  const layers = {
    capture: captureResult,
    resources,
    transform,
    acceptance
  }
  const pass = Object.values(layers).every((layer) => layer.pass === true)
  const failures = Object.entries(layers).flatMap(([layer, result]) => (
    (result.failures || []).map((failure) => ({ layer, ...failure }))
  ))
  return {
    id: component.id,
    type: component.type,
    pass,
    status: pass ? 'passed' : 'failed',
    layers,
    failures,
    ...(transform.schema ? { schema: transform.schema, settings: transform.settings } : {})
  }
}

export function importMiniappCapture({ capture, resourceManifest, resourceVerification, acceptanceByComponent = {} } = {}) {
  const normalized = normalizeMiniappCapture(capture)
  const resources = resourceVerification ?? evaluateResourceManifest(resourceManifest)
  const components = {}
  const pages = normalized.pages.map((page) => {
    const assembledComponentIds = []
    const excludedComponentIds = []
    for (const component of page.components) {
      const captureResult = page.verification.componentResults[component.id]
      const result = componentResult(
        component,
        captureResult,
        resources,
        resourceManifest,
        acceptanceByComponent[component.id]
      )
      if (Object.hasOwn(components, component.id)) {
        result.pass = false
        result.status = 'failed'
        result.failures.push({ layer: 'assembly', type: 'duplicate-component-id', componentId: component.id })
      }
      components[component.id] = result
      if (result.pass) assembledComponentIds.push(component.id)
      else excludedComponentIds.push(component.id)
    }
    const pass = page.components.length > 0 && excludedComponentIds.length === 0
    return {
      id: page.id,
      route: page.route,
      pass,
      status: pass ? 'passed' : 'failed',
      assembledComponentIds,
      excludedComponentIds
    }
  })
  const pass = resources.pass && pages.every((page) => page.pass)
  return {
    schemaVersion: 1,
    platform: 'wechat-miniapp',
    pass,
    status: pass ? 'passed' : 'failed',
    resources,
    components,
    pages,
    summary: {
      pageCount: pages.length,
      passedPageCount: pages.filter((page) => page.pass).length,
      componentCount: Object.keys(components).length,
      passedComponentCount: Object.values(components).filter((component) => component.pass).length,
      failedComponentCount: Object.values(components).filter((component) => !component.pass).length
    }
  }
}

