import {
  REQUIRED_EDITOR_DATA_DOMAINS,
  evaluateEditorPage
} from '../../import-foundation/editor-data-contract.mjs'

function normalizeDomain(component, domain) {
  const captured = component.captured?.[domain]
  if (captured) {
    return {
      status: 'captured',
      value: captured.value,
      evidence: captured.evidence
    }
  }
  const omitted = component.notApplicable?.[domain]
  if (omitted) {
    return {
      status: 'not-applicable',
      reason: omitted.reason,
      evidence: omitted.evidence
    }
  }
  return undefined
}

function normalizeComponent(component) {
  const domains = {}
  for (const domain of REQUIRED_EDITOR_DATA_DOMAINS) {
    const normalized = normalizeDomain(component, domain)
    if (normalized) domains[domain] = normalized
  }
  return {
    id: component.id,
    type: component.type,
    sourceEvidence: Array.isArray(component.sourceEvidence) ? component.sourceEvidence : [],
    domains
  }
}

export function normalizeMiniappCapture(capture = {}) {
  if (capture.platform !== 'wechat-miniapp') {
    throw new TypeError('platform must be wechat-miniapp')
  }
  if (capture.schemaVersion !== 1) throw new TypeError('capture schemaVersion must be 1')
  if (!Array.isArray(capture.pages) || capture.pages.length === 0) {
    throw new TypeError('capture pages must be a non-empty array')
  }

  const pages = capture.pages.map((page) => {
    const components = Array.isArray(page.components)
      ? page.components.map(normalizeComponent)
      : []
    return {
      id: page.id,
      route: page.route,
      components,
      verification: evaluateEditorPage({ id: page.id, components })
    }
  })

  return {
    schemaVersion: 1,
    platform: 'wechat-miniapp',
    baseUrl: capture.baseUrl,
    pages,
    summary: {
      status: pages.every((page) => page.verification.pass) ? 'passed' : 'failed',
      pageCount: pages.length,
      componentCount: pages.reduce((sum, page) => sum + page.components.length, 0),
      failedComponentCount: pages.reduce(
        (sum, page) => sum + Object.values(page.verification.componentResults).filter((result) => !result.pass).length,
        0
      )
    }
  }
}

