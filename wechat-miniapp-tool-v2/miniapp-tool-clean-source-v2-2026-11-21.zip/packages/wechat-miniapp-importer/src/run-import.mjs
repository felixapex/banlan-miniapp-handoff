import { access, copyFile, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import path from 'node:path'

import { verifyFrozenResourceFiles } from '../../import-foundation/resource-contract.mjs'
import { freezeResourceGraph } from '../../import-foundation/resource-freezer.mjs'
import { importMiniappCapture } from './import-pipeline.mjs'

async function exists(target) {
  try {
    await access(target)
    return true
  } catch {
    return false
  }
}

async function readJson(file) {
  return JSON.parse(await readFile(file, 'utf8'))
}

async function writeJson(file, value) {
  await mkdir(path.dirname(file), { recursive: true })
  await writeFile(file, `${JSON.stringify(value, null, 2)}\n`, 'utf8')
}

function safeName(value) {
  const name = String(value || '').replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-+|-+$/g, '')
  if (!name) throw new TypeError('artifact id cannot be converted to a safe filename')
  return name
}

async function copyFrozenAssets(manifest, sourceRoot, outputRoot) {
  for (const resource of manifest.resources || []) {
    if (resource.status !== 'frozen') continue
    const source = path.resolve(sourceRoot, resource.localPath)
    const destination = path.resolve(outputRoot, resource.localPath)
    if (!path.relative(sourceRoot, source).startsWith('..') && !path.relative(outputRoot, destination).startsWith('..')) {
      await mkdir(path.dirname(destination), { recursive: true })
      await copyFile(source, destination)
    }
  }
}

export async function runMiniappImport({ captureDir, outputDir, fetchImpl = globalThis.fetch } = {}) {
  if (!captureDir || !outputDir) throw new TypeError('captureDir and outputDir are required')
  const sourceRoot = path.resolve(captureDir)
  const acceptedRoot = path.resolve(outputDir)
  if (await exists(acceptedRoot)) throw new Error(`output directory already exists: ${acceptedRoot}`)
  const parent = path.dirname(acceptedRoot)
  await mkdir(parent, { recursive: true })
  const stagingRoot = path.join(parent, `.${path.basename(acceptedRoot)}.staging-${process.pid}-${Date.now()}`)
  await mkdir(stagingRoot, { recursive: false })

  try {
    const capture = await readJson(path.join(sourceRoot, 'capture.json'))
    const acceptanceByComponent = await readJson(path.join(sourceRoot, 'acceptance.json'))
    const manifestFile = path.join(sourceRoot, 'resource-manifest.json')
    const preFrozen = await exists(manifestFile)
    let resourceManifest
    let resourceRoot
    if (preFrozen) {
      resourceManifest = await readJson(manifestFile)
      resourceRoot = sourceRoot
    } else {
      const documents = await readJson(path.join(sourceRoot, 'documents.json'))
      const frozen = await freezeResourceGraph({ baseUrl: capture.baseUrl, documents }, { outputDir: stagingRoot, fetchImpl })
      resourceManifest = frozen.manifest
      resourceRoot = stagingRoot
      await writeJson(path.join(stagingRoot, 'rewritten-documents.json'), frozen.documents)
    }
    const resourceVerification = await verifyFrozenResourceFiles(resourceManifest, resourceRoot)
    const verification = importMiniappCapture({
      capture,
      resourceManifest,
      resourceVerification,
      acceptanceByComponent
    })

    await writeJson(path.join(stagingRoot, 'resource-manifest.json'), resourceManifest)
    await writeJson(path.join(stagingRoot, 'verification.json'), verification)
    await writeJson(path.join(stagingRoot, 'manifest.json'), {
      schemaVersion: 1,
      platform: 'wechat-miniapp',
      status: verification.status,
      summary: verification.summary
    })

    for (const component of Object.values(verification.components)) {
      const directory = component.pass ? 'components' : 'rejected-components'
      await writeJson(path.join(stagingRoot, directory, `${safeName(component.id)}.json`), component)
    }
    for (const page of verification.pages) {
      if (page.pass) await writeJson(path.join(stagingRoot, 'pages', `${safeName(page.id)}.json`), page)
    }
    if (preFrozen && resourceVerification.pass) await copyFrozenAssets(resourceManifest, sourceRoot, stagingRoot)

    await rename(stagingRoot, acceptedRoot)
    return { exitCode: verification.pass ? 0 : 2, outputDir: acceptedRoot, verification }
  } catch (error) {
    await rm(stagingRoot, { recursive: true, force: true })
    throw error
  }
}

