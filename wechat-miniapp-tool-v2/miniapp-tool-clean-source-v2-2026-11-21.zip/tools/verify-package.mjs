import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readdir, readFile, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifestPath = path.join(root, 'FILE-MANIFEST-SHA256.txt');

async function filesBelow(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await filesBelow(absolute));
    else if (entry.isFile() && absolute !== manifestPath) files.push(absolute);
  }
  return files;
}

function sha256(filename) {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256');
    const input = createReadStream(filename);
    input.on('error', reject);
    input.on('data', chunk => hash.update(chunk));
    input.on('end', () => resolve(hash.digest('hex')));
  });
}

async function buildRows() {
  const files = await filesBelow(root);
  const rows = [];
  for (const filename of files) {
    const info = await stat(filename);
    const relative = path.relative(root, filename).split(path.sep).join('/');
    rows.push(`${await sha256(filename)}  ${info.size}  ${relative}`);
  }
  return rows;
}

if (process.argv.includes('--write')) {
  const rows = await buildRows();
  await writeFile(manifestPath, `${rows.join('\n')}\n`, 'utf8');
  console.log(JSON.stringify({ mode: 'write', files: rows.length, manifest: manifestPath }));
} else {
  const expected = (await readFile(manifestPath, 'utf8')).trim().split(/\r?\n/);
  const actual = await buildRows();
  const mismatches = [];
  const expectedMap = new Map(expected.map(row => [row.split('  ').slice(2).join('  '), row]));
  const actualMap = new Map(actual.map(row => [row.split('  ').slice(2).join('  '), row]));
  for (const [name, row] of expectedMap) if (actualMap.get(name) !== row) mismatches.push(name);
  for (const name of actualMap.keys()) if (!expectedMap.has(name)) mismatches.push(name);
  console.log(JSON.stringify({ mode: 'verify', expected: expected.length, actual: actual.length, mismatches }));
  if (mismatches.length) process.exitCode = 1;
}
