$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($PSScriptRoot)
$capture = Join-Path $root 'packages\wechat-miniapp-capture'
$importer = Join-Path $root 'packages\wechat-miniapp-importer'

Push-Location $capture
try {
    npm test
    if ($LASTEXITCODE -ne 0) { throw 'capture Node tests failed' }
    python -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw 'capture Python tests failed' }
} finally {
    Pop-Location
}

Push-Location $importer
try {
    npm test
    if ($LASTEXITCODE -ne 0) { throw 'importer tests failed' }
} finally {
    Pop-Location
}

Write-Host 'All source verification tests passed.'
