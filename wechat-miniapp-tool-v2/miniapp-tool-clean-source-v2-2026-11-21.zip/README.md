# 微信小程序执行与导入工具：干净源码

本包只包含正式源码、配置、测试、必要测试夹具和技术文档。它不包含 `node_modules`、缓存、临时运行目录、历史实验脚本、品牌批量数据、微信登录资料或后端代码。

## 代码目录

- `packages/wechat-miniapp-capture/`：小程序采集执行器。
- `packages/wechat-miniapp-importer/`：把采集证据转换为编辑器组件与页面。
- `packages/import-foundation/`：三类导入器共用的数据契约，包含 `editor-data-contract.mjs`。

采集器内部已经按职责拆分：

- `capture/core/`：品牌无关的配置、OCR、数据导出和界面探索。
- `capture/platforms/`：Android 与 Windows 设备/窗口适配。
- `capture/adapters/banlan/`：班兰参考小程序的专用适配，未写入通用引擎。
- `capture/verification/`：对账、补采和“有缺口就不通过”的验收逻辑。
- `platforms/wmpf/`：WMPF 本地桥接与 CDP 采集运行时。

## 安装与测试

```powershell
cd packages\wechat-miniapp-capture
npm ci
python -m pip install -r ..\..\requirements-windows.txt
npm test
python -m unittest discover -s tests -v

cd ..\wechat-miniapp-importer
npm test
```

也可以在包根目录执行：

```powershell
pwsh -File verify-source.ps1
```

离线环境请先把随交接提供的“离线依赖包”解压到
`packages/wechat-miniapp-capture/node_modules/`，再执行验证脚本。源码包本身故意不包含依赖目录。

本版实际验证数量为：采集器 Python 132 项、采集器 Node 26 项、导入器 16 项，共 174 项。

## 能力边界

采集器会为已发现的安全按钮保存点击前后截图、可见文字、接口响应、图片文件、哈希和失败原因，并在存在未核实项时保持未完成状态。

当前代码的离线与模拟通道测试通过，但不能声称“输入任意第三方小程序链接，就一定能后台取得整款小程序的所有数据”。未显现、无权限、未请求或服务端未返回的数据无法凭空取得；真实运行还受微信版本、账号风控、授权和目标小程序结构限制。

涉及微信、ADB、模拟器或 WMPF/Frida 的自动化，只能在取得授权的独立测试环境和专用账号中运行。不要用个人微信做批量自动点击。

禁止使用 Microsoft Edge。网页相关入口只允许使用隔离的 Google Chrome。
