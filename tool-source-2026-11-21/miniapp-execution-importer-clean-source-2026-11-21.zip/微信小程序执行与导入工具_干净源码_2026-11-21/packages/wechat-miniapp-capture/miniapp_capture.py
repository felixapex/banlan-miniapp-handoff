"""CLI for local Windows WeChat miniapp screenshots and product exports."""

import argparse
import json
from pathlib import Path
import subprocess
from urllib.request import Request, urlopen

from capture.config import require_e_output
from capture.export import collect_products, export_assets, export_images, write_catalog, write_detail_text
from capture.runner import load_target, run_capture, runtime_preflight

ACCOUNT_PAUSE = Path(__file__).resolve().parents[2] / "artifacts" / "isolated-android" / "ACCOUNT-AUTOMATION-PAUSED.txt"


def _fetch_image(url):
    with urlopen(Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=30) as response:
        if not response.headers.get("Content-Type", "").startswith("image/"):
            raise ValueError("CDN did not return an image")
        return response.read(100 * 1024 * 1024 + 1)


def do_export(responses, output):
    responses = Path(responses).resolve()
    require_e_output(str(responses))
    output = Path(output).resolve()
    require_e_output(str(output))
    records = []
    for file in sorted(responses.glob("*.json")):
        if file.name == "ready.json":
            continue
        record = json.loads(file.read_text(encoding="utf-8"))
        if isinstance(record, dict) and "data" in record:
            record["source"] = file.name
            records.append(record)
    products = collect_products(records)
    if not products:
        raise RuntimeError(f"No product records found in {responses}")
    manifest = export_images(products, output, _fetch_image)
    write_catalog(manifest, output)
    write_detail_text(records, output)
    asset_file = responses / "image-urls.txt"
    assets = export_assets(asset_file.read_text(encoding="utf-8").splitlines(), output.parent / "assets", _fetch_image) if asset_file.is_file() else {"assets": []}
    failures = sum(image["status"] == "error" for product in manifest["products"] for image in product["images"])
    failures += sum(asset["status"] == "error" for asset in assets["assets"])
    print(f"products={len(products)} images={sum(len(p['images']) for p in manifest['products'])} assets={len(assets['assets'])} failures={failures}")
    if failures:
        raise RuntimeError(f"{failures} image downloads failed; inspect manifest.json")


def main():
    parser = argparse.ArgumentParser(description="Capture a miniapp through already-signed-in Windows WeChat. No Edge or second WeChat is launched.")
    commands = parser.add_subparsers(dest="command", required=True)
    doctor = commands.add_parser("doctor", help="Read-only runtime checks")
    doctor.add_argument("--config", required=True)
    capture = commands.add_parser("capture", help="Open, click, screenshot, and export")
    capture.add_argument("--config", required=True)
    capture.add_argument("--output", required=True)
    capture.add_argument("--already-open", action="store_true", help="Use a target miniapp window that is already open")
    details = commands.add_parser("details", help="Open each observed product detail and capture its response and screen")
    details.add_argument("--config", required=True)
    details.add_argument("--source-responses", required=True, help="Captured list responses on E:")
    details.add_argument("--output", required=True)
    details.add_argument("--limit", type=int, help="First N products for a live smoke check")
    export = commands.add_parser("export", help="Download original product images from captured JSON")
    export.add_argument("--responses", required=True)
    export.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "export":
        do_export(args.responses, args.output)
        return
    if args.command in {"capture", "details"} and ACCOUNT_PAUSE.exists():
        raise RuntimeError(f"WeChat account automation is paused: {ACCOUNT_PAUSE}")
    config = load_target(args.config)
    package = Path(__file__).parent
    runtime_preflight(package, config["wmpfVersion"])
    print(f"own bridge version {config['wmpfVersion']}: ready")
    subprocess.run(["node", "--version"], check=True)
    if args.command == "doctor":
        subprocess.run(["node", str(package / "bridge/server.mjs"), "--probe", "--version", str(config["wmpfVersion"])], check=True)
        from capture.windows_ui import _windows
        wechat_count = len(_windows("微信", "Weixin.exe"))
        target_count = len(_windows(config["title"], "WeChatAppEx.exe"))
        print("signed-in WeChat main window candidates:", wechat_count)
        print("target miniapp window candidates:", target_count)
        print("doctor checked; no UI input sent")
        if target_count > 1 or (target_count != 1 and wechat_count != 1):
            raise RuntimeError("Capture requires one visible target miniapp or one visible signed-in WeChat window")
        return
    output = Path(args.output).resolve()
    require_e_output(str(output))
    if args.command == "details":
        source = Path(args.source_responses).resolve()
        require_e_output(str(source))
        if args.limit is not None and args.limit < 1:
            raise ValueError("--limit must be positive")
        run_capture(args.config, output, detail_source=source, detail_limit=args.limit)
    else:
        run_capture(args.config, output, open_target=not args.already_open)
    do_export(output / "responses", output / "products")


if __name__ == "__main__":
    try:
        main()
    except (FileNotFoundError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        raise SystemExit(f"capture error: {error}") from None
