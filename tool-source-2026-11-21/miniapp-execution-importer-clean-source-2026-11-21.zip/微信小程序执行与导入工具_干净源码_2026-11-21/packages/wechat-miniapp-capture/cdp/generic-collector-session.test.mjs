import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';

const packageDir = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const brandsRoot = path.resolve(packageDir, '../../artifacts/brands');

async function until(predicate, timeout = 10000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('timed out waiting for collector state');
}

test('generic collector publishes one live AppID-bound session and clears it on disconnect', { timeout: 20000 }, async t => {
  const brand = `testcollector${process.pid}`;
  const run = path.join(brandsRoot, brand, 'runs', `session${Date.now()}`);
  fs.mkdirSync(run, { recursive: true });
  fs.writeFileSync(path.join(run, 'input.json'), JSON.stringify({ link: '#小程序://测试/abcdefgh' }));
  const server = new WebSocketServer({ host: '127.0.0.1', port: 0 });
  await new Promise(resolve => server.once('listening', resolve));
  let currentProduct = 'p1';
  server.on('connection', socket => socket.on('message', bytes => {
    const command = JSON.parse(bytes.toString());
    if (command.method === 'Runtime.enable') {
      socket.send(JSON.stringify({ id: command.id, result: {} }));
      socket.send(JSON.stringify({ method: 'Network.requestWillBeSent', params: {
        requestId: 'early-request', request: { method: 'GET', url: 'https://example.com/first-screen' },
      } }));
      socket.send(JSON.stringify({ method: 'Network.responseReceived', params: {
        requestId: 'early-request', response: { url: 'https://example.com/first-screen',
          status: 200, mimeType: 'application/json' },
      } }));
      socket.send(JSON.stringify({ method: 'Network.loadingFinished', params: { requestId: 'early-request' } }));
      return;
    }
    if (command.method === 'Network.getResponseBody') {
      setTimeout(() => socket.send(JSON.stringify({ id: command.id, result: {
        body: '{"product":"captured"}', base64Encoded: false,
      } })), 250);
      return;
    }
    let result = {};
    if (command.method === 'Runtime.evaluate') {
      const expression = command.params?.expression || '';
      if (expression.includes('getCurrentPages'))
        result = { result: { value: JSON.stringify([{ route: 'pages/product/detail', options: { id: currentProduct } }]) } };
      else if (expression.includes('wx.redirectTo')) {
        currentProduct = 'p2';
        result = { result: { value: 'sent' } };
      } else result = { result: { value: 'wx0123456789abcdef' } };
    }
    socket.send(JSON.stringify({ id: command.id, result }));
  }));
  let child;
  t.after(async () => {
    if (child && child.exitCode === null) child.kill();
    for (const socket of server.clients) socket.terminate();
    await new Promise(resolve => server.close(resolve));
    const target = path.resolve(brandsRoot, brand);
    if (!target.startsWith(brandsRoot + path.sep)) throw new Error('unsafe cleanup path');
    fs.rmSync(target, { recursive: true, force: true });
  });
  const sessionId = 'b'.repeat(32);
  child = spawn(process.execPath, ['cdp/generic-collector.mjs', '--output', run,
    '--url', `ws://127.0.0.1:${server.address().port}`, '--session-id', sessionId],
  { cwd: packageDir, stdio: ['pipe', 'pipe', 'pipe'] });
  let childOutput = '';
  child.stdout.on('data', chunk => { childOutput += chunk.toString(); });
  child.stderr.on('data', chunk => { childOutput += chunk.toString(); });
  const readyPath = path.join(run, 'collector-ready.json');
  const heartbeatPath = path.join(run, 'collector-heartbeat.json');
  await until(() => fs.existsSync(readyPath) && fs.existsSync(heartbeatPath));
  const ready = JSON.parse(fs.readFileSync(readyPath, 'utf8'));
  const heartbeat = JSON.parse(fs.readFileSync(heartbeatPath, 'utf8'));
  assert.equal(ready.sessionId, sessionId);
  assert.equal(ready.appId, 'wx0123456789abcdef');
  assert.equal(heartbeat.sessionId, sessionId);
  const commandFile = id => path.join(run, 'commands', `${id}.json`);
  child.stdin.write(JSON.stringify({ id: 11, action: 'inspectPages' }) + '\n');
  await until(() => fs.existsSync(commandFile(11)));
  assert.equal(JSON.parse(fs.readFileSync(commandFile(11), 'utf8')).pages[0].options.id, 'p1');
  child.stdin.write(JSON.stringify({ id: 12, action: 'openObservedDetail',
    route: 'pages/product/detail', paramKey: 'id', productId: 'p2' }) + '\n');
  await until(() => fs.existsSync(commandFile(12)));
  assert.equal(JSON.parse(fs.readFileSync(commandFile(12), 'utf8')).status, 'ok');
  child.stdin.write(JSON.stringify({ id: 13, action: 'inspectPages' }) + '\n');
  await until(() => fs.existsSync(commandFile(13)));
  assert.equal(JSON.parse(fs.readFileSync(commandFile(13), 'utf8')).pages[0].options.id, 'p2');
  const socket = [...server.clients][0];
  socket.send(JSON.stringify({ method: 'Network.requestWillBeSent', params: {
    requestId: 'test-request', request: { method: 'GET', url: 'https://example.com/product' },
  } }));
  socket.send(JSON.stringify({ method: 'Network.responseReceived', params: {
    requestId: 'test-request', response: { url: 'https://example.com/product', status: 200,
      mimeType: 'application/json' },
  } }));
  socket.send(JSON.stringify({ method: 'Network.loadingFinished', params: { requestId: 'test-request' } }));
  await until(() => {
    if (!fs.existsSync(heartbeatPath)) {
      if (child.exitCode !== null) throw new Error(`collector exited ${child.exitCode}: ${childOutput}`);
      return false;
    }
    return JSON.parse(fs.readFileSync(heartbeatPath, 'utf8')).pendingBodies >= 1;
  });
  await until(() => {
    if (!fs.existsSync(heartbeatPath)) {
      if (child.exitCode !== null) throw new Error(`collector exited ${child.exitCode}: ${childOutput}`);
      return false;
    }
    return JSON.parse(fs.readFileSync(heartbeatPath, 'utf8')).pendingBodies === 0 &&
      fs.readFileSync(path.join(run, 'responses.jsonl'), 'utf8').includes('"status":"saved"');
  });
  await until(() => fs.readFileSync(path.join(run, 'responses.jsonl'), 'utf8').trim().split('\n').length === 2);
  const records = fs.readFileSync(path.join(run, 'responses.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
  assert.ok(records.some(record => record.url.endsWith('/first-screen') && record.preIdentity === true));
  assert.ok(records.every(record => record.requestMethod === 'GET'));
  for (const socket of server.clients) socket.close();
  await until(() => !fs.existsSync(readyPath) && !fs.existsSync(heartbeatPath));
});
