// Navigate observed miniapp detail routes and capture each page in the visible WeChat window.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import WebSocket from 'ws';
import { validateBrandRunPath } from './generic-policy.mjs';

const execFileAsync = promisify(execFile);
function option(name, fallback) {
  const index = process.argv.indexOf(name);
  return index < 0 ? fallback : process.argv[index + 1];
}
const output = option('--output');
const title = option('--title');
const limit = Number(option('--limit', '1000'));
const longRunArg = option('--long-run');
const startIndex = Number(option('--start-index', '1'));
if (!output || !title || !Number.isInteger(limit) || limit < 1 || limit > 1000) throw new Error('invalid arguments');
if (!Number.isInteger(startIndex) || startIndex < 1) throw new Error('invalid start index');
const run = validateBrandRunPath(output, fileURLToPath(new URL('../../../artifacts/brands/', import.meta.url)));
const longRun = longRunArg ? validateBrandRunPath(longRunArg, fileURLToPath(new URL('../../../artifacts/brands/', import.meta.url))) : null;
if (longRun && (longRun.brand !== run.brand || JSON.parse(fs.readFileSync(path.join(longRun.output, 'input.json'), 'utf8')).link !== JSON.parse(fs.readFileSync(path.join(run.output, 'input.json'), 'utf8')).link))
  throw new Error('long-page output must belong to the same miniapp share code');
const pages = JSON.parse(fs.readFileSync(path.join(run.output, 'pages.json'), 'utf8'));
const route = pages.pages.find((page) => /^[a-zA-Z0-9/_-]+$/.test(page.route) && page.options?.id)?.route;
if (!route || !/^wx[0-9a-f]{16}$/i.test(pages.appId)) throw new Error('observed detail route and AppID are required');
const source = JSON.parse(fs.readFileSync(path.join(run.output, 'catalog', 'all-products.json'), 'utf8'));
const productList = source.products.filter((product) => /^[a-zA-Z0-9_-]{1,80}$/.test(String(product.id)));
const screenshotDir = path.join(run.output, 'screenshots', 'products');
if (!longRun) fs.mkdirSync(screenshotDir, { recursive: true });
const manifestPath = longRun ? path.join(longRun.output, 'product-long-results.jsonl') : path.join(screenshotDir, 'manifest.jsonl');
const already = new Set();
const latest = new Map();
if (fs.existsSync(manifestPath)) for (const line of fs.readFileSync(manifestPath, 'utf8').split(/\r?\n/)) {
  if (!line) continue;
  const entry = JSON.parse(line);
  latest.set(entry.id, entry);
}
for (const [id, entry] of latest) {
  if (entry.status !== 'saved') continue;
  const owner = longRun || run;
  if (longRun) {
    const file = path.join(owner.output, entry.manifest);
    if (fs.existsSync(file) && JSON.parse(fs.readFileSync(file, 'utf8')).steps.at(-1)?.endOfPage) already.add(id);
  } else if (fs.existsSync(path.join(owner.output, entry.file))) already.add(id);
}
const packageDir = fileURLToPath(new URL('../', import.meta.url));
const captureScript = path.join(packageDir, 'experiments', 'act-visible-miniapp.py');
const ws = new WebSocket('ws://127.0.0.1:62000');
let nextId = 10000;
let contextId = 0;
const pending = new Map();
function call(method, params = {}, timeout = 5000) {
  return new Promise((resolve, reject) => {
    const id = nextId++;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`${method} timeout`)); }, timeout);
    pending.set(id, { resolve, reject, timer });
    ws.send(JSON.stringify({ id, method, params }));
  });
}
ws.on('message', (bytes) => {
  let message;
  try { message = JSON.parse(bytes.toString()); } catch { return; }
  const wait = pending.get(message.id);
  if (!wait) return;
  pending.delete(message.id);
  clearTimeout(wait.timer);
  if (message.error) wait.reject(new Error(JSON.stringify(message.error)));
  else wait.resolve(message.result);
});
await new Promise((resolve, reject) => { ws.once('open', resolve); ws.once('error', reject); });
try {
  await call('Runtime.enable', {}, 1000).catch(() => {});
  const probe = '(function(){try{return wx.getAccountInfoSync().miniProgram.appId}catch(_){return ""}})()';
  for (let id = 1; id <= 20; id++) {
    try {
      const result = await call('Runtime.evaluate', { expression: probe, contextId: id, returnByValue: true }, 1000);
      if (result?.result?.value === pages.appId) { contextId = id; break; }
    } catch { /* context absent */ }
  }
  if (!contextId) throw new Error('miniapp AppID does not match observed run');
  const initial = await call('Runtime.evaluate', { expression: 'JSON.stringify(getCurrentPages().slice(-1).map(p=>p.route))', contextId, returnByValue: true });
  let onDetail = JSON.parse(initial.result?.value || '[]')[0] === route;
  let saved = 0;
  let attempted = 0;
  for (let productIndex = startIndex - 1; productIndex < productList.length; productIndex++) {
    const product = productList[productIndex];
    const id = String(product.id);
    if (already.has(id)) continue;
    const oldPosition = productList.findIndex((item) => String(item.id) === id) + 1;
    const oldShot = path.join(run.output, `product-detail-${oldPosition}.bmp`);
    if (!longRun && oldPosition <= 10 && fs.existsSync(oldShot)) {
      fs.appendFileSync(manifestPath, `${JSON.stringify({ id, status: 'saved', file: path.relative(run.output, oldShot).replaceAll('\\', '/'), source: 'prior live screenshot' })}\n`);
      saved++;
      continue;
    }
    if (attempted >= limit) break;
    attempted++;
    const target = path.join(screenshotDir, `${id}.bmp`);
    try {
      const url = `/${route}?id=${encodeURIComponent(id)}`;
      const expression = `wx.${onDetail ? 'redirectTo' : 'navigateTo'}({url:${JSON.stringify(url)}}); "sent"`;
      const result = await call('Runtime.evaluate', { expression, contextId, returnByValue: true }, 10000);
      if (result.exceptionDetails || result.result?.value !== 'sent') throw new Error('navigation rejected');
      await new Promise((resolve) => setTimeout(resolve, 1800));
      const pageCheck = await call('Runtime.evaluate', { expression: 'JSON.stringify(getCurrentPages().slice(-1).map(p=>({route:p.route,id:p.options?.id})))', contextId, returnByValue: true });
      const current = JSON.parse(pageCheck.result?.value || '[]')[0];
      if (current?.route !== route || String(current.id) !== id) throw new Error('active page does not match product');
      onDetail = true;
      if (longRun) {
        let slug = `product-${id}`;
        for (let retry = 2; fs.existsSync(path.join(longRun.output, 'screenshots', 'long-pages', slug)); retry++)
          slug = `product-${id}-retry-${retry}`;
        const { stdout } = await execFileAsync('python', ['-m', 'capture.full_page', '--run', longRun.output,
          '--title', title, '--slug', slug, '--max-scrolls', '120', '--header-reference',
          path.join(run.output, 'product-detail-1.bmp')], { cwd: packageDir, timeout: 300000 });
        const result = JSON.parse(stdout.trim());
        if (!result.endOfPage) throw new Error(`long page did not reach bottom after ${result.screens} screens`);
        const manifest = `screenshots/long-pages/${slug}/manifest.json`;
        fs.appendFileSync(manifestPath, `${JSON.stringify({ id, status: 'saved', manifest, screens: result.screens, at: new Date().toISOString() })}\n`);
      } else {
        await execFileAsync('python', [captureScript, '--title', title, '--action', 'screenshot', '--width', '430', '--height', '788', '--name', id, '--output', screenshotDir], { cwd: packageDir, timeout: 15000 });
        const file = path.relative(run.output, target).replaceAll('\\', '/');
        fs.appendFileSync(manifestPath, `${JSON.stringify({ id, status: 'saved', file, at: new Date().toISOString() })}\n`);
      }
      saved++;
      console.log(`saved ${saved} ${id}`);
    } catch (error) {
      fs.appendFileSync(manifestPath, `${JSON.stringify({ id, status: 'error', error: error.message })}\n`);
      console.error(`failed ${id}: ${error.message}`);
    }
  }
  console.log(JSON.stringify({ products: productList.length, savedThisRun: saved, attempted }));
} finally {
  ws.close();
}
