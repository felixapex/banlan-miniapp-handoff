// Capture responses from one live, signed-in WeChat miniapp CDP session.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import WebSocket from 'ws';
import { classifyResponse, validateBrandRunPath } from './generic-policy.mjs';
import { createSessionStatus } from './session-status.mjs';

function option(name, fallback) {
  const index = process.argv.indexOf(name);
  return index < 0 ? fallback : process.argv[index + 1];
}

const outputDir = option('--output');
const cdpUrl = option('--url', 'ws://127.0.0.1:62000');
const timeoutMs = Number(option('--timeout', '30000'));
const sessionId = option('--session-id', crypto.randomBytes(16).toString('hex'));
const brandsRoot = fileURLToPath(new URL('../../../artifacts/brands/', import.meta.url));
if (!outputDir) throw new Error('--output is required');
const run = validateBrandRunPath(outputDir, brandsRoot);
if (!fs.existsSync(path.join(run.output, 'input.json'))) throw new Error('brand run input.json is required');
const endpoint = new URL(cdpUrl);
if (endpoint.protocol !== 'ws:' || !['127.0.0.1', 'localhost'].includes(endpoint.hostname))
  throw new Error('CDP must use local loopback');
if (!Number.isInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > 120000)
  throw new Error('invalid timeout');
if (!/^[0-9a-f]{32}$/i.test(sessionId)) throw new Error('invalid session ID');

const responsesDir = path.join(run.output, 'responses');
fs.mkdirSync(responsesDir, { recursive: true });
const readyPath = path.join(run.output, 'collector-ready.json');
fs.rmSync(readyPath, { force: true });
fs.rmSync(path.join(run.output, 'collector-heartbeat.json'), { force: true });
const ws = new WebSocket(cdpUrl);
let nextId = 10000;
let appId = null;
let contextId = null;
let sessionStatus = null;
let heartbeatTimer = null;
const existing = fs.readdirSync(responsesDir).filter((name) => /^\d{5}-[0-9a-f]{16}\./.test(name));
let captureCount = existing.reduce((max, name) => Math.max(max, Number(name.slice(0, 5))), 0);
let totalBytes = existing.reduce((sum, name) => sum + fs.statSync(path.join(responsesDir, name)).size, 0);
const pending = new Map();
const inFlight = new Map();
const requestMethods = new Map();
const earlyEvents = [];
let earlyOverflow = false;
let pendingBodies = 0;
const MAX_BODY = 20 * 1024 * 1024;
const MAX_TOTAL = 1024 * 1024 * 1024;
const MAX_COUNT = 10000;

function call(method, params = {}, timeout = 5000) {
  return new Promise((resolve, reject) => {
    if (ws.readyState !== WebSocket.OPEN) return reject(new Error('CDP disconnected'));
    const id = nextId++;
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(new Error(`${method} timed out`));
    }, timeout);
    pending.set(id, { resolve, reject, timer });
    ws.send(JSON.stringify({ id, method, params }));
  });
}

function record(value) {
  fs.appendFileSync(path.join(run.output, 'responses.jsonl'), `${JSON.stringify(value)}\n`);
}

function pulseStatus() {
  if (sessionStatus) sessionStatus.pulse({ inFlight: inFlight.size, pendingBodies });
}

async function saveBody(requestId, meta) {
  try {
    if (captureCount >= MAX_COUNT || totalBytes >= MAX_TOTAL) {
      record({ ...meta, status: 'limit-reached' });
      return;
    }
    const result = await call('Network.getResponseBody', { requestId }, 10000);
    const body = result.base64Encoded ? Buffer.from(result.body, 'base64') : Buffer.from(result.body, 'utf8');
    if (body.length > MAX_BODY || totalBytes + body.length > MAX_TOTAL) {
      record({ ...meta, status: 'body-too-large', bytes: body.length });
      return;
    }
    const hash = crypto.createHash('sha256').update(body).digest('hex');
    const name = `${String(++captureCount).padStart(5, '0')}-${hash.slice(0, 16)}${meta.extension}`;
    fs.writeFileSync(path.join(responsesDir, name), body);
    totalBytes += body.length;
    record({ ...meta, status: 'saved', file: `responses/${name}`, bytes: body.length, sha256: hash });
    console.log(`saved ${captureCount} ${meta.kind} ${body.length} bytes ${new URL(meta.url).hostname}`);
  } catch (error) {
    record({ ...meta, status: 'capture-error', error: error.message });
  } finally {
    pendingBodies -= 1;
    pulseStatus();
  }
}

function handleNetworkEvent(message, preIdentity = false) {
  const params = message.params || {};
  if (message.method === 'Network.requestWillBeSent') {
    const method = params.request?.method;
    if (typeof method === 'string' && /^[A-Z]{3,10}$/.test(method))
      requestMethods.set(params.requestId, method);
  } else if (message.method === 'Network.responseReceived') {
    const response = params.response || {};
    const kind = classifyResponse(response.url, response.status, response.mimeType);
    if (kind) inFlight.set(params.requestId, {
      url: response.url, httpStatus: response.status, mimeType: response.mimeType,
      kind: kind.kind, extension: kind.extension, observedAt: new Date().toISOString(), preIdentity,
      requestMethod: requestMethods.get(params.requestId) || 'unknown',
    });
    pulseStatus();
  } else if (message.method === 'Network.loadingFinished') {
    const meta = inFlight.get(params.requestId);
    inFlight.delete(params.requestId);
    requestMethods.delete(params.requestId);
    if (meta) pendingBodies += 1;
    pulseStatus();
    if (meta) void saveBody(params.requestId, meta);
  } else if (message.method === 'Network.loadingFailed') {
    const meta = inFlight.get(params.requestId);
    inFlight.delete(params.requestId);
    requestMethods.delete(params.requestId);
    if (meta) record({ ...meta, status: 'load-failed' });
    pulseStatus();
  }
}

ws.on('message', (bytes) => {
  let message;
  try { message = JSON.parse(bytes.toString()); } catch { return; }
  const waiting = pending.get(message.id);
  if (waiting) {
    clearTimeout(waiting.timer);
    pending.delete(message.id);
    if (message.error) waiting.reject(new Error(JSON.stringify(message.error)));
    else waiting.resolve(message.result);
    return;
  }
  if (!appId) {
    if (typeof message.method === 'string' && message.method.startsWith('Network.')) {
      if (earlyEvents.length < 5000) earlyEvents.push(message);
      else earlyOverflow = true;
    }
    return;
  }
  handleNetworkEvent(message);
});

ws.on('open', async () => {
  try {
    // The bridge queues this subscription until the miniapp socket arrives.
    await call('Network.enable', {}, 1000).catch(() => {});
    await call('Runtime.enable', {}, 1000).catch(() => {});
    const probe = '(function(){try{return wx.getAccountInfoSync().miniProgram.appId}catch(_){return ""}})()';
    const deadline = Date.now() + timeoutMs;
    while (!appId && Date.now() < deadline && ws.readyState === WebSocket.OPEN) {
      for (let id = 1; id <= 20; id++) {
        try {
          const result = await call('Runtime.evaluate', { expression: probe, contextId: id, returnByValue: true }, 1000);
          const value = result?.result?.value;
          if (/^wx[0-9a-f]{16}$/i.test(value || '')) { appId = value; contextId = id; break; }
        } catch { /* Context may not exist yet. */ }
      }
      if (!appId) await new Promise((resolve) => setTimeout(resolve, 500));
    }
    if (!appId) throw new Error('miniapp AppID was not found');
    await call('Network.enable');
    sessionStatus = createSessionStatus(run.output, { sessionId, appId, contextId, brand: run.brand });
    sessionStatus.ready();
    pulseStatus();
    for (const event of earlyEvents) handleNetworkEvent(event, true);
    earlyEvents.length = 0;
    if (earlyOverflow) record({ status: 'capture-error', error: 'early network event buffer exceeded' });
    heartbeatTimer = setInterval(() => {
      try { pulseStatus(); }
      catch (error) { console.error(`heartbeat error: ${error.message}`); process.exitCode = 1; ws.close(); }
    }, 1000);
    heartbeatTimer.unref();
    console.log(`ready appId=${appId} context=${contextId}`);
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
    ws.close();
  }
});

ws.on('close', () => {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  if (sessionStatus) sessionStatus.close();
  for (const wait of pending.values()) { clearTimeout(wait.timer); wait.reject(new Error('CDP disconnected')); }
  pending.clear();
  process.stdin.pause();
});
ws.on('error', (error) => { console.error(error.message); process.exitCode = 1; process.stdin.pause(); });
process.once('exit', () => { if (sessionStatus) sessionStatus.close(); });

let inputBuffer = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  inputBuffer += chunk;
  let newline;
  while ((newline = inputBuffer.indexOf('\n')) >= 0) {
    const line = inputBuffer.slice(0, newline);
    inputBuffer = inputBuffer.slice(newline + 1);
    void handleCommand(line);
  }
});

async function handleCommand(line) {
  let command;
  let reply;
  try {
    command = JSON.parse(line);
    if (!appId || !Number.isSafeInteger(command.id)) throw new Error('collector is not ready');
    if (command.action === 'inspectPages') {
      const expression = 'JSON.stringify(getCurrentPages().map(p=>({route:p.route,options:p.options})))';
      const result = await call('Runtime.evaluate', { expression, contextId, returnByValue: true });
      if (result.exceptionDetails || typeof result.result?.value !== 'string') throw new Error('page inspection failed');
      const pages = JSON.parse(result.result.value);
      const observation = { appId, sessionId, pages, observedAt: new Date().toISOString() };
      fs.writeFileSync(path.join(run.output, 'pages.json'), JSON.stringify(observation, null, 2));
      fs.appendFileSync(path.join(run.output, 'pages-observed.jsonl'), JSON.stringify(observation) + '\n');
      reply = { status: 'ok', pages };
      console.log(`pages inspected ${pages.length}`);
    } else if (command.action === 'openObservedDetail') {
      const history = fs.readFileSync(path.join(run.output, 'pages-observed.jsonl'), 'utf8')
        .split('\n').filter(Boolean).map(JSON.parse);
      if (!history.some((observation) => observation.appId === appId &&
          observation.sessionId === sessionId && observation.pages.some((page) =>
            page.route === command.route && Object.hasOwn(page.options || {}, command.paramKey))))
        throw new Error('route and product parameter were not observed in this session');
      if (!/^[a-zA-Z0-9_/-]{1,160}$/.test(command.route || '') ||
          !/^[a-zA-Z0-9_-]{1,40}$/.test(command.paramKey || ''))
        throw new Error('invalid observed route or parameter');
      if (!/^[a-zA-Z0-9_-]{1,80}$/.test(command.productId || '')) throw new Error('invalid detail ID');
      const url = `/${command.route}?${encodeURIComponent(command.paramKey)}=${encodeURIComponent(command.productId)}`;
      const expression = `wx.redirectTo({url:${JSON.stringify(url)}}); "sent"`;
      const result = await call('Runtime.evaluate', { expression, contextId, returnByValue: true });
      if (result.exceptionDetails || result.result?.value !== 'sent') throw new Error('navigation failed');
      reply = { status: 'ok', route: command.route, paramKey: command.paramKey, productId: command.productId };
      console.log(`detail opened ${command.productId}`);
    } else {
      throw new Error('unsupported command');
    }
  } catch (error) {
    reply = { status: 'error', error: error.message };
    console.error(`command ${command?.id ?? '?'}: ${error.message}`);
  } finally {
    if (Number.isSafeInteger(command?.id) && command.id >= 0) {
      const commandDir = path.join(run.output, 'commands');
      fs.mkdirSync(commandDir, { recursive: true });
      const target = path.join(commandDir, `${command.id}.json`);
      fs.writeFileSync(target + '.tmp', JSON.stringify({ id: command.id, appId, sessionId, ...reply }));
      fs.renameSync(target + '.tmp', target);
    }
  }
}
