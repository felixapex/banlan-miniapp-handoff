import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from capture.reconcile_data import reconcile_data
from capture.retry_details import retry_missing_details
from tests.test_data_reconciliation import save_response
from tests.test_retry_assets import Response


def mark_get(run, file):
    ledger = run / 'responses.jsonl'
    rows = [json.loads(line) for line in ledger.read_text(encoding='utf-8').splitlines()]
    for row in rows:
        if row['file'] == file:
            row['requestMethod'] = 'GET'
    ledger.write_text(''.join(json.dumps(row) + '\n' for row in rows), encoding='utf-8')


class RetryDetailsTests(unittest.TestCase):
    def test_replays_observed_banlan_query_detail_without_changing_other_parameters(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json',
                          'https://api.example/xcx/custom/good/findPageByCid?cid=121&start=1&limit=2',
                          'json', b'{"page":{"totalRow":2,"list":[{"id":"p1","price":100},{"id":"p2","price":200}]}}')
            save_response(run, 'p1.json',
                          'https://api.example/xcx/custom/good/detail?gid=p1&sale_id=shop1',
                          'json', b'{"good":{"id":"p1","title":"First sofa"}}')
            mark_get(run, 'responses/p1.json')
            audit = reconcile_data(run)
            self.assertEqual([item['id'] for item in audit['missingProductDetails']], ['p2'])
            seen = []
            def open_url(request, timeout):
                seen.append(request.full_url)
                return Response(b'{"good":{"id":"p2","title":"Second sofa"}}',
                                'application/json', request.full_url)
            with patch('capture.retry_details.urlopen', side_effect=open_url):
                retry = retry_missing_details(run, audit)
            self.assertEqual(retry['saved'], 1)
            self.assertEqual(seen, ['https://api.example/xcx/custom/good/detail?gid=p2&sale_id=shop1'])
            self.assertEqual(reconcile_data(run)['missingProductDetails'], [])

    def test_replays_only_observed_get_detail_pattern_and_validates_product_id(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json', 'https://api.example/products?page=1', 'json',
                          b'{"data":{"total":2,"items":[{"id":"p1"},{"id":"p2"}]}}')
            save_response(run, 'p1.json', 'https://api.example/products/p1', 'json',
                          b'{"product":{"id":"p1","description":"First sofa"}}')
            mark_get(run, 'responses/p1.json')
            before = reconcile_data(run)
            self.assertEqual([item['id'] for item in before['missingProductDetails']], ['p2'])
            seen = []
            def open_url(request, timeout):
                seen.append(request.full_url)
                return Response(b'{"product":{"id":"p2","description":"Second sofa"}}',
                                'application/json', request.full_url)
            with patch('capture.retry_details.urlopen', side_effect=open_url):
                retry = retry_missing_details(run, before)
            self.assertEqual(seen, ['https://api.example/products/p2'])
            self.assertEqual(retry['saved'], 1)
            self.assertEqual(reconcile_data(run)['missingProductDetails'], [])

    def test_unknown_method_does_not_guess_detail_url(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json', 'https://api.example/products?page=1', 'json',
                          b'{"data":{"total":2,"items":[{"id":"p1"},{"id":"p2"}]}}')
            save_response(run, 'p1.json', 'https://api.example/products/p1', 'json',
                          b'{"product":{"id":"p1","description":"First sofa"}}')
            before = reconcile_data(run)
            with patch('capture.retry_details.urlopen') as open_url:
                retry = retry_missing_details(run, before)
            open_url.assert_not_called()
            self.assertEqual(retry['saved'], 0)
            self.assertEqual(retry['skipped'], 1)

    def test_wrong_product_response_is_failure_and_does_not_enter_ledger(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json', 'https://api.example/products?page=1', 'json',
                          b'{"data":{"total":2,"items":[{"id":"p1"},{"id":"p2"}]}}')
            save_response(run, 'p1.json', 'https://api.example/products/p1', 'json',
                          b'{"product":{"id":"p1","description":"First sofa"}}')
            mark_get(run, 'responses/p1.json')
            before = reconcile_data(run)
            with patch('capture.retry_details.urlopen', return_value=Response(
                    b'{"product":{"id":"p9","description":"Wrong"}}',
                    'application/json', 'https://api.example/products/p2')):
                retry = retry_missing_details(run, before)
            self.assertEqual(retry['failed'], 1)
            self.assertEqual(len((run / 'responses.jsonl').read_text(encoding='utf-8').splitlines()), 2)
            self.assertEqual(len(reconcile_data(run)['missingProductDetails']), 1)

    def test_recovered_json_does_not_pass_without_detail_screenshot(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json', 'https://api.example/products?page=1', 'json',
                          b'{"data":{"total":2,"items":[{"id":"p1"},{"id":"p2"}]}}')
            save_response(run, 'p1.json', 'https://api.example/products/p1', 'json',
                          b'{"product":{"id":"p1","description":"First sofa"}}')
            mark_get(run, 'responses/p1.json')
            (run / 'capture.json').write_text(json.dumps({'kind': 'visible-miniapp-capture', 'attempts': []}),
                                              encoding='utf-8')
            before = reconcile_data(run)
            with patch('capture.retry_details.urlopen', return_value=Response(
                    b'{"product":{"id":"p2","description":"Second sofa"}}',
                    'application/json', 'https://api.example/products/p2')):
                retry_missing_details(run, before)
            after = reconcile_data(run)
            self.assertEqual(after['missingProductDetails'], [])
            self.assertEqual([item['id'] for item in after['missingProductScreenshots']], ['p1', 'p2'])
            self.assertFalse(after['observedDataVerified'])


if __name__ == '__main__':
    unittest.main()
