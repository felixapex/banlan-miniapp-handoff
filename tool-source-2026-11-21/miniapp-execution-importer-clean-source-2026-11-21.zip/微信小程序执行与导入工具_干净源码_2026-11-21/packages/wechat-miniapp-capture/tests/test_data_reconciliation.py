"""Offline data accounting: each fixture starts with no prior brand captures."""

import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from capture.reconcile_data import reconcile_data
from capture.verify_visible_capture import verify_capture


def save_response(run, name, url, kind, body):
    directory = run / 'responses'
    directory.mkdir(exist_ok=True)
    file = directory / name
    file.write_bytes(body)
    entry = {'url': url, 'kind': kind, 'status': 'saved', 'file': f'responses/{name}',
             'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
    with (run / 'responses.jsonl').open('a', encoding='utf-8') as ledger:
        ledger.write(json.dumps(entry) + '\n')
    return file


class DataReconciliationTests(unittest.TestCase):
    def test_banlan_query_detail_matches_listed_product_id(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json',
                          'https://api.example/xcx/custom/good/findPageByCid?cid=121&start=1&limit=2',
                          'json', b'{"page":{"totalRow":2,"list":[{"id":"p1","price":100},{"id":"p2","price":200}]}}')
            save_response(run, 'p1.json',
                          'https://api.example/xcx/custom/good/detail?gid=p1&sale_id=shop1',
                          'json', b'{"good":{"id":"p1","title":"First sofa"}}')
            audit = reconcile_data(run)
            self.assertEqual([item['id'] for item in audit['missingProductDetails']], ['p2'])
            self.assertEqual(audit['missingDetailText'], [])

    def test_banlan_category_list_is_not_mistaken_for_product_inventory(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'categories.json', 'https://api.example/store/good/getList', 'json',
                          b'{"list":[{"id":37,"name":"Sofas","children":[],"sort":1}]}')
            audit = reconcile_data(run)
            self.assertEqual(audit['missingProductDetails'], [])
            self.assertEqual(audit['ambiguousProductLists'], [])

    def test_unclear_good_list_remains_pending(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'unclear.json', 'https://api.example/good/getList', 'json',
                          b'{"list":[{"id":"p1","name":"unknown"}]}')
            audit = reconcile_data(run)
            self.assertEqual(len(audit['ambiguousProductLists']), 1)
            self.assertFalse(audit['observedDataVerified'])

    def test_comma_separated_original_image_urls_are_counted_individually(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'detail.json', 'https://api.example/detail', 'json',
                          b'{"gallery":"https://img.example/one.jpg,https://img.example/two.jpg"}')
            save_response(run, 'one.jpg', 'https://img.example/one.jpg', 'image', b'original')
            audit = reconcile_data(run)
            self.assertEqual([item['url'] for item in audit['missingImageReferences']],
                             ['https://img.example/two.jpg'])

    def test_finds_missing_page_product_detail_and_original_image(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            listing = {'data': {'total': 3, 'items': [
                {'id': 'p1', 'name': 'Sofa', 'price': 100, 'image': 'https://img.example/a.jpg'},
                {'id': 'p2', 'name': 'Chair', 'price': 80, 'image': 'https://img.example/b.jpg'},
            ]}}
            save_response(run, 'list.json', 'https://api.example/products?page=1&pageSize=2', 'json',
                          json.dumps(listing).encode())
            save_response(run, 'p1.json', 'https://api.example/products/p1', 'json',
                          b'{"product":{"id":"p1","description":"real detail"}}')
            save_response(run, 'a.jpg', 'https://img.example/a.jpg', 'image', b'original-a')
            report = reconcile_data(run)
            self.assertEqual(report['verifiedResponseFiles'], 3)
            self.assertEqual(report['paginationGaps'][0]['missingCount'], 1)
            self.assertEqual([item['id'] for item in report['missingProductDetails']], ['p2'])
            self.assertEqual([item['url'] for item in report['missingImageReferences']], ['https://img.example/b.jpg'])
            self.assertFalse(report['observedDataVerified'])

    def test_reports_complete_only_for_all_observed_refs_and_bytes(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            listing = {'data': {'total': 2, 'items': [
                {'id': 'p1', 'price': 100, 'image': 'https://img.example/a.jpg'},
                {'id': 'p2', 'price': 80, 'image': 'https://img.example/b.jpg'},
            ]}}
            save_response(run, 'list.json', 'https://api.example/products?page=1&pageSize=2', 'json',
                          json.dumps(listing).encode())
            for ident, letter in [('p1', 'a'), ('p2', 'b')]:
                save_response(run, f'{ident}.json', f'https://api.example/products/{ident}', 'json',
                              json.dumps({'product': {'id': ident, 'description': f'{ident} details',
                                                        'image': f'https://img.example/{letter}.jpg'}}).encode())
                save_response(run, f'{letter}.jpg', f'https://img.example/{letter}.jpg', 'image', letter.encode())
            report = reconcile_data(run)
            self.assertEqual(report['paginationGaps'], [])
            self.assertEqual(report['missingProductDetails'], [])
            self.assertEqual(report['missingImageReferences'], [])
            self.assertTrue(report['observedDataVerified'])

    def test_verifier_includes_all_response_files_and_rejects_tampering(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            file = save_response(run, 'first.json', 'https://api.example/content', 'json', b'{"title":"First"}')
            file.write_bytes(b'changed')
            (run / 'capture.json').write_text(json.dumps({
                'kind': 'visible-miniapp-capture', 'screens': [], 'attempts': [], 'scrolls': [], 'errors': [],
            }), encoding='utf-8')
            report = verify_capture(run)
            self.assertEqual(report['dataAudit']['responseFileErrors'][0]['file'], 'responses/first.json')
            self.assertFalse(report['observedScopeVerified'])
            self.assertTrue((run / 'data-audit.json').is_file())

    def test_list_without_total_stays_unverified(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json', 'https://api.example/products?page=1', 'json',
                          b'{"data":{"items":[{"id":"p1","price":10}],"hasMore":true}}')
            save_response(run, 'p1.json', 'https://api.example/products/p1', 'json', b'{"product":{"id":"p1"}}')
            report = reconcile_data(run)
            self.assertEqual(len(report['unknownPagination']), 1)
            self.assertFalse(report['observedDataVerified'])

    def test_two_pages_reconcile_against_one_total(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            for page, ids in [(1, ['p1', 'p2']), (2, ['p3'])]:
                save_response(run, f'list-{page}.json', f'https://api.example/products?page={page}&pageSize=2',
                              'json', json.dumps({'data': {'total': 3, 'items': [{'id': ident} for ident in ids]}}).encode())
            for ident in ['p1', 'p2', 'p3']:
                save_response(run, f'{ident}.json', f'https://api.example/products/{ident}', 'json',
                              json.dumps({'product': {'id': ident, 'description': f'{ident} details'}}).encode())
            report = reconcile_data(run)
            self.assertEqual(report['paginationGaps'], [])
            self.assertEqual(report['missingProductDetails'], [])
            self.assertTrue(report['observedDataVerified'])

    def test_detail_without_descriptive_text_is_not_marked_complete(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json', 'https://api.example/products', 'json',
                          b'{"data":{"total":1,"items":[{"id":"p1"}]}}')
            save_response(run, 'p1.json', 'https://api.example/products/p1', 'json',
                          b'{"product":{"id":"p1","price":100}}')
            report = reconcile_data(run)
            self.assertEqual([item['id'] for item in report['missingDetailText']], ['p1'])
            self.assertFalse(report['observedDataVerified'])

    def test_relative_image_reference_matches_one_verified_image_path(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'detail.json', 'https://api.example/detail', 'json',
                          b'{"image":"folder/a.jpg"}')
            save_response(run, 'a.jpg', 'https://img.example/assets/folder/a.jpg', 'image', b'original-a')
            report = reconcile_data(run)
            self.assertEqual(report['matchedRelativeImages'], 1)
            self.assertEqual(report['relativeImageReferences'], [])
            self.assertTrue(report['observedDataVerified'])

    def test_total_row_and_total_page_reveal_missing_pages(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            page = {'page': {'pageNumber': 1, 'totalPage': 8, 'totalRow': 80, 'pageSize': 10,
                             'lastPage': False, 'list': [{'id': f'n{number}'} for number in range(10)]}}
            save_response(run, 'page.json', 'https://api.example/news?pageNumber=1', 'json',
                          json.dumps(page).encode())
            report = reconcile_data(run)
            self.assertEqual(report['paginationGaps'][0]['missingCount'], 70)
            self.assertEqual(report['unknownPagination'], [])
            self.assertFalse(report['observedDataVerified'])

    def test_start_limit_pages_are_one_list_without_erasing_other_filters(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            for start, ids in [(0, ['p1', 'p2']), (2, ['p3'])]:
                save_response(run, f'list-{start}.json',
                              f'https://api.example/products?category=sofa&start={start}&limit=2&total=3&isEnd=false',
                              'json', json.dumps({'data': {'total': 3, 'items': [{'id': ident} for ident in ids]}}).encode())
            for ident in ['p1', 'p2', 'p3']:
                save_response(run, f'{ident}.json', f'https://api.example/products/{ident}', 'json',
                              json.dumps({'product': {'id': ident, 'description': f'{ident} detail'}}).encode())
            report = reconcile_data(run)
            self.assertEqual(report['paginationGaps'], [])
            self.assertTrue(report['observedDataVerified'])

    def test_detail_response_without_matching_detail_screenshot_stays_incomplete(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'list.json', 'https://api.example/products?page=1', 'json',
                          b'{"data":{"total":1,"items":[{"id":"p1"}]}}')
            save_response(run, 'p1.json', 'https://api.example/products/p1', 'json',
                          b'{"product":{"id":"p1","description":"Sofa details"}}')
            (run / 'capture.json').write_text(json.dumps({'kind': 'visible-miniapp-capture', 'attempts': []}),
                                              encoding='utf-8')
            report = reconcile_data(run)
            self.assertEqual([item['id'] for item in report['missingProductScreenshots']], ['p1'])
            self.assertFalse(report['observedDataVerified'])

            image = b'\x89PNG\r\n\x1a\n' + b'detail'
            (run / 'screenshots').mkdir()
            (run / 'screenshots' / 'detail.png').write_bytes(image)
            capture = {'kind': 'visible-miniapp-capture', 'attempts': [{
                'status': 'changed_page', 'before': {'fingerprint': 'home'},
                'after': {'fingerprint': 'detail', 'screenshot': 'screenshots/detail.png',
                          'screenshotSha256': hashlib.sha256(image).hexdigest()},
                'responses': [{'status': 'verified', 'file': 'responses/p1.json'}],
            }]}
            (run / 'capture.json').write_text(json.dumps(capture), encoding='utf-8')
            report = reconcile_data(run)
            self.assertEqual(report['missingProductScreenshots'], [])
            self.assertTrue(report['observedDataVerified'])


if __name__ == '__main__':
    unittest.main()
