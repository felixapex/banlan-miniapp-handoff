import json
from pathlib import Path
import tempfile
import unittest

from capture.brand_store import create_brand_run


class BrandStoreTests(unittest.TestCase):
    def test_existing_brand_alias_reuses_brand_directory_and_preserves_runs(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp)
            brand = root / 'natuzzi-italia'
            brand.mkdir()
            (brand / 'brand.json').write_text(json.dumps({'displayName': 'Natuzzi Italia', 'aliases': ['NatuzziItalia']}), encoding='utf-8')
            run = create_brand_run(root, 'NatuzziItalia', '#小程序://NatuzziItalia/tjezlUI89cIWHDw', run_id='first')
            self.assertEqual(run, brand / 'runs' / 'first')
            self.assertEqual(json.loads((run / 'input.json').read_text(encoding='utf-8'))['brand'], 'natuzzi-italia')
            with self.assertRaises(FileExistsError):
                create_brand_run(root, 'NatuzziItalia', '#小程序://NatuzziItalia/tjezlUI89cIWHDw', run_id='first')

    def test_new_chinese_brand_has_own_directory(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp)
            run = create_brand_run(root, '家居精选', '#小程序://家居精选/tjezlUI89cIWHDw', run_id='first')
            self.assertEqual(run.parent.parent.name, '家居精选')
            self.assertEqual(json.loads((run.parent.parent / 'brand.json').read_text(encoding='utf-8'))['displayName'], '家居精选')

    def test_rejects_unsafe_brand_name(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            with self.assertRaises(ValueError):
                create_brand_run(Path(temp), '../other', '#小程序://X/tjezlUI89cIWHDw', run_id='first')


if __name__ == '__main__':
    unittest.main()
