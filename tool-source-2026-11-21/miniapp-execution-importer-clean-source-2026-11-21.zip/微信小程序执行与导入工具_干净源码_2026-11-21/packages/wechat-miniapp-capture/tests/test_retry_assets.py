import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from capture.reconcile_data import reconcile_data
from capture.retry_assets import retry_missing_images
from tests.test_data_reconciliation import save_response


class Response:
    def __init__(self, body, content_type='image/jpeg', final_url='https://img.example/a.jpg'):
        self.body = body
        self.position = 0
        self.headers = {'Content-Type': content_type, 'Content-Length': str(len(body))}
        self.final_url = final_url

    def __enter__(self): return self
    def __exit__(self, *args): return False
    def geturl(self): return self.final_url
    def read(self, size):
        block = self.body[self.position:self.position + size]
        self.position += len(block)
        return block


class RetryAssetsTests(unittest.TestCase):
    def test_relative_image_uses_only_unique_host_observed_in_same_json(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'detail.json', 'https://api.example/detail', 'json',
                          b'{"main":"https://img.example/assets/known.jpg","other":"assets/missing.jpg"}')
            save_response(run, 'known.jpg', 'https://img.example/assets/known.jpg', 'image', b'known')
            before = reconcile_data(run)
            self.assertEqual(before['relativeImageReferences'][0]['candidateUrl'],
                             'https://img.example/assets/missing.jpg')
            seen = []
            def open_url(request, timeout):
                seen.append(request.full_url)
                return Response(b'missing-original')
            with patch('capture.retry_assets.urlopen', side_effect=open_url):
                retry = retry_missing_images(run, before)
            self.assertEqual(seen, ['https://img.example/assets/missing.jpg'])
            self.assertEqual(retry['saved'], 1)
            self.assertEqual(reconcile_data(run)['relativeImageReferences'], [])

    def test_unresolved_relative_filename_is_recorded_without_fetch(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'detail.json', 'https://api.example/detail', 'json',
                          b'{"other":"missing.jpg"}')
            before = reconcile_data(run)
            with patch('capture.retry_assets.urlopen') as open_url:
                retry = retry_missing_images(run, before)
            open_url.assert_not_called()
            self.assertEqual(retry['skipped'], 1)

    def test_recovers_missing_original_image_and_reconciles_again(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'detail.json', 'https://api.example/detail', 'json',
                          b'{"image":"https://img.example/a.jpg"}')
            before = reconcile_data(run)
            self.assertEqual(len(before['missingImageReferences']), 1)
            with patch('capture.retry_assets.urlopen', return_value=Response(b'original-image')) as open_url:
                retry = retry_missing_images(run, before)
            self.assertEqual(open_url.call_count, 1)
            self.assertEqual(retry['saved'], 1)
            after = reconcile_data(run)
            self.assertEqual(after['missingImageReferences'], [])
            self.assertTrue(after['observedDataVerified'])
            entry = json.loads((run / 'responses.jsonl').read_text(encoding='utf-8').splitlines()[-1])
            self.assertEqual(entry['sha256'], hashlib.sha256(b'original-image').hexdigest())
            self.assertEqual((run / entry['file']).read_bytes(), b'original-image')

    def test_non_image_response_remains_missing_with_failure_record(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            run = Path(temp)
            save_response(run, 'detail.json', 'https://api.example/detail', 'json',
                          b'{"image":"https://img.example/a.jpg"}')
            before = reconcile_data(run)
            with patch('capture.retry_assets.urlopen', return_value=Response(b'<html>login</html>', 'text/html')):
                retry = retry_missing_images(run, before)
            self.assertEqual(retry['saved'], 0)
            self.assertEqual(retry['failed'], 1)
            self.assertEqual(len(reconcile_data(run)['missingImageReferences']), 1)
            self.assertEqual(len((run / 'responses.jsonl').read_text(encoding='utf-8').splitlines()), 1)
            self.assertTrue((run / 'asset-retry.json').is_file())


if __name__ == '__main__':
    unittest.main()
