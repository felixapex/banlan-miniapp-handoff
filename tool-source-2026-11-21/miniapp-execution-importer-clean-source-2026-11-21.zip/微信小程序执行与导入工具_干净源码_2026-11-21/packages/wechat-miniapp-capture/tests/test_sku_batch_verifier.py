import json
from pathlib import Path
import tempfile
import unittest

from capture.sku_batch import prepare_products, run_batch, verify_batch


def _detail(product_id, title, combinations=2):
    choices = [
        {"id": f"choice-{index}", "name": f"Choice {index}", "file_url": f"choice-{index}.jpg"}
        for index in range(combinations)
    ]
    return {
        "code": "0",
        "good": {
            "id": product_id,
            "title": title,
            "price": 100,
            "parameter_json": json.dumps([{"name": "Material", "content": "Wood"}]),
            "problem_json": json.dumps([{"name": "Question", "content": "Answer"}]),
            "renovation_json": json.dumps([{
                "name": "Details", "config": {"content": "<p>Product description</p>"},
            }]),
            "specs": [{
                "id": "root",
                "children": [{"id": "group", "name": "Model", "children": choices}],
            }],
        },
    }


def _entry(product_id, title, detail_name, image_names):
    return {
        "id": product_id,
        "title": title,
        "fullDetailJson": detail_name,
        "screenshot": f"{product_id}.bmp",
        "images": [
            {"urlOrPath": name, "localFile": name} for name in image_names
        ],
    }


class SkuBatchVerifierTests(unittest.TestCase):
    def test_prepare_products_rejects_combo_explosion_and_rotates_categories(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp).resolve()
            entries = []
            categories = []
            for index, combos in enumerate((2, 2, 2, 200)):
                product_id = f"p{index}"
                detail_name = f"{product_id}.json"
                image_names = [f"choice-{choice}.jpg" for choice in range(combos)]
                (root / detail_name).write_text(
                    json.dumps(_detail(product_id, f"Product {index}", combos)), encoding="utf-8")
                (root / f"{product_id}.bmp").write_bytes(b"bitmap")
                for name in image_names:
                    (root / name).write_bytes(name.encode("utf-8"))
                entries.append(_entry(product_id, f"Product {index}", detail_name, image_names))
                category_file = f"category-{index % 2}.json"
                categories.append({
                    "id": index % 2,
                    "parent": "Furniture",
                    "name": f"Category {index % 2}",
                    "file": category_file,
                })
            for category_index in range(2):
                ids = [f"p{index}" for index in range(4) if index % 2 == category_index]
                (root / f"category-{category_index}.json").write_text(json.dumps({
                    "page": {"list": [{"id": product_id} for product_id in ids]},
                }), encoding="utf-8")

            selected = prepare_products(
                {"productEntries": entries}, {"categories": categories}, root,
                count=3, max_combinations=10,
            )

            self.assertEqual(len(selected), 3)
            self.assertNotIn("p3", {item["id"] for item in selected})
            self.assertEqual(
                {item["primaryCategory"]["name"] for item in selected},
                {"Category 0", "Category 1"},
            )
            self.assertTrue(all(item["combinationCount"] == 2 for item in selected))

    def test_materialized_batch_verifies_every_file_and_rejects_tampering(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as temp:
            root = Path(temp).resolve()
            detail = _detail("p1", "Chair", 2)
            (root / "p1.json").write_text(json.dumps(detail), encoding="utf-8")
            (root / "p1.bmp").write_bytes(b"bitmap")
            for name in ("choice-0.jpg", "choice-1.jpg"):
                (root / name).write_bytes(("image-" + name).encode("utf-8"))
            entry = _entry("p1", "Chair", "p1.json", ["choice-0.jpg", "choice-1.jpg"])
            entry["primaryCategory"] = {"id": 1, "parent": "Furniture", "name": "Chair"}
            output = root / "delivery"

            def resolver(gid, ids):
                return {
                    "code": "0",
                    "priceObj": {
                        "gid": gid,
                        "ids": json.dumps(ids),
                        "price": 100,
                        "price_id": ids[0],
                    },
                    "message": "ok",
                }

            report = run_batch(
                [entry], root, output, {"productEntries": [entry]}, resolver=resolver,
            )
            verified = verify_batch(output, expected_count=1)

            self.assertTrue(report["complete"])
            self.assertTrue(verified["complete"])
            product = report["products"][0]
            manifest_path = Path(product["materialsManifestFile"])
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertTrue(Path(manifest["detail"]["file"]).is_file())
            self.assertTrue(Path(manifest["screenshot"]["file"]).is_file())
            self.assertTrue(Path(manifest["productTextJson"]).is_file())
            self.assertEqual(len(manifest["images"]), 2)

            text_path = Path(manifest["productTextJson"])
            original_text = text_path.read_bytes()
            text_path.write_bytes(b"tampered text")
            tampered_text = verify_batch(output, expected_count=1)
            text_path.write_bytes(original_text)

            self.assertFalse(tampered_text["complete"])
            self.assertTrue(any("sha256" in error for error in tampered_text["errors"]))

            original_manifest = manifest_path.read_text(encoding="utf-8")
            manifest["images"] = manifest["images"][:1]
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            omitted_image = verify_batch(output, expected_count=1)
            manifest_path.write_text(original_manifest, encoding="utf-8")

            self.assertFalse(omitted_image["complete"])
            self.assertTrue(any("declared 2 images" in error for error in omitted_image["errors"]))

            Path(manifest["images"][0]["file"]).write_bytes(b"tampered")
            tampered = verify_batch(output, expected_count=1)
            wrong_count = verify_batch(output, expected_count=2)

            self.assertFalse(tampered["complete"])
            self.assertTrue(any("sha256" in error for error in tampered["errors"]))
            self.assertFalse(wrong_count["complete"])
            self.assertTrue(any("expected 2" in error for error in wrong_count["errors"]))


if __name__ == "__main__":
    unittest.main()
