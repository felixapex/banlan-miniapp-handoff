"""Foreground automation must never take the user's mouse by default."""

import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from capture.windows_ui import _activate


class ForegroundInputTests(unittest.TestCase):
    def test_window_activation_fails_before_touching_windows_without_opt_in(self):
        with patch.dict(os.environ, {"WECHAT_ALLOW_FOREGROUND_INPUT": "0"}), \
             patch('capture.windows_ui.ACCOUNT_PAUSE', Path('E:/not-present-account-pause')):
            with self.assertRaisesRegex(RuntimeError, "foreground input is disabled"):
                _activate(0)

    def test_account_pause_blocks_foreground_even_with_old_opt_in(self):
        with tempfile.TemporaryDirectory() as folder:
            marker = Path(folder) / 'ACCOUNT-AUTOMATION-PAUSED.txt'
            marker.write_text('paused', encoding='utf-8')
            with patch.dict(os.environ, {"WECHAT_ALLOW_FOREGROUND_INPUT": "1"}), \
                 patch('capture.windows_ui.ACCOUNT_PAUSE', marker), patch('capture.windows_ui.win32gui') as gui:
                with self.assertRaisesRegex(RuntimeError, 'paused'):
                    _activate(0)
                gui.assert_not_called()


if __name__ == "__main__":
    unittest.main()
