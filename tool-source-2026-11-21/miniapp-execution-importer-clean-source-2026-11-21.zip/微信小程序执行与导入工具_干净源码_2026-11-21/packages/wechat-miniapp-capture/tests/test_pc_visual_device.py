import struct
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zlib

from capture.pc_visual_device import PcVisualDevice, bmp32_to_png
from tests.test_share_code_locator import bmp


class PcVisualDeviceTests(unittest.TestCase):
    def test_printwindow_bgra_bitmap_becomes_png_with_same_pixels(self):
        bitmap = bmp(2, 2, [(0, 0, (10, 20, 30)), (1, 0, (40, 50, 60)),
                            (0, 1, (70, 80, 90)), (1, 1, (100, 110, 120))])
        encoded = bmp32_to_png(bitmap)
        self.assertTrue(encoded.startswith(b'\x89PNG\r\n\x1a\n'))
        self.assertEqual(struct.unpack('>II', encoded[16:24]), (2, 2))
        offset = 8
        compressed = bytearray()
        while offset < len(encoded):
            size = struct.unpack('>I', encoded[offset:offset+4])[0]
            kind = encoded[offset+4:offset+8]
            if kind == b'IDAT': compressed.extend(encoded[offset+8:offset+8+size])
            offset += 12 + size
        pixels = zlib.decompress(compressed)
        self.assertEqual(pixels[:9], b'\x00' + bytes((30, 20, 10, 255, 60, 50, 40, 255)))

    def test_printwindow_undefined_alpha_does_not_hide_screenshot(self):
        bitmap = bytearray(bmp(1, 1, [(0, 0, (10, 20, 30))]))
        offset = struct.unpack_from('<I', bitmap, 10)[0]
        bitmap[offset + 3] = 0
        encoded = bmp32_to_png(bytes(bitmap))
        size = struct.unpack('>I', encoded[33:37])[0]
        pixels = zlib.decompress(encoded[41:41 + size])
        self.assertEqual(pixels, b'\x00' + bytes((30, 20, 10, 255)))

    def test_account_pause_blocks_pc_capture_before_window_or_mouse_access(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            marker = Path(folder) / 'pause.txt'
            marker.write_text('paused', encoding='utf-8')
            with patch('capture.pc_visual_device.ACCOUNT_PAUSE', marker), \
                 patch('capture.pc_visual_device.win32gui') as gui:
                with self.assertRaisesRegex(RuntimeError, 'paused'):
                    PcVisualDevice(123, folder).screenshot()
                gui.assert_not_called()


if __name__ == '__main__':
    unittest.main()
