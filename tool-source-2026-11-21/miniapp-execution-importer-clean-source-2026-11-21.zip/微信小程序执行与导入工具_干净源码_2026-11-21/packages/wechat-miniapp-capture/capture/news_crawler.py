"""Discover and open each card in Banlan's one-column news feed."""

import argparse
import hashlib
import json
from pathlib import Path
import time

import win32api
import win32con
import win32gui

from .config import require_e_output
from .full_page import capture_page, changed_ratio, content_pixels
from .grid_crawler import bmp_rows, text_row_shift
from .windows_ui import _activate, _capture, _click, _windows


def image_bands(rows):
    spans = []
    start = None
    for y in range(105, 715):
        row = rows[y]
        colored = sum(min(row[x * 4:x * 4 + 3]) < 230 for x in range(19, 411))
        active = colored > 392 * 0.2
        if active and start is None:
            start = y
        if start is not None and (not active or y == 714):
            end = y if not active else y + 1
            if 205 <= end - start <= 215 and end + 70 < 715:
                spans.append((start, end))
            start = None
    return spans


def card_hash(rows, start):
    digest = hashlib.sha256()
    for y in range(start, start + 270):
        digest.update(rows[y][19 * 4:411 * 4])
    return digest.hexdigest()


def discover(list_dir, run):
    files = sorted(list_dir.glob("screen-*.bmp"))
    if not files:
        raise ValueError("no fine-step news list screenshots")
    cards = []
    seen = set()
    for index, file in enumerate(files):
        rows = bmp_rows(file)
        for start, end in image_bands(rows):
            digest = card_hash(rows, start)
            if digest in seen:
                continue
            seen.add(digest)
            cards.append({"hash": digest, "listScreen": index,
                          "imageTop": start, "x": 215, "y": start + 100})
    (run / "news-cards.json").write_text(json.dumps({"listScreens": len(files), "cards": cards}, indent=2), encoding="utf-8")
    return cards


def find_card_image(rows, card, reference):
    top_row = bytes(reference[card["imageTop"]][19 * 4:411 * 4])
    matches = []
    for top in range(105, 445):
        if bytes(rows[top][19 * 4:411 * 4]) == top_row and card_hash(rows, top) == card["hash"]:
            matches.append(top + 100)
    if len(matches) > 1:
        raise RuntimeError("same news card appears twice in one viewport")
    if matches:
        return matches[0]
    return None


def find_card(rows, card, reference):
    y = find_card_image(rows, card, reference)
    if y is not None:
        return y, "image and title"
    shift = text_row_shift(rows, reference)
    if shift is not None and 110 <= card["y"] + shift <= 610:
        return card["y"] + shift, "list text alignment"
    return None, None


def visible_orders(rows, cards, references):
    found = set()
    for order, card in enumerate(cards):
        ref = references[card["listScreen"]]
        if find_card_image(rows, card, ref) is not None:
            found.add(order)
    return found


def scroll(hwnd, distance):
    _activate(hwnd)
    left, top, _, _ = win32gui.GetWindowRect(hwnd)
    win32api.SetCursorPos((left + 215, top + 400))
    win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, distance, 0)
    time.sleep(0.8)


def crawl(title, run, cards, list_dir, limit):
    windows = _windows(title, "WeChatAppEx.exe")
    if len(windows) != 1:
        raise RuntimeError("expected one miniapp window")
    hwnd = windows[0]
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    if (right - left, bottom - top) != (430, 788):
        raise RuntimeError("miniapp window changed size")
    _click(hwnd, 295, 75)
    time.sleep(0.8)
    before = run / ".news-before.bmp"
    after = run / ".news-after.bmp"
    for _ in range(100):
        _capture(hwnd, before)
        scroll(hwnd, 10000)
        _capture(hwnd, after)
        if changed_ratio(content_pixels(before, 430, 788, 105, 715),
                         content_pixels(after, 430, 788, 105, 715)) < 0.01:
            break
    else:
        raise RuntimeError("news list could not rewind to top")
    before.unlink(missing_ok=True)
    after.unlink(missing_ok=True)
    # Some intermediate viewports contain only partial covers. Keep them as
    # text anchors even though discover() did not create a clickable card.
    references = {index: bmp_rows(file)
                  for index, file in enumerate(sorted(list_dir.glob("screen-*.bmp")))}
    ledger = run / "news-results.jsonl"
    done = {}
    if ledger.is_file():
        for line in ledger.read_text(encoding="utf-8").splitlines():
            entry = json.loads(line)
            if entry.get("status") == "saved" and entry.get("endOfPage"):
                done[entry["hash"]] = entry
    completed = 0
    for order, card in enumerate(cards):
        if card["hash"] in done:
            continue
        if completed >= limit:
            break
        current = run / ".news-list-current.bmp"
        y = None
        located_by = None
        for _ in range(150):
            _capture(hwnd, current)
            rows = bmp_rows(current)
            y, located_by = find_card(rows, card, references[card["listScreen"]])
            if y is not None:
                break
            visible = visible_orders(rows, cards, references)
            if not visible:
                aligned = [screen for screen, reference in references.items()
                           if text_row_shift(rows, reference) is not None]
                if not aligned:
                    raise RuntimeError(f"no known news content while seeking card {order}")
                nearest = min(aligned, key=lambda screen: abs(screen - card["listScreen"]))
                distance = 120 if card["listScreen"] < nearest else -120
            elif order < min(visible):
                distance = 120 if min(visible) - order <= 4 else 420
            elif order > max(visible):
                distance = -120 if order - max(visible) <= 4 else -420
            else:
                raise RuntimeError(f"news card {order} is between visible cards but not matched")
            scroll(hwnd, distance)
        if y is None:
            raise RuntimeError(f"news card {order} could not be located")
        _click(hwnd, card["x"], y)
        time.sleep(1.0)
        entered = run / ".news-entered.bmp"
        _capture(hwnd, entered)
        ratio = changed_ratio(content_pixels(current, 430, 788, 105, 715),
                              content_pixels(entered, 430, 788, 105, 715))
        if ratio < 0.1:
            raise RuntimeError(f"news card {order} did not open")
        slug = f"news-card-{order:03d}-{card['hash'][:10]}"
        steps = capture_page(title, run, slug, 200, -520, 430, 788, 55, 775, rewind_to_top=True)
        record = {"hash": card["hash"], "slug": slug, "status": "saved" if steps[-1].get("endOfPage") else "partial",
                  "screens": len(steps), "endOfPage": bool(steps[-1].get("endOfPage")), "locatedBy": located_by}
        with ledger.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record) + "\n")
        if not record["endOfPage"]:
            raise RuntimeError(f"news card {order} detail did not reach bottom")
        _click(hwnd, 38, 40)
        time.sleep(0.8)
        returned = run / ".news-returned.bmp"
        _capture(hwnd, returned)
        if find_card(bmp_rows(returned), card, references[card["listScreen"]])[0] is None:
            raise RuntimeError(f"news list position changed after card {order}")
        current.unlink(missing_ok=True)
        entered.unlink(missing_ok=True)
        returned.unlink(missing_ok=True)
        completed += 1
        print(json.dumps({"article": order + 1, "screens": len(steps), "locatedBy": located_by}), flush=True)
    return {"discovered": len(cards), "alreadyDone": len(done), "completedNow": completed}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--list-slug", default="brand-news-list-fine")
    parser.add_argument("--limit", type=int, default=200)
    parser.add_argument("--discover-only", action="store_true")
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected an existing E-drive brand run")
    if not 1 <= args.limit <= 200:
        parser.error("limit must be 1..200")
    list_dir = run / "screenshots" / "long-pages" / args.list_slug
    cards = discover(list_dir, run)
    if args.discover_only:
        print(json.dumps({"cards": len(cards)}))
        return
    print(json.dumps(crawl(args.title, run, cards, list_dir, args.limit)))


if __name__ == "__main__":
    main()
