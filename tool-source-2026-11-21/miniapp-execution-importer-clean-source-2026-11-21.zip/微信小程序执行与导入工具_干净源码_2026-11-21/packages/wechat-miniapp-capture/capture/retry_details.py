"""Retry missing product JSON only from a verified GET detail shape in this run."""

import hashlib
import json
from pathlib import Path
import re
from urllib.parse import parse_qsl, quote, urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen

from .config import require_e_output
from .reconcile_data import DETAIL_PATH, DETAIL_ID_KEYS, DETAIL_QUERY_ENDINGS, detail_id_from_url, _item_id, _walk
from .response_observer import ResponseObserver
from .retry_assets import NUMBERED


PRODUCT_ID = re.compile(r"[A-Za-z0-9_-]{1,128}$")


def _observed_template(url, ident):
    parsed = urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname:
        return None
    ending = parsed.path.rstrip("/").rsplit("/", 1)[-1].casefold()
    if ending in DETAIL_QUERY_ENDINGS:
        pairs = parse_qsl(parsed.query, keep_blank_values=True)
        matches = [index for index, (key, value) in enumerate(pairs)
                   if key.casefold() in DETAIL_ID_KEYS and value == ident]
        if len(matches) != 1:
            return None
        pairs[matches[0]] = (pairs[matches[0]][0], None)
        return ("query", parsed.scheme, parsed.netloc, parsed.path, tuple(pairs))
    match = DETAIL_PATH.search(parsed.path)
    if match and match.group(1) == ident:
        return ("path", parsed.scheme, parsed.netloc, parsed.path[:match.start(1)], parsed.query)
    return None


def _url_for_id(template, ident):
    mode, scheme, host, path, query = template
    if mode == "path":
        path += quote(ident, safe="")
    else:
        query = urlencode([(key, ident if value is None else value) for key, value in query])
    return urlunsplit((scheme, host, path, query, ""))


def _contains_detail_id(data, wanted):
    try:
        return any(_item_id(value) == wanted and path and path[-1].casefold() in
                   {"product", "good", "goodsdetail", "productdetail"}
                   for path, value in _walk(data) if isinstance(value, dict))
    except ValueError:
        return False


def retry_missing_details(run, audit, *, max_requests=500, max_body_bytes=20 * 1024 * 1024):
    run = Path(run).resolve()
    require_e_output(str(run))
    if audit.get("kind") != "miniapp-data-reconciliation" or audit.get("status") != "reconciled":
        raise ValueError("a verified data audit from this run is required")
    if not (1 <= max_requests <= 1000 and 1 <= max_body_bytes <= 20 * 1024 * 1024):
        raise ValueError("invalid detail retry limits")
    ledger = run / "responses.jsonl"
    entries = [json.loads(line) for line in ledger.read_text(encoding="utf-8").splitlines()]
    by_file = {entry.get("file"): entry for entry in entries if isinstance(entry, dict)}
    observer = ResponseObserver(run)
    templates = set()
    for entry in entries:
        if (not isinstance(entry, dict) or entry.get("kind") != "json" or
                entry.get("requestMethod") != "GET" or observer._verify(entry).get("status") != "verified"):
            continue
        url = entry.get("url", "")
        observed_id = detail_id_from_url(url)
        if not observed_id:
            continue
        try:
            data = json.loads((run / entry["file"]).read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, ValueError):
            continue
        if _contains_detail_id(data, observed_id):
            template = _observed_template(url, observed_id)
            if template is not None:
                templates.add(template)

    responses = run / "responses"
    highest = max((int(match.group(1)) for file in responses.iterdir()
                   if (match := NUMBERED.fullmatch(file.name))), default=0)
    result = {"kind": "get-detail-retry", "attempts": [], "saved": 0, "failed": 0,
              "skipped": 0, "completeMiniapp": False}
    attempted = set()
    for missing in audit.get("missingProductDetails", []):
        product_id = missing.get("id")
        if product_id in attempted:
            continue
        attempted.add(product_id)
        attempt = {"id": product_id, "sourceLists": missing.get("sourceLists", [])}
        if not isinstance(product_id, str) or not PRODUCT_ID.fullmatch(product_id):
            attempt.update(status="skipped-unsafe-id")
            result["skipped"] += 1
            result["attempts"].append(attempt)
            continue
        source_hosts = {urlsplit(by_file[name].get("url", "")).hostname
                        for name in missing.get("sourceLists", []) if name in by_file}
        candidates = [template for template in templates if urlsplit(
            urlunsplit((template[1], template[2], template[3], "", ""))).hostname in source_hosts]
        if len(candidates) != 1:
            attempt.update(status="skipped-no-unique-observed-get-template")
            result["skipped"] += 1
            result["attempts"].append(attempt)
            continue
        url = _url_for_id(candidates[0], product_id)
        attempt["url"] = url
        if len(attempted) > max_requests or highest >= 99999:
            attempt.update(status="skipped-limit")
            result["skipped"] += 1
            result["attempts"].append(attempt)
            continue
        try:
            request = Request(url, headers={"Accept": "application/json"}, method="GET")
            with urlopen(request, timeout=15) as response:
                final_url = response.geturl()
                if urlsplit(final_url).scheme != "https":
                    raise ValueError("detail redirected outside HTTPS")
                mime = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                if mime != "application/json" and not mime.endswith("+json"):
                    raise ValueError("detail returned non-JSON content")
                body = response.read(max_body_bytes + 1)
            if not body or len(body) > max_body_bytes:
                raise ValueError("detail body is empty or too large")
            data = json.loads(body)
            if not _contains_detail_id(data, product_id):
                raise ValueError("detail JSON does not identify the requested product")
            digest = hashlib.sha256(body).hexdigest()
            highest += 1
            name = f"{highest:05d}-{digest[:16]}.json"
            relative = f"responses/{name}"
            with (responses / name).open("xb") as target:
                target.write(body)
            with ledger.open("a", encoding="utf-8") as target:
                target.write(json.dumps({"url": final_url, "kind": "json", "status": "saved",
                    "file": relative, "bytes": len(body), "sha256": digest,
                    "requestMethod": "GET", "source": "get-detail-retry"}, ensure_ascii=False) + "\n")
            attempt.update(status="saved", file=relative, bytes=len(body), sha256=digest)
            result["saved"] += 1
        except (OSError, ValueError) as error:
            attempt.update(status="failed", error=str(error))
            result["failed"] += 1
        result["attempts"].append(attempt)
    temporary = run / "detail-retry.json.tmp"
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(run / "detail-retry.json")
    return result
