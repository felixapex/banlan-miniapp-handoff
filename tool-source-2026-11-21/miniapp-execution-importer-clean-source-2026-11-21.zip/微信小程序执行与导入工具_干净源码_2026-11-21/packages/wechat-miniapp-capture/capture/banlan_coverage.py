"""Audit Banlan page coverage against the pages visible in the live miniapp."""

import argparse
import json
from pathlib import Path

from .config import require_e_output


def ended(run, slug):
    path = run / "screenshots" / "long-pages" / slug / "manifest.json"
    if not path.is_file():
        return False
    steps = json.loads(path.read_text(encoding="utf-8")).get("steps", [])
    return bool(steps and steps[-1].get("endOfPage"))


def full_product_pages(base, deep):
    catalog = json.loads((base / "catalog" / "full-product-catalog.json").read_text(encoding="utf-8"))
    product_ids = {str(item["id"]) for item in catalog["productEntries"]}
    completed = set()
    if catalog["productEntries"] and ended(deep, "jiandu-sofa-detail"):
        completed.add(str(catalog["productEntries"][0]["id"]))
    ledger = deep / "product-long-results.jsonl"
    if ledger.is_file():
        latest = {}
        for line in ledger.read_text(encoding="utf-8").splitlines():
            entry = json.loads(line)
            latest[str(entry.get("id"))] = entry
        for entry in latest.values():
            if entry.get("status") != "saved" or str(entry.get("id")) not in product_ids:
                continue
            manifest = deep / entry["manifest"]
            if manifest.is_file():
                steps = json.loads(manifest.read_text(encoding="utf-8")).get("steps", [])
                if steps and steps[-1].get("endOfPage"):
                    completed.add(str(entry["id"]))
    return len(completed)


def audit(base, deep):
    old = json.loads((base / "verification.json").read_text(encoding="utf-8"))
    discovered = json.loads((deep / "grid-cards.json").read_text(encoding="utf-8"))["cards"]
    results = [json.loads(line) for line in (deep / "grid-results.jsonl").read_text(encoding="utf-8").splitlines()] if (deep / "grid-results.jsonl").is_file() else []
    saved = {entry["hash"] for entry in results if entry.get("status") == "saved" and entry.get("endOfPage")}
    diary_done = sum(card["hash"] in saved for card in discovered)
    gallery_path = deep / "gallery" / "all-posts.json"
    gallery = json.loads(gallery_path.read_text(encoding="utf-8")) if gallery_path.is_file() else {}
    assets_path = deep / "gallery" / "asset-summary.json"
    assets = json.loads(assets_path.read_text(encoding="utf-8")) if assets_path.is_file() else {}
    designers_path = deep / "designers" / "manifest.json"
    designers = json.loads(designers_path.read_text(encoding="utf-8")) if designers_path.is_file() else []
    about_links_path = deep / "about-links" / "manifest.json"
    about_links = json.loads(about_links_path.read_text(encoding="utf-8")) if about_links_path.is_file() else []
    news_cards_path = deep / "news-cards.json"
    news_cards = json.loads(news_cards_path.read_text(encoding="utf-8"))["cards"] if news_cards_path.is_file() else []
    news_results_path = deep / "news-results.jsonl"
    news_results = [json.loads(line) for line in news_results_path.read_text(encoding="utf-8").splitlines()] if news_results_path.is_file() else []
    news_saved = {entry["hash"] for entry in news_results if entry.get("status") == "saved" and entry.get("endOfPage")}
    public_news_path = deep / "news" / "all-articles.json"
    public_news = json.loads(public_news_path.read_text(encoding="utf-8")) if public_news_path.is_file() else {}
    news_covers_path = deep / "news" / "verification.json"
    news_covers = json.loads(news_covers_path.read_text(encoding="utf-8")) if news_covers_path.is_file() else {}
    news_matches_path = deep / "news" / "cover-matches.json"
    news_matches = json.loads(news_matches_path.read_text(encoding="utf-8")) if news_matches_path.is_file() else {}
    stores_path = deep / "stores" / "public-stores.json"
    stores = json.loads(stores_path.read_text(encoding="utf-8")) if stores_path.is_file() else {}
    sections = {
        "productCatalog": {"listed": old["products"], "detailJson": old["products"],
                           "firstScreen": old["screenshots"], "fullScroll": full_product_pages(base, deep)},
        "productDetailTabs": {"CP": (deep / "jiandu-sofa-cp-entry.bmp").is_file(),
                              "reviews": (deep / "jiandu-sofa-reviews-entry.bmp").is_file()},
        "brand": {
            "galleryFirstScreen": (deep / "brand-main.bmp").is_file(),
            "galleryFullScroll": ended(deep, "brand-gallery-list"),
            "galleryPostsFromApi": gallery.get("uniquePosts", 0),
            "galleryReportedTotal": gallery.get("reportedTotal"),
            "galleryOriginalImageUrls": assets.get("uniqueImageUrls", 0),
            "galleryImagesSavedOrReused": assets.get("saved", 0) + assets.get("reused", 0),
            "galleryImageErrors": len(assets.get("errors", [])),
            "galleryUnresolvedReferences": len(assets.get("unresolvedReferences", [])),
            "galleryRelativeReferencesResolved": len(assets.get("inferredRelativeReferences", [])),
            "designersFirstScreen": (deep / "brand-designers-entry.bmp").is_file(),
            "designersListFullScroll": ended(deep, "brand-designers-list"),
            "designerHanYiFullScroll": ended(deep, "designer-hanyi-detail"),
            "designerSlides": len(designers),
            "designerDetailsFullScroll": sum(bool(item.get("endOfPage")) for item in designers),
            "diaryListFullScroll": ended(deep, "brand-new-home-diary-list"),
            "diaryCardsDetected": len(discovered), "diaryArticlesFullScroll": diary_done,
            "diaryReportedTotal": None,
            "newsFirstScreen": (deep / "brand-news-entry.bmp").is_file(),
            "newsFullScroll": ended(deep, "brand-news-list"),
            "newsFineListFullScroll": ended(deep, "brand-news-list-fine"),
            "newsCardsDetected": len(news_cards),
            "newsArticlesFullScroll": sum(card["hash"] in news_saved for card in news_cards),
            "newsDistinctArticlesFullScroll": news_matches.get("uniqueMatched", 0) if news_matches.get("ambiguous") == 0 else 0,
            "newsDuplicateDetailVisits": len(news_matches.get("matches", [])) - news_matches.get("uniqueMatched", 0),
            "newsMissingArticleIds": len(news_matches.get("missing", [])),
            "newsArticlesFromApi": public_news.get("uniqueArticles", 0),
            "newsReportedTotal": public_news.get("reportedTotal"),
            "newsCoverFilesVerified": news_covers.get("coverFilesVerified", 0),
            "aboutFirstScreen": (deep / "brand-about-entry.bmp").is_file(),
            "aboutFullScroll": ended(deep, "brand-about"),
            "aboutLinksOpened": len(about_links),
            "aboutDistinctDetailPages": len({item.get("pageIdentity") for item in about_links}),
            "aboutLinkDetailsFullScroll": sum(bool(item.get("endOfPage")) for item in about_links),
        },
        "stores": {"firstScreen": (base / "stores-tab.bmp").is_file(),
                   "fullScroll": ended(deep, "stores-page"),
                   "publicRecords": stores.get("storeCount", 0),
                   "originalImageUrls": stores.get("imageUrls", 0),
                   "imagesSavedOrReused": stores.get("imagesSavedOrReused", 0),
                   "imageErrors": len(stores.get("imageErrors", []))},
        "mine": {"firstScreen": (deep / "mine-entry.bmp").is_file(),
                 "fullScroll": ended(deep, "mine-page")},
    }
    complete = (sections["productCatalog"]["fullScroll"] == old["products"] and
                sections["brand"]["galleryFullScroll"] and
                sections["brand"]["galleryImagesSavedOrReused"] == sections["brand"]["galleryOriginalImageUrls"] and
                sections["brand"]["galleryUnresolvedReferences"] == 0 and
                sections["brand"]["designersListFullScroll"] and
                sections["brand"]["designerDetailsFullScroll"] == 5 and
                sections["brand"]["diaryReportedTotal"] is not None and
                sections["brand"]["diaryArticlesFullScroll"] == sections["brand"]["diaryReportedTotal"] and
                sections["brand"]["newsFullScroll"] and
                sections["brand"]["newsDistinctArticlesFullScroll"] == sections["brand"]["newsArticlesFromApi"] == sections["brand"]["newsReportedTotal"] and
                sections["brand"]["aboutFullScroll"] and
                sections["brand"]["aboutLinkDetailsFullScroll"] == 7 and
                sections["stores"]["fullScroll"] and sections["mine"]["fullScroll"])
    result = {"brand": "班兰", "complete": complete, "sections": sections}
    (deep / "coverage.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-run", required=True)
    parser.add_argument("--deep-run", required=True)
    args = parser.parse_args()
    base = Path(args.base_run).resolve()
    deep = Path(args.deep_run).resolve()
    require_e_output(str(base))
    require_e_output(str(deep))
    if base.parent != deep.parent or base.parent.name != "runs":
        parser.error("base and deep runs must belong to the same E-drive brand")
    result = audit(base, deep)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
