"""Page through the public Banlan gallery endpoint observed in the miniapp."""

import argparse
import csv
import json
from pathlib import Path

from .banlan_public_catalog import changed_url, get_json, saved_entries
from .config import require_e_output


def gallery_url(base):
    for entry in saved_entries(base):
        if "/xcx/custom/lanfenPage/lyzPage?" in entry.get("url", "") and entry.get("status") == "saved":
            return entry["url"]
    raise ValueError("gallery request was not observed in the source run")


def collect(base, deep):
    template = gallery_url(base)
    pages = deep / "gallery" / "pages"
    pages.mkdir(parents=True, exist_ok=True)
    posts = {}
    first_total = None
    for number in range(1, 101):
        url = changed_url(template, {"start": str(number), "limit": "10"})
        data = get_json(url, pages / f"{number:03d}.json")
        page = data.get("page", {})
        items = page.get("list")
        if str(data.get("code")) != "0" or not isinstance(items, list) or page.get("pageNumber") != number:
            raise ValueError(f"gallery page {number} returned unexpected data")
        if first_total is None:
            first_total = page.get("totalRow")
        for item in items:
            post_id = str(item.get("id", ""))
            if not post_id:
                raise ValueError(f"gallery page {number} contains a post without id")
            posts[post_id] = item
        print(json.dumps({"page": number, "items": len(items), "uniquePosts": len(posts)}), flush=True)
        if page.get("lastPage"):
            break
    else:
        raise RuntimeError("gallery did not end within 100 pages")
    result = {"sourceUrl": template, "reportedTotal": first_total,
              "pages": number, "uniquePosts": len(posts), "posts": list(posts.values())}
    (deep / "gallery" / "all-posts.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with (deep / "gallery" / "gallery-posts.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        columns = ["id", "gtitle", "content", "nickName", "cname", "create_time", "gid", "img_urls"]
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows({key: item.get(key) for key in columns} for item in posts.values())
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-run", required=True)
    parser.add_argument("--deep-run", required=True)
    args = parser.parse_args()
    base = Path(args.base_run).resolve()
    deep = Path(args.deep_run).resolve()
    require_e_output(str(base))
    require_e_output(str(deep))
    if base.parent != deep.parent or base.parent.name != "runs" or not (deep / "input.json").is_file():
        parser.error("expected Banlan brand runs on E")
    result = collect(base, deep)
    print(json.dumps({"pages": result["pages"], "uniquePosts": result["uniquePosts"],
                      "reportedTotal": result["reportedTotal"]}))


if __name__ == "__main__":
    main()
