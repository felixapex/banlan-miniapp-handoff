"""Replay bounded HTTPS GET pagination only when the original method is known."""

import hashlib
import json
import math
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen

from .config import require_e_output
from .reconcile_data import _group_key
from .retry_assets import NUMBERED


def _page_urls(template, total):
    parsed = urlsplit(template)
    pairs = parse_qsl(parsed.query, keep_blank_values=True)
    values = {key.casefold(): value for key, value in pairs}
    if values.get("start", "").isdigit() and values.get("limit", "").isdigit():
        key = "start"
        step = int(values["limit"])
        first = 0
    else:
        key = next((name for name in ("page", "pageNum", "pageNumber", "current")
                    if values.get(name.casefold(), "").isdigit()), None)
        size = next((int(values[name]) for name in ("pagesize", "limit", "size")
                     if values.get(name, "").isdigit()), 0)
        if key is None or size < 1:
            return None
        step = size
        first = 1
    if step < 1 or step > 1000 or total < 1 or total > 100000:
        return None
    count = math.ceil(total / step)
    result = []
    for number in range(count):
        page_value = first + (number * step if key == "start" else number)
        updated = []
        for name, value in pairs:
            if name.casefold() == key.casefold():
                value = str(page_value)
            elif name.casefold() == "total" and value.isdigit():
                value = str(total)
            elif name.casefold() == "isend":
                value = "false"
            updated.append((name, value))
        result.append((page_value, urlunsplit((parsed.scheme, parsed.netloc, parsed.path,
                                               urlencode(updated), ""))))
    return key, result


def retry_missing_pages(run, audit, *, max_requests=100, max_body_bytes=20 * 1024 * 1024):
    run = Path(run).resolve()
    require_e_output(str(run))
    if audit.get("kind") != "miniapp-data-reconciliation" or audit.get("status") != "reconciled":
        raise ValueError("a verified data audit from this run is required")
    if not (1 <= max_requests <= 200 and 1 <= max_body_bytes <= 20 * 1024 * 1024):
        raise ValueError("invalid page retry limits")
    ledger = run / "responses.jsonl"
    entries = [json.loads(line) for line in ledger.read_text(encoding="utf-8").splitlines()]
    by_file = {entry.get("file"): entry for entry in entries if isinstance(entry, dict)}
    responses = run / "responses"
    highest = max((int(match.group(1)) for file in responses.iterdir()
                   if (match := NUMBERED.fullmatch(file.name))), default=0)
    result = {"kind": "get-pagination-retry", "attempts": [], "saved": 0, "failed": 0,
              "skipped": 0, "completeMiniapp": False}
    attempted_urls = set()
    for gap in audit.get("paginationGaps", []):
        sources = [by_file.get(name) for name in gap.get("sources", [])]
        sources = [entry for entry in sources if isinstance(entry, dict)]
        known_get = next((entry for entry in sources if entry.get("requestMethod") == "GET"), None)
        if known_get is None:
            result["attempts"].append({"endpoint": gap.get("endpoint"), "status": "skipped-method-unverified"})
            result["skipped"] += 1
            continue
        template = known_get.get("url", "")
        parsed = urlsplit(template)
        if parsed.scheme != "https" or not parsed.hostname:
            result["attempts"].append({"endpoint": gap.get("endpoint"), "status": "skipped-non-https"})
            result["skipped"] += 1
            continue
        pages = _page_urls(template, gap.get("expectedTotal", 0))
        if pages is None:
            result["attempts"].append({"endpoint": gap.get("endpoint"), "status": "skipped-unknown-pagination"})
            result["skipped"] += 1
            continue
        key, urls = pages
        normalized = _group_key(template, ())
        existing = set()
        for entry in entries:
            if (not isinstance(entry, dict) or entry.get("status") != "saved" or
                    _group_key(entry.get("url", ""), ()) != normalized):
                continue
            params = {name.casefold(): value for name, value in parse_qsl(urlsplit(entry["url"]).query)}
            if params.get(key.casefold(), "").isdigit():
                existing.add(int(params[key.casefold()]))
        for page_value, url in urls:
            if page_value in existing or url in attempted_urls:
                continue
            attempted_urls.add(url)
            attempt = {"url": url, "page": page_value, "endpoint": gap.get("endpoint")}
            if len(attempted_urls) > max_requests or highest >= 99999:
                attempt.update(status="skipped-limit")
                result["skipped"] += 1
                result["attempts"].append(attempt)
                continue
            try:
                request = Request(url, headers={"Accept": "application/json"}, method="GET")
                with urlopen(request, timeout=15) as response:
                    final_url = response.geturl()
                    if urlsplit(final_url).scheme != "https":
                        raise ValueError("pagination redirected outside HTTPS")
                    mime = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                    if mime != "application/json" and not mime.endswith("+json"):
                        raise ValueError("pagination returned non-JSON content")
                    body = response.read(max_body_bytes + 1)
                if not body or len(body) > max_body_bytes:
                    raise ValueError("pagination body is empty or too large")
                json.loads(body)
                digest = hashlib.sha256(body).hexdigest()
                highest += 1
                name = f"{highest:05d}-{digest[:16]}.json"
                relative = f"responses/{name}"
                with (responses / name).open("xb") as target:
                    target.write(body)
                entry = {"url": final_url, "kind": "json", "status": "saved", "file": relative,
                         "bytes": len(body), "sha256": digest, "requestMethod": "GET",
                         "source": "get-pagination-retry"}
                with ledger.open("a", encoding="utf-8") as target:
                    target.write(json.dumps(entry, ensure_ascii=False) + "\n")
                attempt.update(status="saved", file=relative, bytes=len(body), sha256=digest)
                result["saved"] += 1
            except (OSError, ValueError) as error:
                attempt.update(status="failed", error=str(error))
                result["failed"] += 1
            result["attempts"].append(attempt)
    temporary = run / "page-retry.json.tmp"
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(run / "page-retry.json")
    return result
