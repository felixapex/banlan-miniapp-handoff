"""Open a WeChat miniapp share code through the signed-in desktop self chat.

The verified coordinates and image fingerprints apply to this machine's current
718x582 WeChat layout. Any mismatch stops before sending a chat message.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import time

import win32api
import win32con
import win32gui
import win32process

from .brand_store import create_brand_run
from .config import require_e_output
from .windows_ui import _activate, _click, _capture, _process_name, _type_unicode, _windows


LINK = re.compile(r"^#小程序://(?P<brand>[^/]{1,64})/[A-Za-z0-9]{8,64}$")
MAIN_SIZE = (718, 582)
POPUP_SIZE = (368, 519)
SELF_HEADER_HASH = "c24cfc5786a9ef543d77ff41634104373c00023782dcd737b4fb57d71efadfda"
ACCOUNT_PAUSE = Path(__file__).resolve().parents[3] / "artifacts" / "isolated-android" / "ACCOUNT-AUTOMATION-PAUSED.txt"


def bmp_region_hash(file, rect):
    image = file.read_bytes()
    offset = struct.unpack_from("<I", image, 10)[0]
    width, height = struct.unpack_from("<ii", image, 18)
    depth = struct.unpack_from("<H", image, 28)[0]
    if depth != 32:
        raise RuntimeError("unexpected screenshot format")
    stride = ((width * depth + 31) // 32) * 4
    x1, y1, x2, y2 = rect
    if not (0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height):
        raise RuntimeError("invalid screenshot region")
    pixels = b"".join(image[offset + (height - 1 - y) * stride + x1 * 4:
                            offset + (height - 1 - y) * stride + x2 * 4] for y in range(y1, y2))
    return hashlib.sha256(pixels).hexdigest()


def bmp_pixel(file, x, y):
    image = file.read_bytes()
    offset = struct.unpack_from("<I", image, 10)[0]
    width, height = struct.unpack_from("<ii", image, 18)
    depth = struct.unpack_from("<H", image, 28)[0]
    if depth != 32 or not (0 <= x < width and 0 <= y < height):
        raise RuntimeError("unexpected screenshot format")
    stride = ((width * depth + 31) // 32) * 4
    start = offset + (height - 1 - y) * stride + x * 4
    return tuple(image[start:start + 4])


def locate_self_result(file):
    """Find the green File Transfer icon; its row can move as search results change."""
    image = file.read_bytes()
    offset = struct.unpack_from("<I", image, 10)[0]
    width, height = struct.unpack_from("<ii", image, 18)
    depth = struct.unpack_from("<H", image, 28)[0]
    if (width, height, depth) != (*POPUP_SIZE, 32):
        raise RuntimeError("search popup image format changed")
    stride = width * 4
    counts = []
    for y in range(height):
        row = image[offset + (height - 1 - y) * stride:offset + (height - y) * stride]
        count = 0
        for x in range(35, 70):
            blue, green, red, _ = row[x * 4:x * 4 + 4]
            if green > 150 and red < 100 and blue < 150:
                count += 1
        counts.append(count)
    top = [14, 18, 20, 22, 24, 26, 28, 23, 21]
    bottom = [28, 26, 24, 22, 20, 18, 14]
    matches = [y + 16 for y in range(0, height - 32)
               if counts[y:y + 9] == top and counts[y + 25:y + 32] == bottom]
    if len(matches) != 1:
        raise RuntimeError("File Transfer Assistant result was not uniquely identified")
    return matches[0]


def locate_newest_sent_link(file):
    """Locate the latest outgoing green message; older chat content can shift it."""
    image = file.read_bytes()
    offset = struct.unpack_from("<I", image, 10)[0]
    width, height = struct.unpack_from("<ii", image, 18)
    if (width, height) != MAIN_SIZE:
        raise RuntimeError("WeChat screenshot dimensions changed")
    stride = width * 4
    rows = []
    for y in range(80, 430):
        row = image[offset + (height - 1 - y) * stride:offset + (height - y) * stride]
        count = sum(row[x * 4:x * 4 + 3] == bytes((159, 242, 157)) for x in range(395, 635))
        if count > 150:
            rows.append(y)
    groups = []
    for y in rows:
        if groups and y - groups[-1][-1] <= 8:
            groups[-1].append(y)
        else:
            groups.append([y])
    candidates = [group for group in groups if group[-1] - group[0] >= 30]
    if not candidates:
        raise RuntimeError("sent miniapp code bubble was not found")
    newest = max(candidates, key=lambda group: group[-1])
    return (newest[0] + newest[-1]) // 2


def popup_for(main):
    _, pid = win32process.GetWindowThreadProcessId(main)
    matches = []
    def visit(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd) or win32gui.GetClassName(hwnd) != "Qt51514QWindowToolSaveBits":
            return
        _, owner = win32process.GetWindowThreadProcessId(hwnd)
        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
        if owner == pid and (right-left, bottom-top) == POPUP_SIZE:
            matches.append(hwnd)
    win32gui.EnumWindows(visit, None)
    if len(matches) != 1:
        raise RuntimeError("self-chat search popup is missing or ambiguous")
    return matches[0]


def run_link(link, run):
    if ACCOUNT_PAUSE.exists():
        raise RuntimeError(f"WeChat account automation is paused: {ACCOUNT_PAUSE}")
    main = _windows("微信", "Weixin.exe")
    if len(main) != 1:
        raise RuntimeError("expected one signed-in WeChat main window")
    _activate(main[0])
    left, top, right, bottom = win32gui.GetWindowRect(main[0])
    if (right-left, bottom-top) != MAIN_SIZE:
        raise RuntimeError("WeChat layout changed")

    _click(main[0], 150, 56)
    win32api.keybd_event(win32con.VK_CONTROL, 0, 0, 0)
    win32api.keybd_event(ord("A"), 0, 0, 0)
    win32api.keybd_event(ord("A"), 0, win32con.KEYEVENTF_KEYUP, 0)
    win32api.keybd_event(win32con.VK_CONTROL, 0, win32con.KEYEVENTF_KEYUP, 0)
    _type_unicode("文件传输助手")
    time.sleep(1)
    popup = popup_for(main[0])
    search_file = run / "self-search.bmp"
    _capture(popup, search_file)
    result_y = locate_self_result(search_file)
    if win32gui.GetForegroundWindow() != main[0]:
        raise RuntimeError("WeChat lost focus; nothing sent")
    left, top, _, _ = win32gui.GetWindowRect(popup)
    win32api.SetCursorPos((left + 110, top + result_y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    time.sleep(1)
    before = run / "self-chat-before-send.bmp"
    _capture(main[0], before)
    if bmp_region_hash(before, (310, 34, 480, 72)) != SELF_HEADER_HASH:
        raise RuntimeError("File Transfer Assistant header not verified; nothing sent")
    if bmp_pixel(before, 650, 530) != (237, 237, 237, 255):
        raise RuntimeError("self-chat draft is not empty; nothing sent")

    _click(main[0], 480, 480)
    _type_unicode(link)
    time.sleep(0.5)
    draft = run / "share-code-draft.bmp"
    _capture(main[0], draft)
    if bmp_pixel(draft, 650, 530) != (117, 195, 0, 255):
        raise RuntimeError("share code did not appear as a draft; nothing sent")
    _click(main[0], 660, 540)
    time.sleep(0.7)
    sent = run / "share-code-sent.bmp"
    _capture(main[0], sent)
    if bmp_pixel(sent, 650, 530) != (237, 237, 237, 255):
        raise RuntimeError("share code send state could not be verified")
    _click(main[0], 500, locate_newest_sent_link(sent))
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        foreground = win32gui.GetForegroundWindow()
        try:
            _, pid = win32process.GetWindowThreadProcessId(foreground)
            if _process_name(pid) == "wechatappex.exe":
                screenshot = run / "first-screen.bmp"
                time.sleep(1.5)
                _capture(foreground, screenshot)
                result = {"link": link, "windowTitle": win32gui.GetWindowText(foreground),
                          "screenshot": screenshot.name, "openedAt": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
                (run / "share-intake.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
                return result
        except Exception:
            pass
        time.sleep(0.25)
    raise RuntimeError("share code did not open a miniapp window")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--link", required=True)
    parser.add_argument("--run")
    args = parser.parse_args()
    match = LINK.fullmatch(args.link)
    if not match:
        parser.error("expected #小程序://品牌/口令")
    if ACCOUNT_PAUSE.exists():
        raise RuntimeError(f"WeChat account automation is paused: {ACCOUNT_PAUSE}")
    if args.run:
        run = Path(args.run).resolve()
        require_e_output(str(run))
        source = json.loads((run / "input.json").read_text(encoding="utf-8"))
        if source.get("link") != args.link or run.parent.name != "runs":
            parser.error("run input link does not match")
    else:
        root = Path(__file__).resolve().parents[3] / "artifacts" / "brands"
        run = create_brand_run(root, match.group("brand"), args.link)
    print(json.dumps({"run": str(run), **run_link(args.link, run)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
