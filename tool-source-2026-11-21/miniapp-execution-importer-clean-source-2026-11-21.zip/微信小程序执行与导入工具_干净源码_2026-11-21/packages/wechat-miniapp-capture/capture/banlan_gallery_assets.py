"""Save original gallery images named by the public gallery response."""

import argparse
import hashlib
import json
from pathlib import Path
from pathlib import PurePosixPath
import re
import time
from urllib.parse import quote, unquote, urlsplit, urlunsplit
from urllib.request import urlopen

from .banlan_public_catalog import saved_entries
from .config import require_e_output


HOST = "mp-banlan-product.oss-cn-shenzhen.aliyuncs.com"
MAX_IMAGE_BYTES = 32 * 1024 * 1024


def normalized_url(value):
    parsed = urlsplit(value.strip())
    if parsed.scheme != "https" or parsed.hostname != HOST or parsed.username or parsed.password:
        return None
    return urlunsplit(("https", HOST, quote(unquote(parsed.path), safe="/-_.~"), parsed.query, ""))


def image_suffix(data):
    if data.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return ".gif"
    if data.startswith(b"RIFF") and data[8:12] == b"WEBP":
        return ".webp"
    raise ValueError("response is not a recognized image")


def references(posts):
    refs = {}
    unresolved = []
    inferred = []
    for post in posts:
        tokens = []
        for field in ("img_urls", "select_index"):
            value = post.get(field) or ""
            if not isinstance(value, str):
                continue
            for raw in re.split(r"[,，]", value):
                if raw.strip():
                    tokens.append((field, raw.strip()))
        absolute = [normalized_url(raw) for _, raw in tokens]
        absolute = [url for url in absolute if url]
        for field, raw in tokens:
            url = normalized_url(raw)
            if url is None and not raw.startswith(("/", "\\")) and ".." not in PurePosixPath(raw).parts:
                relative = PurePosixPath(raw)
                candidates = set()
                for known in absolute:
                    parsed = urlsplit(known)
                    parent = PurePosixPath(unquote(parsed.path)).parent
                    if len(relative.parts) >= 2 and parent.name == relative.parts[0]:
                        candidates.add(normalized_url(f"https://{HOST}{parent.parent / relative}"))
                candidates.discard(None)
                if len(candidates) == 1:
                    url = candidates.pop()
                    inferred.append({"postId": str(post["id"]), "field": field, "value": raw, "resolvedUrl": url})
            if url:
                refs.setdefault(url, set()).add(str(post["id"]))
            else:
                unresolved.append({"postId": str(post["id"]), "field": field, "value": raw})
    return refs, unresolved, inferred


def existing_files(base):
    found = {}
    asset_path = base / "referenced-assets" / "manifest.json"
    if asset_path.is_file():
        manifest = json.loads(asset_path.read_text(encoding="utf-8"))
        for entry in manifest.get("assets", {}).values():
            if entry.get("status") == "saved" and entry.get("url") and entry.get("file"):
                url = normalized_url(entry["url"])
                path = base / entry["file"]
                if url and path.is_file():
                    found[url] = path
    for entry in saved_entries(base):
        if entry.get("kind") == "image" and entry.get("status") == "saved":
            url = normalized_url(entry.get("url", ""))
            path = base / entry["file"]
            if url and path.is_file():
                found[url] = path
    return found


def fetch_asset(url, output):
    with urlopen(url, timeout=20) as response:
        if urlsplit(response.geturl()).hostname != HOST:
            raise ValueError("image redirected to a different host")
        body = response.read(MAX_IMAGE_BYTES + 1)
    if not body or len(body) > MAX_IMAGE_BYTES:
        raise ValueError("image is empty or exceeds 32 MiB")
    suffix = image_suffix(body)
    path = output / (hashlib.sha256(url.encode("utf-8")).hexdigest()[:24] + suffix)
    part = path.with_suffix(path.suffix + ".part")
    try:
        part.write_bytes(body)
        part.replace(path)
    finally:
        part.unlink(missing_ok=True)
    return path, body


def save_images(base, deep):
    posts_path = deep / "gallery" / "all-posts.json"
    posts = json.loads(posts_path.read_text(encoding="utf-8"))["posts"]
    refs, unresolved, inferred = references(posts)
    output = deep / "gallery" / "assets"
    output.mkdir(parents=True, exist_ok=True)
    (deep / "gallery" / "unresolved-image-references.json").write_text(
        json.dumps(unresolved, ensure_ascii=False, indent=2), encoding="utf-8")
    (deep / "gallery" / "inferred-image-references.json").write_text(
        json.dumps(inferred, ensure_ascii=False, indent=2), encoding="utf-8")
    old = existing_files(base)
    ledger = output / "manifest.jsonl"
    done = {}
    verification_path = deep / "gallery" / "verification.json"
    repair_urls = set()
    if verification_path.is_file():
        previous_check = json.loads(verification_path.read_text(encoding="utf-8"))
        repair_urls = {item["url"] for item in previous_check.get("failures", [])
                       if item.get("reason") == "size or SHA-256 mismatch"}
    if ledger.is_file():
        for line in ledger.read_text(encoding="utf-8").splitlines():
            if line:
                entry = json.loads(line)
                if (entry.get("status") in ("saved", "reused") and entry["url"] not in repair_urls
                        and Path(entry.get("file", "")).is_file()):
                    done[entry["url"]] = entry
    for index, url in enumerate(sorted(refs), 1):
        if url in done:
            continue
        record = {"url": url, "postIds": sorted(refs[url])}
        try:
            if url in old:
                path = old[url]
                body = path.read_bytes()
                image_suffix(body)
                record["status"] = "reused"
            else:
                path, body = fetch_asset(url, output)
                record["status"] = "saved"
            record.update({"file": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()})
        except Exception as error:
            record.update({"status": "error", "error": str(error)})
        with ledger.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        if index % 25 == 0 or record["status"] == "error":
            print(json.dumps({"index": index, "total": len(refs), "status": record["status"]}), flush=True)
        if record["status"] == "saved":
            time.sleep(0.1)
    latest = {}
    for line in ledger.read_text(encoding="utf-8").splitlines():
        entry = json.loads(line)
        if entry["url"] in refs:
            latest[entry["url"]] = entry
    summary = {"posts": len(posts), "uniqueImageUrls": len(refs),
               "unresolvedReferences": unresolved, "inferredRelativeReferences": inferred,
               "saved": sum(e["status"] == "saved" for e in latest.values()),
               "reused": sum(e["status"] == "reused" for e in latest.values()),
               "errors": [e for e in latest.values() if e["status"] == "error"]}
    (deep / "gallery" / "asset-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-run", required=True)
    parser.add_argument("--deep-run", required=True)
    args = parser.parse_args()
    base = Path(args.base_run).resolve()
    deep = Path(args.deep_run).resolve()
    require_e_output(str(base))
    require_e_output(str(deep))
    if base.parent != deep.parent or base.parent.name != "runs" or not (deep / "input.json").is_file():
        parser.error("expected Banlan brand runs on E")
    result = save_images(base, deep)
    print(json.dumps({k: len(v) if k in ("errors", "unresolvedReferences", "inferredRelativeReferences") else v
                      for k, v in result.items()}))


if __name__ == "__main__":
    main()
