"""Verify that each saved product scroll begins on a visible detail page."""

import argparse
import json
from pathlib import Path

from .config import require_e_output
from .open_share_code import bmp_region_hash


HEADER_RECT = (156, 20, 264, 60)


def verify(base, deep, invalidate=False):
    expected = bmp_region_hash(base / "product-detail-1.bmp", HEADER_RECT)
    ledger = deep / "product-long-results.jsonl"
    latest = {}
    if ledger.is_file():
        for line in ledger.read_text(encoding="utf-8").splitlines():
            entry = json.loads(line)
            latest[entry["id"]] = entry
    valid = []
    invalid = []
    for product_id, entry in latest.items():
        if entry.get("status") != "saved":
            continue
        try:
            manifest = (deep / entry["manifest"]).resolve()
            if not manifest.is_relative_to(deep) or not manifest.is_file():
                raise ValueError("manifest missing or outside run")
            steps = json.loads(manifest.read_text(encoding="utf-8"))["steps"]
            if len(steps) != entry["screens"] or not steps[-1].get("endOfPage"):
                raise ValueError("screen count or end-of-page marker does not match")
            for step in steps:
                screenshot = (deep / step["file"]).resolve()
                if not screenshot.is_relative_to(deep) or not screenshot.is_file():
                    raise ValueError("screenshot missing or outside run")
            first = (deep / steps[0]["file"]).resolve()
            if bmp_region_hash(first, HEADER_RECT) != expected:
                raise ValueError("first visible frame is not the stable product-detail page")
            valid.append(product_id)
        except (KeyError, IndexError, OSError, ValueError) as error:
            invalid.append({"id": product_id, "reason": str(error)})
    if invalidate:
        with ledger.open("a", encoding="utf-8") as output:
            for item in invalid:
                output.write(json.dumps({"id": item["id"], "status": "invalid", "reason": item["reason"]}, ensure_ascii=False) + "\n")
    result = {"savedEntriesChecked": len(valid) + len(invalid), "verifiedProducts": len(valid),
              "verifiedIds": valid, "invalid": invalid}
    (deep / "product-long-verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-run", required=True)
    parser.add_argument("--deep-run", required=True)
    parser.add_argument("--invalidate", action="store_true")
    args = parser.parse_args()
    base = Path(args.base_run).resolve()
    deep = Path(args.deep_run).resolve()
    require_e_output(str(base))
    require_e_output(str(deep))
    if base.parent != deep.parent or base.parent.name != "runs":
        parser.error("base and deep runs must belong to the same E-drive brand")
    result = verify(base, deep, args.invalidate)
    print(json.dumps({"savedEntriesChecked": result["savedEntriesChecked"],
                      "verifiedProducts": result["verifiedProducts"], "invalid": result["invalid"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
