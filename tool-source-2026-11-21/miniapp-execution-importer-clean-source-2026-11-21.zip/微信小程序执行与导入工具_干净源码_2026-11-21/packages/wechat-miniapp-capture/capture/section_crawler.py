"""Visit the visible Banlan tabs and save each entire scrollable page."""

import argparse
import json
from pathlib import Path
import time

import win32gui

from .config import require_e_output
from .full_page import capture_page, changed_ratio, content_pixels
from .windows_ui import _capture, _click, _windows


SECTIONS = {
    "gallery": (48, 75, "brand-gallery-list", "brand-main.bmp"),
    "designers": (130, 75, "brand-designers-list", "brand-designers-entry.bmp"),
    "news": (295, 75, "brand-news-list", "brand-news-entry.bmp"),
    "about": (370, 75, "brand-about", "brand-about-entry.bmp"),
    "stores": (298, 748, "stores-page", "stores-entry.bmp"),
    "mine": (380, 748, "mine-page", "mine-entry.bmp"),
}


def page_finished(run, slug):
    manifest = run / "screenshots" / "long-pages" / slug / "manifest.json"
    if not manifest.is_file():
        return False
    steps = json.loads(manifest.read_text(encoding="utf-8")).get("steps", [])
    return bool(steps and steps[-1].get("endOfPage"))


def visit(title, run, sections):
    windows = _windows(title, "WeChatAppEx.exe")
    if len(windows) != 1:
        raise RuntimeError("expected one miniapp window")
    hwnd = windows[0]
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    if (right - left, bottom - top) != (430, 788):
        raise RuntimeError("miniapp window changed size")
    progress_path = run / "section-progress.json"
    progress = json.loads(progress_path.read_text(encoding="utf-8")) if progress_path.is_file() else []
    for section in sections:
        x, y, slug, entry_name = SECTIONS[section]
        before = run / ".section-before.bmp"
        _capture(hwnd, before)
        _click(hwnd, x, y)
        time.sleep(1.1)
        entry = run / entry_name
        _capture(hwnd, entry)
        ratio = changed_ratio(content_pixels(before, 430, 788, 105, 715),
                              content_pixels(entry, 430, 788, 105, 715))
        if ratio < 0.03 and not page_finished(run, slug):
            raise RuntimeError(f"{section} tab did not visibly open ({ratio:.4f})")
        before.unlink(missing_ok=True)
        if page_finished(run, slug):
            steps = json.loads((run / "screenshots" / "long-pages" / slug / "manifest.json").read_text(encoding="utf-8"))["steps"]
        else:
            steps = capture_page(title, run, slug, 200, -520, 430, 788, 105, 715, rewind_to_top=True)
        result = {"section": section, "screens": len(steps), "endOfPage": bool(steps[-1].get("endOfPage"))}
        progress = [entry for entry in progress if entry["section"] != section]
        progress.append(result)
        progress_path.write_text(json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(result), flush=True)
        if not result["endOfPage"]:
            raise RuntimeError(f"{section} page did not reach bottom within 200 scrolls")
    return progress


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--sections", nargs="+", choices=tuple(SECTIONS), required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected one existing E-drive brand run")
    visit(args.title, run, args.sections)


if __name__ == "__main__":
    main()
