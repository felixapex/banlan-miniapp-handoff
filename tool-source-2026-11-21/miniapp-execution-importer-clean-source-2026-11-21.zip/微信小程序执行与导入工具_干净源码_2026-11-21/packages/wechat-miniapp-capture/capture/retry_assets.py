"""Retry only image URLs explicitly found in this run's verified JSON bodies."""

import hashlib
import json
from pathlib import Path
import re
from urllib.parse import quote, urlsplit, urlunsplit
from urllib.request import Request, urlopen

from .config import require_e_output


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg", ".avif", ".bmp"}
NUMBERED = re.compile(r"^(\d{5})-[0-9a-f]{16}\.[a-z0-9]+$", re.I)


def retry_missing_images(run, audit, *, max_assets=2000, max_asset_bytes=20 * 1024 * 1024,
                         max_total_bytes=512 * 1024 * 1024):
    run = Path(run).resolve()
    require_e_output(str(run))
    if not (1 <= max_assets <= 10000 and 1 <= max_asset_bytes <= 20 * 1024 * 1024 and
            max_asset_bytes <= max_total_bytes <= 1024 * 1024 * 1024):
        raise ValueError("invalid image retry limits")
    if audit.get("kind") != "miniapp-data-reconciliation" or audit.get("status") != "reconciled":
        raise ValueError("a verified data audit from this run is required")
    responses = run / "responses"
    responses.mkdir(exist_ok=True)
    ledger = run / "responses.jsonl"
    if not ledger.is_file():
        raise ValueError("response ledger is missing")
    highest = max((int(match.group(1)) for file in responses.iterdir()
                   if (match := NUMBERED.fullmatch(file.name))), default=0)
    remaining = max_total_bytes
    result = {"kind": "image-reference-retry", "attempts": [], "saved": 0, "failed": 0,
              "skipped": 0, "completeMiniapp": False}
    seen = set()
    references = [("absolute", item) for item in audit.get("missingImageReferences", [])]
    references.extend(("relative", item) for item in audit.get("relativeImageReferences", []))
    for origin, item in references:
        url = item.get("url") if origin == "absolute" else item.get("candidateUrl")
        key = (origin, url or item.get("value"), item.get("source"))
        if key in seen:
            continue
        seen.add(key)
        attempt = {"url": url, "origin": origin,
                   "sourceJson": item.get("sourceJson", [item.get("source")] if item.get("source") else [])}
        if not isinstance(url, str):
            attempt.update(status="skipped-no-unique-observed-image-host")
            result["skipped"] += 1
            result["attempts"].append(attempt)
            continue
        if len(result["attempts"]) >= max_assets or highest >= 99999 or remaining <= 0:
            attempt.update(status="skipped-limit", error="image retry limit reached")
            result["skipped"] += 1
            result["attempts"].append(attempt)
            continue
        try:
            parsed = urlsplit(url)
            extension = Path(parsed.path).suffix.lower()
            if parsed.scheme != "https" or not parsed.hostname or extension not in IMAGE_EXTENSIONS:
                raise ValueError("image reference is not a supported HTTPS image URL")
            request_url = urlunsplit((parsed.scheme, parsed.netloc, quote(parsed.path, safe="/%"),
                                      quote(parsed.query, safe="=&%"), ""))
            request = Request(request_url, headers={"Accept": "image/*"})
            chunks = []
            size = 0
            with urlopen(request, timeout=15) as response:
                if urlsplit(response.geturl()).scheme != "https":
                    raise ValueError("image redirected outside HTTPS")
                content_type = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                if not content_type.startswith("image/"):
                    raise ValueError("image URL returned a non-image response")
                while True:
                    block = response.read(min(1024 * 1024, max_asset_bytes + 1 - size))
                    if not block:
                        break
                    size += len(block)
                    if size > max_asset_bytes or size > remaining:
                        raise ValueError("image response exceeded retry byte limit")
                    chunks.append(block)
            if size == 0:
                raise ValueError("image URL returned an empty body")
            body = b"".join(chunks)
            digest = hashlib.sha256(body).hexdigest()
            highest += 1
            name = f"{highest:05d}-{digest[:16]}{extension}"
            relative = f"responses/{name}"
            with (responses / name).open("xb") as target:
                target.write(body)
            entry = {"url": url, "kind": "image", "status": "saved", "file": relative,
                     "bytes": size, "sha256": digest, "source": "image-reference-retry"}
            with ledger.open("a", encoding="utf-8") as target:
                target.write(json.dumps(entry, ensure_ascii=False) + "\n")
            attempt.update(status="saved", file=relative, bytes=size, sha256=digest)
            result["saved"] += 1
            remaining -= size
        except (OSError, ValueError) as error:
            attempt.update(status="failed", error=str(error))
            result["failed"] += 1
        result["attempts"].append(attempt)
    temporary = run / "asset-retry.json.tmp"
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(run / "asset-retry.json")
    return result
