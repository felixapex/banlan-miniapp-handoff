"""Read and verify response files already captured in one E: brand run."""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import re
import secrets
import time

from .config import require_e_output


class ResponseObserver:
    # A saved JSONL file alone does not prove a live collector is attached to this UI session.
    channel_verified = False

    def __init__(self, run):
        self.run = Path(run).resolve()
        require_e_output(str(self.run))
        self.ledger = self.run / "responses.jsonl"
        self.responses = (self.run / "responses").resolve()

    @property
    def available(self):
        return self.ledger.is_file()

    def checkpoint(self):
        return self.ledger.stat().st_size if self.available else None

    def changes(self, cursor):
        if not self.available:
            return []
        results = []
        with self.ledger.open("rb") as file:
            file.seek(cursor or 0)
            for line in file:
                try:
                    record = json.loads(line)
                    if not isinstance(record, dict):
                        raise ValueError("response ledger entry is not an object")
                    results.append(self._verify(record))
                except (ValueError, UnicodeDecodeError) as error:
                    results.append({"status": "invalid", "error": f"invalid response ledger entry: {error}"})
        return results

    def _verify(self, record):
        result = {key: record[key] for key in ("url", "kind", "file", "sha256", "bytes") if key in record}
        if record.get("status") != "saved":
            return {**result, "status": "not_saved", "sourceStatus": record.get("status"),
                    "error": record.get("error")}
        value = record.get("file")
        if not isinstance(value, str) or not value.startswith("responses/") or "\\" in value:
            return {**result, "status": "invalid", "error": "unsafe response path"}
        location = (self.run / value).resolve()
        if not location.is_relative_to(self.responses) or not location.is_file():
            return {**result, "status": "invalid", "error": "response file missing or outside run"}
        expected = record.get("sha256")
        if not isinstance(expected, str) or len(expected) != 64:
            return {**result, "status": "invalid", "error": "response hash missing"}
        digest = hashlib.sha256()
        size = 0
        with location.open("rb") as file:
            for block in iter(lambda: file.read(1024 * 1024), b""):
                digest.update(block)
                size += len(block)
        if digest.hexdigest() != expected or size != record.get("bytes"):
            return {**result, "status": "invalid", "error": "response hash or size mismatch"}
        return {**result, "status": "verified"}


class ActiveResponseObserver(ResponseObserver):
    """Accept a collector only while its owned process and bound heartbeat are live."""

    supports_page_inspection = True

    def __init__(self, run, process, session_id, app_id, max_age_seconds=3):
        super().__init__(run)
        if not re.fullmatch(r"[0-9a-f]{32}", session_id or "", re.I):
            raise ValueError("invalid collector session ID")
        if not re.fullmatch(r"wx[0-9a-f]{16}", app_id or "", re.I):
            raise ValueError("invalid miniapp AppID")
        self.process = process
        self.session_id = session_id
        self.app_id = app_id
        self.max_age_seconds = max_age_seconds

    def _live_heartbeat(self):
        try:
            if self.process.poll() is not None or not self.available:
                return None
            ready = json.loads((self.run / "collector-ready.json").read_text(encoding="utf-8"))
            heartbeat = json.loads((self.run / "collector-heartbeat.json").read_text(encoding="utf-8"))
            if any(value.get("sessionId") != self.session_id or value.get("appId") != self.app_id
                   for value in (ready, heartbeat)):
                return None
            if any(type(heartbeat.get(key)) is not int or heartbeat[key] < 0
                   for key in ("inFlight", "pendingBodies")):
                return None
            moment = datetime.fromisoformat(heartbeat["heartbeatAt"].replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - moment).total_seconds()
            return heartbeat if 0 <= age <= self.max_age_seconds else None
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            return None

    @property
    def channel_verified(self):
        return self._live_heartbeat() is not None

    def checkpoint(self):
        if not self.channel_verified:
            raise RuntimeError("collector is not live or does not match this miniapp session")
        return super().checkpoint()

    def command(self, action, *, timeout=8, **arguments):
        """Send one bounded command to the owned collector and verify its reply."""
        if action not in {"inspectPages", "openObservedDetail"}:
            raise ValueError("unsupported collector command")
        if not self.channel_verified or self.process.stdin is None:
            raise RuntimeError("collector command channel is unavailable")
        command_id = secrets.randbits(52)
        target = self.run / "commands" / f"{command_id}.json"
        payload = json.dumps({"id": command_id, "action": action, **arguments}, ensure_ascii=False) + "\n"
        self.process.stdin.write(payload.encode("utf-8"))
        self.process.stdin.flush()
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if target.is_file():
                reply = json.loads(target.read_text(encoding="utf-8"))
                if (reply.get("id") != command_id or reply.get("sessionId") != self.session_id or
                        reply.get("appId") != self.app_id):
                    raise RuntimeError("collector command reply belongs to another session")
                if reply.get("status") != "ok":
                    raise RuntimeError(f"collector command failed: {reply.get('error')}")
                return reply
            if not self.channel_verified:
                raise RuntimeError("collector disconnected during command")
            time.sleep(0.05)
        raise TimeoutError(f"collector {action} command timed out")

    def changes(self, cursor):
        if not self.channel_verified:
            return [{"status": "capture-error", "error": "collector disconnected before response check"}]
        return super().changes(cursor)

    def settle(self, cursor, *, timeout=5, min_wait=1, quiet=0.3):
        """Wait for the owned collector's eligible requests and body writes to finish."""
        if not (0 <= min_wait < timeout <= 30 and 0 < quiet < timeout):
            raise ValueError("invalid response settle limits")
        start = time.monotonic()
        deadline = start + timeout
        stable_since = None
        previous_size = None
        while time.monotonic() < deadline:
            heartbeat = self._live_heartbeat()
            if heartbeat is None:
                return [{"status": "capture-error", "error": "collector disconnected during response settle"}]
            size = self.ledger.stat().st_size
            idle = heartbeat["inFlight"] == 0 and heartbeat["pendingBodies"] == 0
            if idle and size == previous_size:
                stable_since = stable_since or time.monotonic()
            else:
                stable_since = None
            previous_size = size
            now = time.monotonic()
            if idle and stable_since is not None and now - stable_since >= quiet and now - start >= min_wait:
                return super().changes(cursor)
            time.sleep(0.05)
        return [*super().changes(cursor), {"status": "capture-error", "error": "response activity did not settle"}]
