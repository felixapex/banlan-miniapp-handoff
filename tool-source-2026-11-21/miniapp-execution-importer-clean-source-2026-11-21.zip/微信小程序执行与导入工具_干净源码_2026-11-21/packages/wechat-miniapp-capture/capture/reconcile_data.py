"""Reconcile every captured response against visible product and image references.

This proves only the references returned in this run. It never claims that an
unvisited server page or inaccessible resource was discovered.
"""

import hashlib
import json
from pathlib import Path
import re
from urllib.parse import parse_qsl, unquote, urlencode, urlsplit, urlunsplit

from .config import require_e_output
from .response_observer import ResponseObserver


IMAGE_SUFFIX = re.compile(r"\.(?:jpe?g|png|webp|gif|svg|avif|bmp)$", re.I)
URL = re.compile(r"https://[^\s\"'<>;,|]+", re.I)
PRODUCT_PATH = re.compile(r"/(?:products?|goods?|items?)(?:/|$)", re.I)
DETAIL_PATH = re.compile(r"/(?:products?|goods?|items?)/([^/]+)$", re.I)
DETAIL_QUERY_ENDINGS = {"detail", "details", "getdetail", "productdetail", "gooddetail", "goodsdetail"}
DETAIL_ID_KEYS = {"id", "gid", "productid", "product_id", "goodid", "goodsid", "itemid"}
PAGE_KEYS = {"page", "pagenum", "pagenumber", "current", "offset", "pagesize", "cursor"}
LIST_KEYS = ("items", "list", "records", "products", "goods", "rows")
TOTAL_KEYS = ("total", "totalCount", "total_count", "totalRow", "totalRows")


def _walk(value, limit=100000):
    stack = [((), value)]
    seen = 0
    while stack:
        path, item = stack.pop()
        seen += 1
        if seen > limit:
            raise ValueError("JSON traversal exceeded the safety limit")
        yield path, item
        if isinstance(item, dict):
            stack.extend((path + (str(key),), child) for key, child in item.items())
        elif isinstance(item, list):
            stack.extend((path + (str(index),), child) for index, child in enumerate(item))


def _image_references(value):
    for candidate in URL.findall(value):
        candidate = candidate.rstrip(".,;)]}")
        if IMAGE_SUFFIX.search(urlsplit(candidate).path):
            yield candidate


def _audit_walk(data, report, source):
    try:
        yield from _walk(data)
    except ValueError as error:
        report["jsonErrors"].append({"file": source, "error": str(error)})


def _item_id(item):
    if not isinstance(item, dict):
        return None
    for key in ("id", "productId", "product_id", "goodId", "goodsId", "itemId"):
        value = item.get(key)
        if isinstance(value, (str, int)) and not isinstance(value, bool) and str(value):
            return str(value)
    product = item.get("product")
    if isinstance(product, dict):
        return _item_id(product)
    return None


def _has_descriptive_text(item):
    try:
        for path, value in _walk(item, limit=10000):
            if not isinstance(value, str) or not path:
                continue
            if path[-1].casefold() in {"id", "productid", "goodid", "goodsid", "itemid", "sku", "code"}:
                continue
            stripped = value.strip()
            if (len(stripped) >= 2 and not stripped.startswith(("https://", "http://")) and
                    any(character.isalpha() for character in stripped)):
                return True
    except ValueError:
        return False


def _plain(value):
    return "".join(character.casefold() for character in value if character.isalnum())


def _detail_name_visible(data, texts):
    visible = _plain("".join(texts))
    names = {_plain(value) for path, value in _walk(data, limit=10000)
             if path and path[-1].casefold() in {"name", "title", "productname", "goodsname", "goodname"}
             and isinstance(value, str) and len(_plain(value)) >= 3}
    return any(name in visible for name in names)


def _detail_id_matches(data, ident):
    return any(_item_id(value) == ident and path and path[-1].casefold() in
               {"product", "good", "goodsdetail", "productdetail"}
               for path, value in _walk(data, limit=10000) if isinstance(value, dict))


def detail_id_from_url(url):
    parsed = urlsplit(url)
    ending = parsed.path.rstrip("/").rsplit("/", 1)[-1].casefold()
    if ending in DETAIL_QUERY_ENDINGS:
        ids = {value for key, value in parse_qsl(parsed.query, keep_blank_values=True)
               if key.casefold() in DETAIL_ID_KEYS and value}
        return next(iter(ids)) if len(ids) == 1 else None
    match = DETAIL_PATH.search(parsed.path)
    return unquote(match.group(1)) if match else None


def _product_list_kind(endpoint, items):
    if not PRODUCT_PATH.search(endpoint) or not items:
        return "other"
    if re.search(r"/(?:products|goods|items)(?:/|$)", endpoint, re.I):
        return "product"
    if any(isinstance(item, dict) and
           any(key in item for key in ("price", "salePrice", "sku", "productId", "goodId", "goodsId"))
           for item in items):
        return "product"
    if all(isinstance(item, dict) and "children" in item and "sort" in item for item in items):
        return "category"
    return "unknown"


def _group_key(url, object_path):
    parsed = urlsplit(url)
    pairs = parse_qsl(parsed.query, keep_blank_values=True)
    numbers = {key.casefold(): value for key, value in pairs}
    start_paging = numbers.get("start", "").isdigit() and numbers.get("limit", "").isdigit()
    removed = PAGE_KEYS | ({"start", "limit", "total", "isend"} if start_paging else set())
    retained = [(key, value) for key, value in pairs if key.casefold() not in removed]
    normalized = urlunsplit((parsed.scheme, parsed.netloc, parsed.path,
                             urlencode(sorted(retained)), ""))
    return normalized + "#" + "/".join(object_path)


def _verified_png(run, relative, expected):
    if not isinstance(relative, str) or not isinstance(expected, str):
        return False
    screenshot = (run / relative).resolve()
    if not screenshot.is_relative_to(run) or not screenshot.is_file():
        return False
    digest = hashlib.sha256()
    with screenshot.open("rb") as file:
        first = file.read(8)
        digest.update(first)
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    return first == b"\x89PNG\r\n\x1a\n" and digest.hexdigest() == expected


def reconcile_data(run, *, save_report=True):
    run = Path(run).resolve()
    require_e_output(str(run))
    ledger = run / "responses.jsonl"
    report = {"kind": "miniapp-data-reconciliation", "verifiedResponseFiles": 0,
              "responseFileErrors": [], "jsonErrors": [], "paginationGaps": [], "unknownPagination": [],
              "missingProductDetails": [], "missingProductScreenshots": [], "missingDetailText": [],
              "ambiguousProductLists": [],
              "missingImageReferences": [],
              "relativeImageReferences": [], "matchedRelativeImages": 0, "retryQueue": [],
              "observedDataVerified": False, "completeMiniapp": False}
    if not ledger.is_file():
        report["status"] = "response-ledger-unavailable"
        if save_report:
            (run / "data-audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return report

    observer = ResponseObserver(run)
    captured_images = set()
    captured_image_paths = {}
    image_sources = {}
    relative_candidates = []
    listing_groups = {}
    product_lists = {}
    detail_files = {}
    detail_text_ids = set()
    verified_entry_by_file = {}
    def verified_json():
        with ledger.open("r", encoding="utf-8") as source:
            for number, line in enumerate(source, 1):
                try:
                    entry = json.loads(line)
                    if not isinstance(entry, dict):
                        raise ValueError("ledger entry is not an object")
                except ValueError as error:
                    report["responseFileErrors"].append({"line": number, "error": str(error)})
                    continue
                checked = observer._verify(entry)
                if checked.get("status") != "verified":
                    report["responseFileErrors"].append({"line": number, "file": entry.get("file"),
                        "error": checked.get("error", checked.get("sourceStatus"))})
                    continue
                report["verifiedResponseFiles"] += 1
                verified_entry_by_file[entry.get("file")] = entry
                if entry.get("kind") == "image" and isinstance(entry.get("url"), str):
                    captured_images.add(entry["url"].split("#", 1)[0])
                    image_path = unquote(urlsplit(entry["url"]).path).lstrip("/")
                    captured_image_paths.setdefault(image_path, set()).add(entry["url"])
                if entry.get("kind") != "json":
                    continue
                try:
                    yield entry, json.loads((run / entry["file"]).read_text(encoding="utf-8"))
                except (UnicodeDecodeError, ValueError, OSError) as error:
                    report["jsonErrors"].append({"file": entry["file"], "error": str(error)})

    parsed_count = 0
    for entry, data in verified_json():
        parsed_count += 1
        source_url = entry.get("url", "")
        for path, value in _audit_walk(data, report, entry["file"]):
            if isinstance(value, str):
                for ref in _image_references(value):
                    image_sources.setdefault(ref, set()).add(entry["file"])
                if IMAGE_SUFFIX.search(urlsplit(value).path) and not value.startswith("https://"):
                    relative_candidates.append({"source": entry["file"], "value": value[:500]})
            if not isinstance(value, dict):
                continue
            items = next((value[key] for key in LIST_KEYS if isinstance(value.get(key), list)), None)
            if items is not None:
                ids = [_item_id(item) for item in items]
                identities = {ident or hashlib.sha256(json.dumps(item, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
                              for ident, item in zip(ids, items)}
                key = _group_key(source_url, path)
                group = listing_groups.setdefault(key, {"endpoint": urlsplit(source_url).path,
                                                         "groupHash": hashlib.sha256(key.encode()).hexdigest()[:16],
                                                         "items": set(), "totals": set(), "sources": set()})
                group["items"].update(identities)
                group["sources"].add(entry["file"])
                total = next((value[name] for name in TOTAL_KEYS if type(value.get(name)) is int), None)
                if total is not None and total >= 0:
                    group["totals"].add(total)
                list_kind = _product_list_kind(urlsplit(source_url).path, items)
                if list_kind == "product":
                    product_lists.setdefault(key, set()).update(ident for ident in ids if ident)
                elif list_kind == "unknown":
                    report["ambiguousProductLists"].append({"endpoint": group["endpoint"],
                        "groupHash": group["groupHash"], "source": entry["file"]})
            if any(part.casefold() in {"product", "good", "goodsdetail", "productdetail"} for part in path):
                ident = _item_id(value)
                if ident and ident == detail_id_from_url(source_url):
                    detail_files.setdefault(ident, set()).add(entry["file"])
                    if _has_descriptive_text(value):
                        detail_text_ids.add(ident)

    for candidate in relative_candidates:
        relative_path = unquote(urlsplit(candidate["value"]).path).lstrip("/")
        matches = {url for image_path, urls in captured_image_paths.items()
                   if image_path == relative_path or image_path.endswith("/" + relative_path)
                   for url in urls}
        if len(matches) == 1:
            report["matchedRelativeImages"] += 1
        else:
            unresolved = {**candidate, "reason": "ambiguous" if matches else "not-captured"}
            if not matches and "/" in relative_path:
                prefix = relative_path.split("/", 1)[0]
                hosts = {urlsplit(url).netloc for url, sources in image_sources.items()
                         if candidate["source"] in sources and
                         unquote(urlsplit(url).path).lstrip("/").split("/", 1)[0] == prefix}
                if len(hosts) == 1:
                    unresolved["candidateUrl"] = urlunsplit(("https", next(iter(hosts)),
                        "/" + relative_path, urlsplit(candidate["value"]).query, ""))
            report["relativeImageReferences"].append(unresolved)

    screenshot_responses = set()
    manifest = run / "capture.json"
    if manifest.is_file():
        try:
            capture = json.loads(manifest.read_text(encoding="utf-8"))
            for attempt in capture.get("attempts", []):
                before = attempt.get("before") or {}
                after = attempt.get("after") or {}
                if (attempt.get("status") != "changed_page" or
                        before.get("fingerprint") == after.get("fingerprint")):
                    continue
                relative = after.get("screenshot")
                expected = after.get("screenshotSha256")
                if not _verified_png(run, relative, expected):
                    continue
                screenshot_responses.update(response.get("file") for response in attempt.get("responses", [])
                                            if response.get("status") == "verified")
        except (OSError, ValueError, TypeError, AttributeError) as error:
            report["jsonErrors"].append({"file": "capture.json", "error": str(error)})

    retries = run / "screenshot-retries.json"
    if retries.is_file():
        try:
            evidence = json.loads(retries.read_text(encoding="utf-8"))
            source = json.loads((run / "input.json").read_text(encoding="utf-8"))
            if evidence.get("appId") != source.get("appId"):
                raise ValueError("screenshot retry AppID does not match this run")
            for attempt in evidence.get("attempts", []):
                if attempt.get("status") != "saved":
                    continue
                if (not _verified_png(run, attempt.get("screenshot"), attempt.get("screenshotSha256")) or
                        attempt.get("beforeSha256") == attempt.get("screenshotSha256")):
                    report["jsonErrors"].append({"file": attempt.get("screenshot"), "error": "invalid detail screenshot evidence"})
                    continue
                ident = attempt.get("id")
                route = attempt.get("route")
                key = attempt.get("paramKey")
                if not any(page.get("route") == route and str((page.get("options") or {}).get(key)) == ident
                           for page in attempt.get("pages", [])):
                    report["jsonErrors"].append({"file": attempt.get("screenshot"), "error": "detail page ID mismatch"})
                    continue
                for response in attempt.get("responses", []):
                    if response.get("status") == "verified" and response.get("file") in attempt.get("detailJson", []):
                        entry = verified_entry_by_file.get(response["file"])
                        if entry is None or observer._verify(entry).get("status") != "verified":
                            continue
                        data = json.loads((run / response["file"]).read_text(encoding="utf-8"))
                        if _detail_id_matches(data, ident) and _detail_name_visible(data, attempt.get("texts", [])):
                            screenshot_responses.add(response["file"])
        except (OSError, ValueError, TypeError, AttributeError) as error:
            report["jsonErrors"].append({"file": "screenshot-retries.json", "error": str(error)})

    for group in listing_groups.values():
        if not group["totals"]:
            report["unknownPagination"].append({"endpoint": group["endpoint"], "groupHash": group["groupHash"],
                "observedItems": len(group["items"]), "sources": sorted(group["sources"])})
        else:
            expected = max(group["totals"])
            count = len(group["items"])
            if len(group["totals"]) > 1 or count < expected:
                report["paginationGaps"].append({"endpoint": group["endpoint"], "groupHash": group["groupHash"],
                    "expectedTotal": expected, "observedItems": count, "missingCount": max(0, expected - count),
                    "inconsistentTotals": len(group["totals"]) > 1, "sources": sorted(group["sources"])})
    for key, ids in product_lists.items():
        group = listing_groups[key]
        for ident in sorted(ids - detail_files.keys()):
            report["missingProductDetails"].append({"id": ident, "endpoint": group["endpoint"],
                "groupHash": group["groupHash"], "sourceLists": sorted(group["sources"])})
        for ident in sorted(ids & detail_files.keys() - detail_text_ids):
            report["missingDetailText"].append({"id": ident, "detailJson": sorted(detail_files[ident])})
        if manifest.is_file():
            for ident in sorted(ids & detail_files.keys()):
                if not detail_files[ident] & screenshot_responses:
                    report["missingProductScreenshots"].append({"id": ident, "detailJson": sorted(detail_files[ident])})
    for ref, sources in sorted(image_sources.items()):
        if ref not in captured_images:
            report["missingImageReferences"].append({"url": ref, "sourceJson": sorted(sources)})
    for key, kind in (("responseFileErrors", "response-file"), ("jsonErrors", "json-parse"),
                      ("paginationGaps", "pagination"), ("unknownPagination", "unknown-pagination"),
                      ("ambiguousProductLists", "ambiguous-product-list"),
                      ("missingProductDetails", "product-detail"),
                      ("missingProductScreenshots", "product-screenshot"),
                      ("missingDetailText", "detail-text"),
                      ("missingImageReferences", "image"), ("relativeImageReferences", "relative-image")):
        report["retryQueue"].extend({"kind": kind, **item} for item in report[key])
    report["status"] = "reconciled"
    report["observedDataVerified"] = parsed_count > 0 and not report["retryQueue"]
    if save_report:
        temporary = run / "data-audit.json.tmp"
        temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(run / "data-audit.json")
    return report
