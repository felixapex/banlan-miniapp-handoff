"""Revisit observed product pages while the bound miniapp collector is live."""

import hashlib
import json
from pathlib import Path
import re
import secrets
import time

from .config import require_e_output
from .reconcile_data import detail_id_from_url, _detail_name_visible
from .retry_details import _contains_detail_id
from .response_observer import ResponseObserver


ID = re.compile(r"[A-Za-z0-9_-]{1,80}$")
PNG = b"\x89PNG\r\n\x1a\n"


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _observed_routes(run, app_id):
    """Require a product response and matching page option in one click attempt."""
    source = json.loads((run / "input.json").read_text(encoding="utf-8"))
    if source.get("appId") != app_id:
        raise ValueError("observed route AppID differs from this run")
    manifest = json.loads((run / "capture.json").read_text(encoding="utf-8"))
    ledger = {}
    verifier = ResponseObserver(run)
    for line in (run / "responses.jsonl").read_text(encoding="utf-8").splitlines():
        try:
            entry = json.loads(line)
        except ValueError:
            continue
        if isinstance(entry, dict) and verifier._verify(entry).get("status") == "verified":
            ledger[entry.get("file")] = entry
    routes = set()
    for attempt in manifest.get("attempts", []):
        for response in attempt.get("responses", []):
            if response.get("status") != "verified" or response.get("kind") != "json":
                continue
            entry = ledger.get(response.get("file"), {})
            ident = detail_id_from_url(entry.get("url", ""))
            if not isinstance(ident, str) or not ID.fullmatch(ident):
                continue
            try:
                data = json.loads((run / response["file"]).read_text(encoding="utf-8"))
            except (OSError, UnicodeDecodeError, ValueError):
                continue
            if not _contains_detail_id(data, ident):
                continue
            for page in attempt.get("after", {}).get("pages", []):
                options = page.get("options") or {}
                route = page.get("route")
                if (isinstance(route, str) and isinstance(options, dict) and
                        re.fullmatch(r"[A-Za-z0-9_/-]{1,160}", route)):
                    routes.update((route, key) for key, value in options.items()
                                  if isinstance(key, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,40}", key)
                                  and str(value) == ident)
    return routes


def retry_missing_product_screenshots(run, audit, observer, device, *, ocr=None, max_actions=500):
    run = Path(run).resolve()
    require_e_output(str(run))
    if audit.get("kind") != "miniapp-data-reconciliation" or audit.get("status") != "reconciled":
        raise ValueError("a current reconciliation is required")
    if not 1 <= max_actions <= 1000 or not observer.channel_verified:
        raise ValueError("bounded actions and a live bound collector are required")
    routes = _observed_routes(run, observer.app_id)
    result = {"kind": "product-screenshot-retry", "appId": observer.app_id,
              "sessionId": observer.session_id, "attempts": [], "saved": 0, "failed": 0,
              "skipped": 0, "newSaved": 0, "completeMiniapp": False}
    previous = run / "screenshot-retries.json"
    if previous.is_file():
        earlier = json.loads(previous.read_text(encoding="utf-8"))
        if earlier.get("appId") != observer.app_id:
            raise ValueError("existing screenshot retries belong to another miniapp")
        result["attempts"] = earlier.get("attempts", [])
        for entry in result["attempts"]:
            bucket = "saved" if entry.get("status") == "saved" else "skipped" if entry.get("status", "").startswith("skipped") else "failed"
            result[bucket] += 1
    targets = {item["id"] for kind in ("missingProductDetails", "missingProductScreenshots")
               for item in audit.get(kind, []) if isinstance(item.get("id"), str)}
    folder = run / "detail-screenshots"
    folder.mkdir(exist_ok=True)
    for index, ident in enumerate(sorted(targets)):
        attempt = {"id": ident, "sessionId": observer.session_id}
        if index >= max_actions or not ID.fullmatch(ident) or len(routes) != 1:
            attempt["status"] = "skipped-limit-or-no-unique-observed-route"
            result["skipped"] += 1
            result["attempts"].append(attempt)
            continue
        route, key = next(iter(routes))
        attempt.update(route=route, paramKey=key)
        try:
            before = device.screenshot()
            if not before.startswith(PNG):
                raise ValueError("invalid before screenshot")
            cursor = observer.checkpoint()
            observer.command("openObservedDetail", route=route, paramKey=key, productId=ident)
            responses = observer.settle(cursor)
            time.sleep(0.3)
            after = device.screenshot()
            hierarchy = device.hierarchy()
            page_reply = observer.command("inspectPages")
            words = ocr.recognize(after) if ocr is not None else []
            pages = page_reply.get("pages", [])
            matched_page = any(page.get("route") == route and str((page.get("options") or {}).get(key)) == ident
                               for page in pages)
            detail_files = []
            visible_detail = False
            for response in responses:
                if response.get("status") != "verified" or response.get("kind") != "json":
                    continue
                try:
                    data = json.loads((run / response["file"]).read_text(encoding="utf-8"))
                    if _contains_detail_id(data, ident):
                        detail_files.append(response["file"])
                        visible_detail = visible_detail or _detail_name_visible(
                            data, [word.get("text", "") for word in words])
                except (OSError, UnicodeDecodeError, ValueError, KeyError):
                    pass
            if (not after.startswith(PNG) or _sha(before) == _sha(after) or
                    not matched_page or not detail_files or not visible_detail):
                raise ValueError("detail page, changed screenshot, visible product name, and matching response not all verified")
            name = f"{index + 1:05d}-{ident}-{secrets.token_hex(5)}"
            png = f"detail-screenshots/{name}.png"
            xml = f"detail-screenshots/{name}.xml"
            with (run / png).open("xb") as target:
                target.write(after)
            with (run / xml).open("xb") as target:
                target.write(hierarchy)
            attempt.update(status="saved", screenshot=png, screenshotSha256=_sha(after),
                           ui=xml, uiSha256=_sha(hierarchy), beforeSha256=_sha(before),
                           texts=sorted({word.get("text", "").strip() for word in words if word.get("text", "").strip()}),
                           pages=pages, responses=responses, detailJson=detail_files)
            result["saved"] += 1
            result["newSaved"] += 1
        except Exception as error:
            attempt.update(status="failed", error=str(error))
            result["failed"] += 1
        result["attempts"].append(attempt)
        temporary = run / "screenshot-retries.json.tmp"
        temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(run / "screenshot-retries.json")
    if targets:
        temporary = run / "screenshot-retries.json.tmp"
        temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(run / "screenshot-retries.json")
    return result
