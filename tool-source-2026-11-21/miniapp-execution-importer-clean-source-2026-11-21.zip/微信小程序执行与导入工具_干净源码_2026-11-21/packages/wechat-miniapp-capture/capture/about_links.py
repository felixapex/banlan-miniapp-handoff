"""Open Banlan's story and six material cards from its About page."""

import argparse
import json
from pathlib import Path
import time

import win32api
import win32con
import win32gui

from .config import require_e_output
from .full_page import capture_page, changed_ratio, content_pixels
from .windows_ui import _activate, _capture, _click, _windows


LINKS = [
    ("brand-story", 360, 510, "top"),
    ("stone", 112, 430, "bottom"),
    ("wood", 250, 430, "bottom"),
    ("metal", 388, 430, "bottom"),
    ("leather", 112, 573, "bottom"),
    ("fabric", 250, 573, "bottom"),
    ("goose-down", 388, 573, "bottom"),
]


def position(hwnd, run, placement):
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    if (right - left, bottom - top) != (430, 788):
        raise RuntimeError("miniapp window changed size")
    current = run / "about-position.bmp"
    previous = run / "about-position-previous.bmp"
    for _ in range(30):
        _capture(hwnd, previous)
        _activate(hwnd)
        win32api.SetCursorPos((left + 215, top + 400))
        win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0,
                             10000 if placement == "top" else -10000, 0)
        time.sleep(0.7)
        _capture(hwnd, current)
        if changed_ratio(content_pixels(previous, 430, 788, 105, 715),
                         content_pixels(current, 430, 788, 105, 715)) < 0.01:
            break
    else:
        raise RuntimeError(f"About page {placement} did not stop scrolling")
    previous.unlink(missing_ok=True)
    reference = run / "screenshots" / "long-pages" / "brand-about" / (
        "screen-000.bmp" if placement == "top" else "screen-005.bmp")
    sample_top, sample_bottom = (630, 715) if placement == "bottom" else (105, 715)
    ratio = changed_ratio(content_pixels(current, 430, 788, sample_top, sample_bottom),
                          content_pixels(reference, 430, 788, sample_top, sample_bottom))
    limit = 0.08 if placement == "bottom" else 0.18
    if ratio > limit:
        raise RuntimeError(f"About page {placement} position could not be verified ({ratio:.3f})")
    return current


def collect(title, run):
    windows = _windows(title, "WeChatAppEx.exe")
    if len(windows) != 1:
        raise RuntimeError("expected one miniapp window")
    hwnd = windows[0]
    _click(hwnd, 370, 75)
    time.sleep(0.8)
    output = run / "about-links"
    output.mkdir(parents=True, exist_ok=True)
    records_path = output / "manifest.json"
    records = json.loads(records_path.read_text(encoding="utf-8")) if records_path.is_file() else []
    for slug, x, y, placement in LINKS:
        if any(record.get("link") == slug and record.get("endOfPage") for record in records):
            continue
        before = position(hwnd, run, placement)
        _click(hwnd, x, y)
        time.sleep(0.8)
        entered = output / f"{slug}-entry.bmp"
        _capture(hwnd, entered)
        ratio = changed_ratio(content_pixels(before, 430, 788, 105, 715),
                              content_pixels(entered, 430, 788, 105, 715))
        if ratio < 0.1:
            raise RuntimeError(f"About link {slug} did not visibly open")
        page_identity = "brand-story" if slug == "brand-story" else "materials"
        previous_page = next((record for record in records
                              if record.get("pageIdentity") == page_identity and record.get("endOfPage")), None)
        detail_slug = previous_page["detailSlug"] if previous_page else f"about-{page_identity}"
        if previous_page:
            manifest = run / "screenshots" / "long-pages" / detail_slug / "manifest.json"
            steps = json.loads(manifest.read_text(encoding="utf-8"))["steps"]
        else:
            steps = capture_page(title, run, detail_slug, 200, -520, 430, 788, 55, 775,
                                 rewind_to_top=True)
        record = {"link": slug, "entryScreenshot": str(entered.relative_to(run)).replace("\\", "/"),
                  "pageIdentity": page_identity, "detailSlug": detail_slug,
                  "screens": len(steps), "endOfPage": bool(steps[-1].get("endOfPage"))}
        records.append(record)
        records_path.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(record), flush=True)
        if not record["endOfPage"]:
            raise RuntimeError(f"About link {slug} did not reach bottom")
        _click(hwnd, 38, 40)
        time.sleep(0.8)
    before.unlink(missing_ok=True)
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--title", required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected an existing E-drive brand run")
    collect(args.title, run)


if __name__ == "__main__":
    main()
