"""Independently reconcile visible miniapp capture files and action coverage."""

import argparse
import hashlib
import json
from pathlib import Path

from .config import require_e_output
from .reconcile_data import reconcile_data
from .response_observer import ResponseObserver


def verify_capture(run):
    run = Path(run).resolve()
    require_e_output(str(run))
    source = json.loads((run / "capture.json").read_text(encoding="utf-8"))
    if source.get("kind") != "visible-miniapp-capture":
        raise ValueError("not a visible miniapp capture")
    file_errors = []
    checked = set()

    def check(relative, expected, signature=None):
        if not isinstance(relative, str) or not isinstance(expected, str):
            file_errors.append({"file": relative, "error": "missing path or hash"})
            return
        destination = (run / relative).resolve()
        if not destination.is_relative_to(run) or not destination.is_file():
            file_errors.append({"file": relative, "error": "missing or unsafe path"})
            return
        key = (relative, expected)
        if key in checked:
            return
        checked.add(key)
        digest = hashlib.sha256()
        with destination.open("rb") as file:
            first = file.read(8)
            digest.update(first)
            for block in iter(lambda: file.read(1024 * 1024), b""):
                digest.update(block)
        if signature is not None and first != signature:
            file_errors.append({"file": relative, "error": "invalid file signature"})
        if digest.hexdigest() != expected:
            file_errors.append({"file": relative, "error": "SHA-256 mismatch"})

    observations = list(source.get("screens", []))
    for attempt in source.get("attempts", []):
        observations.extend(attempt[key] for key in ("before", "after", "restored") if isinstance(attempt.get(key), dict))
    for scroll in source.get("scrolls", []):
        if isinstance(scroll.get("after"), dict):
            observations.append(scroll["after"])
    retries = run / "screenshot-retries.json"
    if retries.is_file():
        retry_data = json.loads(retries.read_text(encoding="utf-8"))
        for attempt in retry_data.get("attempts", []):
            if attempt.get("status") == "saved":
                observations.append(attempt)
    for observation in observations:
        check(observation.get("screenshot"), observation.get("screenshotSha256"), b"\x89PNG\r\n\x1a\n")
        check(observation.get("ui"), observation.get("uiSha256"))

    screens = source.get("screens", [])
    controls = {control["id"]: (screen, control) for screen in screens
                for control in screen.get("controls", [])}
    attempts_by_id = {}
    for attempt in source.get("attempts", []):
        attempts_by_id.setdefault(attempt["action"]["id"], []).append(attempt)
    blocked = sum(control.get("status") == "blocked" for screen in screens for control in screen.get("controls", []))
    unverified = sum(control.get("status") == "unverified" for screen in screens for control in screen.get("controls", []))
    inspection_gaps = [{"screen": screen.get("screenshot"), "reason": "icon_inspection_not_completed"}
                       for screen in screens if screen.get("iconInspectionStatus") != "completed"]
    response_observer = ResponseObserver(run)
    ledger_entries = {}
    if response_observer.available:
        for line in response_observer.ledger.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            if isinstance(entry, dict) and isinstance(entry.get("file"), str):
                ledger_entries.setdefault(entry["file"], []).append(entry)

    def verified_response_record(response):
        fields = ("file", "sha256", "bytes", "url", "kind")
        if response.get("status") != "verified" or any(response.get(key) is None for key in fields):
            return False
        return any(entry.get("status") == "saved" and
                   all(entry.get(key) == response.get(key) for key in fields) and
                   response_observer._verify(entry).get("status") == "verified"
                   for entry in ledger_entries.get(response["file"], []))

    response_errors = []
    for attempt in source.get("attempts", []):
        for response in attempt.get("responses", []):
            if not verified_response_record(response):
                response_errors.append({"actionId": attempt["action"]["id"], "file": response.get("file"),
                                        "error": response.get("error") or "response_not_in_verified_collector_ledger"})
    scroll_response_errors = []
    for number, scroll in enumerate(source.get("scrolls", [])):
        if scroll.get("superseded"):
            continue
        for response in scroll.get("responses", []):
            if not verified_response_record(response):
                scroll_response_errors.append({"scrollIndex": number, "file": response.get("file"),
                    "error": response.get("error") or "response_not_in_verified_collector_ledger"})
        if scroll.get("responses") is not None:
            expected_data = [item.get("file") for item in scroll["responses"] if item.get("kind") == "json" and item.get("status") == "verified"]
            expected_images = [item.get("file") for item in scroll["responses"] if item.get("kind") == "image" and item.get("status") == "verified"]
            if scroll.get("dataFiles") != expected_data or scroll.get("imageFiles") != expected_images:
                scroll_response_errors.append({"scrollIndex": number, "error": "response_file_inventory_mismatch"})
    unavailable = sum(item.get("responseCapture") != "available" for item in source.get("attempts", []))
    scroll_unavailable = sum(item.get("responseCapture") != "available" for item in source.get("scrolls", [])
                             if item.get("status") in {"moved", "unchanged", "end"} and not item.get("superseded"))
    scroll_limits = sum(item.get("status") in {"limit", "unavailable"} and not item.get("superseded")
                        for item in source.get("scrolls", []))
    scrolls = [item for item in source.get("scrolls", []) if not item.get("superseded")]
    end_proofs = set()
    transitions = {}
    for number, scroll in enumerate(scrolls):
        origin = scroll.get("from")
        after = scroll.get("after")
        destination = after.get("fingerprint") if isinstance(after, dict) else None
        if scroll.get("responseCapture") != "available" or not isinstance(after, dict):
            continue
        if scroll.get("status") == "end" and origin == destination and not scroll.get("responses"):
            if any(previous.get("from") == origin and previous.get("status") == "unchanged" and
                   isinstance(previous.get("after"), dict) and previous["after"].get("fingerprint") == origin and
                   previous.get("responseCapture") == "available" and not previous.get("responses")
                   for previous in scrolls[:number]):
                end_proofs.add(origin)
        elif scroll.get("status") in {"moved", "unchanged"} and destination:
            transitions.setdefault(origin, set()).add(destination)

    def reaches_end(fingerprint):
        visited = set()
        stack = [fingerprint]
        while stack:
            current = stack.pop()
            if current in end_proofs:
                return True
            if current in visited:
                continue
            visited.add(current)
            stack.extend(transitions.get(current, ()))
        return False

    entrypoints = {screen["fingerprint"]: screen for screen in screens[:1]}
    for attempt in source.get("attempts", []):
        if attempt.get("status") in {"changed_page", "overlay_dismissed"}:
            after = attempt.get("after") or {}
            if after.get("fingerprint"):
                entrypoints[after["fingerprint"]] = after
    scroll_coverage_gaps = [{"fingerprint": fingerprint, "screen": entry.get("screenshot"),
                             "reason": "page_bottom_not_verified"}
                            for fingerprint, entry in entrypoints.items() if not reaches_end(fingerprint)]
    bad_files = {error.get("file") for error in file_errors}

    def attempt_failure(attempt):
        if attempt.get("responseCapture") != "available":
            return "response_capture_unavailable"
        responses = attempt.get("responses") or []
        if not responses:
            return "no_response_observed"
        if any(not verified_response_record(item) for item in responses):
            return "response_not_verified"
        before, after = attempt.get("before"), attempt.get("after")
        if not isinstance(before, dict) or not isinstance(after, dict):
            return "missing_before_or_after_screen"
        for observation in (before, after, attempt.get("restored")):
            if observation is None:
                continue
            if (not isinstance(observation, dict) or not isinstance(observation.get("texts"), list) or
                    observation.get("screenshot") in bad_files or observation.get("ui") in bad_files or
                    not observation.get("screenshot") or not observation.get("ui")):
                return "screen_or_text_evidence_invalid"
        status = attempt.get("status")
        if status == "changed_page":
            restored = attempt.get("restored")
            if (before.get("fingerprint") == after.get("fingerprint") or
                    not isinstance(restored, dict) or restored.get("fingerprint") != before.get("fingerprint")):
                return "return_or_page_change_unverified"
        elif status == "overlay_dismissed":
            if before.get("fingerprint") == after.get("fingerprint"):
                return "overlay_change_unverified"
        elif status == "no_change":
            if before.get("fingerprint") != after.get("fingerprint"):
                return "page_change_unrecorded"
            return "no_visible_change"
        else:
            return attempt.get("failureReason") or "action_status_unverified"
        expected_data = [item.get("file") for item in responses if item.get("kind") == "json"]
        expected_images = [item.get("file") for item in responses if item.get("kind") == "image"]
        if attempt.get("dataFiles") != expected_data or attempt.get("imageFiles") != expected_images:
            return "response_file_inventory_mismatch"
        if attempt.get("branchComplete") is not True:
            return attempt.get("failureReason") or "branch_incomplete"
        return None

    control_ledger = []
    for identifier, (screen, control) in controls.items():
        attempts = attempts_by_id.get(identifier, [])
        if control.get("status") != "eligible":
            reason = control.get("reason") or control.get("status") or "unverified_control"
        elif not attempts:
            reason = "not_attempted"
        else:
            reason = None if any(attempt_failure(item) is None for item in attempts) else attempt_failure(attempts[-1])
        last = attempts[-1] if attempts else {}
        control_ledger.append({"id": identifier, "label": control.get("label"),
            "source": control.get("source"), "screen": screen.get("screenshot"),
            "result": "verified" if reason is None else "incomplete", "reason": reason,
            "attemptCount": len(attempts), "lastStatus": last.get("status"),
            "beforeScreenshot": (last.get("before") or {}).get("screenshot"),
            "afterScreenshot": (last.get("after") or {}).get("screenshot"),
            "beforeTexts": (last.get("before") or {}).get("texts"),
            "afterTexts": (last.get("after") or {}).get("texts"),
            "dataFiles": last.get("dataFiles", []), "imageFiles": last.get("imageFiles", [])})
    pending = [item for item in control_ledger if item["result"] != "verified"]
    pending_ids = {item["id"] for item in pending}
    unresolved_response_errors = [item for item in response_errors if item.get("actionId") in pending_ids]
    orphan_attempts = [identifier for identifier in attempts_by_id if identifier not in controls]
    data_audit = reconcile_data(run)
    report = {"kind": "visible-miniapp-verification", "observedScreens": len(screens),
              "verifiedFiles": len(checked), "fileErrors": file_errors, "responseErrors": response_errors,
              "unresolvedResponseErrors": unresolved_response_errors,
              "scrollResponseErrors": scroll_response_errors,
              "pendingControls": len(pending), "retryQueue": pending, "controlLedger": control_ledger,
              "orphanAttempts": orphan_attempts,
              "blockedControls": blocked, "unverifiedControls": unverified,
              "inspectionGaps": inspection_gaps,
              "responseCaptureUnavailableActions": unavailable,
              "responseCaptureUnavailableScrolls": scroll_unavailable, "scrollLimits": scroll_limits,
              "scrollEndProofs": len(end_proofs), "scrollCoverageGaps": scroll_coverage_gaps,
              "stopReason": source.get("stopReason"), "dataAudit": data_audit,
              "completeMiniapp": False}
    report["observedScopeVerified"] = bool(screens) and not any((file_errors, unresolved_response_errors, scroll_response_errors,
        pending, orphan_attempts, blocked, unverified, inspection_gaps, scroll_unavailable, scroll_limits, scroll_coverage_gaps,
        source.get("errors"), source.get("stopReason"),
        source.get("coverage", {}).get("pageInspectionErrors"),
        source.get("coverage", {}).get("iconInspectionErrors"))) and data_audit["observedDataVerified"]
    (run / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    args = parser.parse_args()
    result = verify_capture(args.run)
    print(json.dumps({"observedScopeVerified": result["observedScopeVerified"],
                      "pendingControls": result["pendingControls"],
                      "fileErrors": len(result["fileErrors"]), "responseErrors": len(result["responseErrors"])}, ensure_ascii=False))
    if not result["observedScopeVerified"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
