"""Check the public store export and every referenced local storefront image."""

import argparse
import json
from pathlib import Path

from .banlan_stores import PUBLIC_FIELDS
from .config import require_e_output
from .verify_gallery import file_sha256


def verify(run):
    output = run / "stores"
    data = json.loads((output / "public-stores.json").read_text(encoding="utf-8"))
    stores = data["stores"]
    allowed = set(PUBLIC_FIELDS) | {"images"}
    if any(set(store) != allowed for store in stores):
        raise ValueError("public store export has unexpected fields")
    urls = {url for store in stores for url in store["images"]}
    ledger = {}
    for line in (output / "assets" / "manifest.jsonl").read_text(encoding="utf-8").splitlines():
        entry = json.loads(line)
        if entry["url"] in urls:
            ledger[entry["url"]] = entry
    failures = []
    for url in sorted(urls):
        entry = ledger.get(url)
        if not entry or entry.get("status") not in ("saved", "reused"):
            failures.append({"url": url, "reason": "not saved"})
            continue
        path = Path(entry["file"]).resolve()
        if not path.is_relative_to(run.parent.parent.resolve()) or not path.is_file():
            failures.append({"url": url, "reason": "file missing or outside brand directory"})
        elif path.stat().st_size != entry["bytes"] or file_sha256(path) != entry["sha256"]:
            failures.append({"url": url, "reason": "size or SHA-256 mismatch"})
    result = {"stores": len(stores), "imageUrls": len(urls),
              "filesVerified": len(urls) - len(failures), "failures": failures,
              "publicFieldsOnly": True}
    (output / "verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected an existing E-drive brand run")
    result = verify(run)
    print(json.dumps({**result, "failures": len(result["failures"])}))


if __name__ == "__main__":
    main()
