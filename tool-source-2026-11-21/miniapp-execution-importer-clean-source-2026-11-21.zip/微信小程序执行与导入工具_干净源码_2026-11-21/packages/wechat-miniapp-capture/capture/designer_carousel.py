"""Capture each visible Banlan designer carousel slide and its detail page."""

import argparse
import json
from pathlib import Path
import time

import win32api
import win32con
import win32gui

from .config import require_e_output
from .full_page import capture_page, changed_ratio, content_pixels
from .windows_ui import _activate, _capture, _click, _windows


def swipe_left(hwnd):
    _activate(hwnd)
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    if (right - left, bottom - top) != (430, 788):
        raise RuntimeError("miniapp window changed size")
    win32api.SetCursorPos((left + 350, top + 350))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    try:
        for x in range(350, 79, -15):
            win32api.SetCursorPos((left + x, top + 350))
            time.sleep(0.02)
    finally:
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    time.sleep(0.8)


def capture_designers(title, run):
    windows = _windows(title, "WeChatAppEx.exe")
    if len(windows) != 1:
        raise RuntimeError("expected one miniapp window")
    hwnd = windows[0]
    _click(hwnd, 130, 748)
    time.sleep(0.8)
    _click(hwnd, 130, 75)
    time.sleep(0.8)
    slides_dir = run / "designers" / "slides"
    slides_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for index in range(5):
        slide = slides_dir / f"slide-{index:02d}.bmp"
        _capture(hwnd, slide)
        if index:
            before = slides_dir / f"slide-{index-1:02d}.bmp"
            ratio = changed_ratio(content_pixels(before, 430, 788, 105, 610),
                                  content_pixels(slide, 430, 788, 105, 610))
            if ratio < 0.1:
                raise RuntimeError(f"designer slide {index} did not change")
        slug = "designer-hanyi-detail" if index == 0 else f"designer-slide-{index:02d}-detail"
        manifest = run / "screenshots" / "long-pages" / slug / "manifest.json"
        if index == 0 and manifest.is_file():
            steps = json.loads(manifest.read_text(encoding="utf-8"))["steps"]
        else:
            _click(hwnd, 378, 580)
            time.sleep(0.9)
            entered = slides_dir / ".entered.bmp"
            _capture(hwnd, entered)
            ratio = changed_ratio(content_pixels(slide, 430, 788, 105, 610),
                                  content_pixels(entered, 430, 788, 105, 610))
            if ratio < 0.1:
                raise RuntimeError(f"designer slide {index} detail did not open")
            steps = capture_page(title, run, slug, 200, -520, 430, 788, 55, 775, rewind_to_top=True)
            _click(hwnd, 38, 40)
            time.sleep(0.9)
            returned = slides_dir / ".returned.bmp"
            _capture(hwnd, returned)
            ratio = changed_ratio(content_pixels(slide, 430, 788, 105, 610),
                                  content_pixels(returned, 430, 788, 105, 610))
            if ratio > 0.15:
                raise RuntimeError(f"designer slide {index} did not return")
            entered.unlink(missing_ok=True)
            returned.unlink(missing_ok=True)
        record = {"slide": index, "screenshot": str(slide.relative_to(run)).replace("\\", "/"),
                  "detailSlug": slug, "detailScreens": len(steps),
                  "endOfPage": bool(steps[-1].get("endOfPage"))}
        records.append(record)
        (run / "designers" / "manifest.json").write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(record), flush=True)
        if not record["endOfPage"]:
            raise RuntimeError(f"designer slide {index} detail did not reach bottom")
        if index < 4:
            swipe_left(hwnd)
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--title", required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected an existing E-drive brand run")
    capture_designers(args.title, run)


if __name__ == "__main__":
    main()
