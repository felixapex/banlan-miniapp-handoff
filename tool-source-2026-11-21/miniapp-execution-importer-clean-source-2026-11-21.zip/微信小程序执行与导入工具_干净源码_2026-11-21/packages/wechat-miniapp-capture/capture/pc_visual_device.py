"""Visible Windows miniapp window adapter for the evidence-first explorer."""

import os
from pathlib import Path
import struct
import zlib

import win32api
import win32con
import win32gui
import win32process

from .config import require_e_output
from .windows_ui import _activate, _capture, _click, _process_name


ACCOUNT_PAUSE = Path(__file__).resolve().parents[3] / "artifacts" / "isolated-android" / "ACCOUNT-AUTOMATION-PAUSED.txt"
PNG = b"\x89PNG\r\n\x1a\n"


def _chunk(kind, payload):
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload))


def bmp32_to_png(bitmap):
    if len(bitmap) < 54 or bitmap[:2] != b"BM":
        raise ValueError("invalid PrintWindow BMP")
    offset = struct.unpack_from("<I", bitmap, 10)[0]
    width, signed_height = struct.unpack_from("<ii", bitmap, 18)
    planes, depth = struct.unpack_from("<HH", bitmap, 26)
    compression = struct.unpack_from("<I", bitmap, 30)[0]
    height = abs(signed_height)
    if not (1 <= width <= 10000 and 1 <= height <= 10000 and planes == 1 and depth == 32 and compression == 0):
        raise ValueError("unsupported PrintWindow BMP format")
    stride = width * 4
    if offset < 54 or len(bitmap) < offset + stride * height:
        raise ValueError("truncated PrintWindow BMP")
    rows = bytearray()
    for y in range(height):
        source_y = height - 1 - y if signed_height > 0 else y
        start = offset + source_y * stride
        row = bitmap[start:start + stride]
        rows.append(0)
        for x in range(0, len(row), 4):
            blue, green, red, _ = row[x:x + 4]
            # GDI PrintWindow does not define the BMP alpha byte.
            rows.extend((red, green, blue, 255))
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    return PNG + _chunk(b"IHDR", header) + _chunk(b"IDAT", zlib.compress(rows, 6)) + _chunk(b"IEND", b"")


class PcVisualDevice:
    def __init__(self, hwnd, run, back=(38, 40)):
        self.hwnd = int(hwnd)
        self.run = Path(run).resolve()
        require_e_output(str(self.run))
        self.back_point = back

    def _rect(self):
        if ACCOUNT_PAUSE.exists():
            raise RuntimeError(f"WeChat account automation is paused: {ACCOUNT_PAUSE}")
        if not win32gui.IsWindow(self.hwnd) or not win32gui.IsWindowVisible(self.hwnd):
            raise RuntimeError("miniapp window is not visible")
        _, pid = win32process.GetWindowThreadProcessId(self.hwnd)
        if _process_name(pid) != "wechatappex.exe":
            raise RuntimeError("target window is not WeChatAppEx.exe")
        left, top, right, bottom = win32gui.GetWindowRect(self.hwnd)
        if right <= left or bottom <= top:
            raise RuntimeError("miniapp window has invalid dimensions")
        return left, top, right, bottom

    def screenshot(self):
        self._rect()
        temporary = self.run / ".pc-window-snapshot.bmp"
        _capture(self.hwnd, temporary)
        try:
            return bmp32_to_png(temporary.read_bytes())
        finally:
            temporary.unlink(missing_ok=True)

    def hierarchy(self):
        self._rect()
        return b"<hierarchy/>"

    def tap(self, x, y):
        self._rect()
        _click(self.hwnd, int(x), int(y))

    def back(self):
        self.tap(*self.back_point)

    def swipe(self, x1, y1, x2, y2, duration_ms=350):
        left, top, right, bottom = self._rect()
        if not (0 <= x1 < right - left and 0 <= y1 < bottom - top):
            raise ValueError("scroll point outside miniapp window")
        _activate(self.hwnd)
        win32api.SetCursorPos((left + int(x1), top + int(y1)))
        win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, -520 if y2 < y1 else 520, 0)
