"""Check Banlan's public news list total and every original cover file."""

import argparse
import json
from pathlib import Path

from .config import require_e_output
from .verify_gallery import file_sha256


def verify(run):
    output = run / "news"
    source = json.loads((output / "all-articles.json").read_text(encoding="utf-8"))
    articles = source["articles"]
    latest = {}
    for line in (output / "covers" / "manifest.jsonl").read_text(encoding="utf-8").splitlines():
        entry = json.loads(line)
        latest[entry["url"]] = entry
    failures = []
    for url, entry in latest.items():
        if entry.get("status") not in ("saved", "reused"):
            failures.append({"url": url, "reason": entry.get("status")})
            continue
        file = Path(entry["file"]).resolve()
        if not file.is_relative_to(run.parent.parent.resolve()) or not file.is_file():
            failures.append({"url": url, "reason": "file missing or outside brand"})
        elif file.stat().st_size != entry["bytes"] or file_sha256(file) != entry["sha256"]:
            failures.append({"url": url, "reason": "size or SHA-256 mismatch"})
    result = {"reportedTotal": source["reportedTotal"], "uniqueArticles": len({str(a["id"]) for a in articles}),
              "coverUrls": len(latest), "coverFilesVerified": len(latest) - len(failures), "failures": failures}
    (output / "verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    require_e_output(str(run))
    if run.parent.name != "runs" or not (run / "input.json").is_file():
        parser.error("expected an existing E-drive brand run")
    result = verify(run)
    print(json.dumps({**result, "failures": len(result["failures"])}))


if __name__ == "__main__":
    main()
