"""Capture one shared third-party miniapp in an isolated desktop WeChat session.

The account pause marker is deliberately checked before any process or window
access. This entry point must not be used with the user's personal account.
"""

import argparse
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import time

import win32gui
import win32process

from capture.brand_store import create_brand_run
from capture.config import require_e_output
from capture.ocr import ScreenshotOcr
from capture.open_share_code import LINK, run_link
from capture.pc_visual_device import PcVisualDevice
from capture.reconcile_data import reconcile_data
from capture.response_observer import ActiveResponseObserver
from capture.retry_assets import retry_missing_images
from capture.retry_details import retry_missing_details
from capture.retry_pages import retry_missing_pages
from capture.retry_screenshots import retry_missing_product_screenshots
from capture.runner import _stop_owned, runtime_preflight
from capture.verify_visible_capture import verify_capture
from capture.visual_explorer import explore_visible
from capture.windows_ui import _process_name


PACKAGE = Path(__file__).resolve().parent
WORKSPACE = PACKAGE.parents[1]
BRANDS = WORKSPACE / "artifacts" / "brands"
ACCOUNT_PAUSE = WORKSPACE / "artifacts" / "isolated-android" / "ACCOUNT-AUTOMATION-PAUSED.txt"
APP_ID = re.compile(r"wx[0-9a-f]{16}", re.I)


def _guard():
    if ACCOUNT_PAUSE.exists():
        raise RuntimeError(f"WeChat account automation is paused: {ACCOUNT_PAUSE}")
    if (os.environ.get("WECHAT_ISOLATED_SESSION") != "1" or
            os.environ.get("WECHAT_ALLOW_FOREGROUND_INPUT") != "1"):
        raise RuntimeError("an isolated WeChat session with explicit foreground input is required")


def explore_until_reconciled(device, output, *, max_passes=3, **options):
    if not 1 <= max_passes <= 5:
        raise ValueError("exploration passes out of range")
    state = None
    for number in range(max_passes):
        state = explore_visible(device, output, **options)
        if (state.get("observedControlsDone") or state.get("stopReason") or
                state.get("coverage", {}).get("incompleteControls", 0) == 0):
            break
    state["explorationPasses"] = number + 1
    return state


def _run_path(link, brand, existing):
    if existing is None:
        return create_brand_run(BRANDS, brand, link), False
    run = Path(existing).resolve()
    require_e_output(str(run))
    if not run.is_relative_to(BRANDS.resolve()) or run.parent.name != "runs":
        raise ValueError("resume directory must be a brand run under E: artifacts/brands")
    source = json.loads((run / "input.json").read_text(encoding="utf-8"))
    if source.get("link") != link:
        raise ValueError("resume link does not match input.json")
    if not (run / "share-intake.json").is_file():
        raise ValueError("resume run has no original share intake")
    return run, True


def _wait_bridge(run, process, timeout=30):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError("owned WMPF bridge exited; inspect bridge.log")
        if "bridge ready" in (run / "bridge.log").read_text(encoding="utf-8", errors="replace"):
            return
        time.sleep(0.2)
    raise RuntimeError("owned WMPF bridge did not become ready")


def wait_collector_ready(run, process, session_id, timeout=30):
    ready = Path(run) / "collector-ready.json"
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError("owned collector exited before ready; inspect collector.log")
        if ready.is_file():
            try:
                state = json.loads(ready.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                time.sleep(0.1)
                continue
            if state.get("sessionId") != session_id:
                raise RuntimeError("collector session does not match this run")
            app_id = state.get("appId")
            if not isinstance(app_id, str) or not APP_ID.fullmatch(app_id):
                raise RuntimeError("collector ready file has no valid AppID")
            return app_id
        time.sleep(0.1)
    raise RuntimeError("collector AppID was not confirmed before timeout")


def _unique_miniapp_window(title):
    windows = []

    def visit(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd):
            return
        try:
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            if _process_name(pid) == "wechatappex.exe":
                windows.append(hwnd)
        except Exception:
            return

    win32gui.EnumWindows(visit, None)
    if len(windows) != 1 or win32gui.GetWindowText(windows[0]) != title:
        raise RuntimeError("the opened miniapp window is missing or ambiguous")
    if win32gui.GetForegroundWindow() != windows[0]:
        raise RuntimeError("miniapp window is not foreground; input cancelled")
    return windows[0]


def _require_no_open_miniapp():
    found = []

    def visit(hwnd, _):
        if not win32gui.IsWindowVisible(hwnd):
            return
        try:
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            if _process_name(pid) == "wechatappex.exe":
                found.append(hwnd)
        except Exception:
            return

    win32gui.EnumWindows(visit, None)
    if found:
        raise RuntimeError("an existing miniapp window could mix another app's responses into this new run")


def capture_pc(link, *, run=None, node="node", wmpf_version=26134,
               max_screens=100, max_depth=5, max_scrolls=20, max_actions=500):
    match = LINK.fullmatch(link or "")
    if not match:
        raise ValueError("expected #小程序://品牌/口令")
    _guard()
    _require_no_open_miniapp()
    runtime_preflight(PACKAGE, wmpf_version)
    ocr = ScreenshotOcr()
    output, resume = _run_path(link, match.group("brand"), run)
    bridge = collector = None
    result = None
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    with (output / "bridge.log").open("a", encoding="utf-8") as bridge_log, \
         (output / "collector.log").open("a", encoding="utf-8") as collector_log:
        try:
            bridge = subprocess.Popen([node, str(PACKAGE / "bridge/server.mjs"),
                                       "--version", str(wmpf_version)], cwd=PACKAGE,
                                      stdout=bridge_log, stderr=subprocess.STDOUT,
                                      creationflags=flags)
            _wait_bridge(output, bridge)
            session_id = secrets.token_hex(16)
            collector = subprocess.Popen([node, str(PACKAGE / "cdp/generic-collector.mjs"),
                                          "--output", str(output), "--url", "ws://127.0.0.1:62000",
                                          "--session-id", session_id, "--timeout", "120000"], cwd=PACKAGE,
                                         stdout=collector_log, stderr=subprocess.STDOUT,
                                         creationflags=flags)
            # On resume, keep the earlier share-intake evidence unchanged.
            intake_dir = output / "reopen" / secrets.token_hex(8) if resume else output
            intake_dir.mkdir(parents=True, exist_ok=True)
            intake = run_link(link, intake_dir)
            hwnd = _unique_miniapp_window(intake["windowTitle"])
            app_id = wait_collector_ready(output, collector, session_id, timeout=120)
            source = json.loads((output / "input.json").read_text(encoding="utf-8"))
            if source.get("appId") and source["appId"] != app_id:
                raise RuntimeError("resume AppID differs from original miniapp")
            if not source.get("appId"):
                source["appId"] = app_id
                (output / "input.json").write_text(json.dumps(source, ensure_ascii=False, indent=2), encoding="utf-8")
            observer = ActiveResponseObserver(output, collector, session_id, app_id)
            if not observer.channel_verified:
                raise RuntimeError("collector heartbeat did not confirm this miniapp session")
            device = PcVisualDevice(hwnd, output)
            state = explore_until_reconciled(device, output, ocr=ocr, observer=observer,
                                             allow_prepared_run=True, max_screens=max_screens,
                                             max_depth=max_depth, max_scrolls=max_scrolls,
                                             max_actions=max_actions)
            live_audit = reconcile_data(output)
            screenshot_retry = {"saved": 0, "failed": 0, "skipped": 0}
            screenshot_retry_error = None
            if live_audit["missingProductDetails"] or live_audit["missingProductScreenshots"]:
                try:
                    screenshot_retry = retry_missing_product_screenshots(
                        output, live_audit, observer, device, ocr=ocr, max_actions=max_actions)
                except Exception as error:
                    screenshot_retry_error = str(error)
            result = {"run": str(output), "appId": app_id,
                      "coverage": state["coverage"], "observedControlsDone": state["observedControlsDone"],
                      "explorationPasses": state["explorationPasses"],
                      "detailScreenshotsRecovered": screenshot_retry.get("newSaved", screenshot_retry["saved"]),
                      "detailScreenshotFailures": screenshot_retry["failed"],
                      "detailScreenshotRetryError": screenshot_retry_error,
                      "initialResponseCoverage": "unverified", "completeMiniapp": False}
        finally:
            _stop_owned(collector)
            _stop_owned(bridge)
            if (output / "capture.json").is_file():
                if result is not None:
                    audit = reconcile_data(output)
                    result["pagesRecovered"] = 0
                    if audit["paginationGaps"]:
                        try:
                            page_retry = retry_missing_pages(output, audit)
                            result["pagesRecovered"] = page_retry["saved"]
                        except Exception as error:
                            result["pageRetryError"] = str(error)
                        audit = reconcile_data(output)
                    result["detailsRecovered"] = 0
                    if audit["missingProductDetails"]:
                        try:
                            detail_retry = retry_missing_details(output, audit)
                            result["detailsRecovered"] = detail_retry["saved"]
                        except Exception as error:
                            result["detailRetryError"] = str(error)
                        audit = reconcile_data(output)
                    result["imagesRecovered"] = 0
                    if audit["missingImageReferences"]:
                        try:
                            retry = retry_missing_images(output, audit)
                            result["imagesRecovered"] = retry["saved"]
                        except Exception as error:
                            result["imageRetryError"] = str(error)
                report = verify_capture(output)
                if result is not None:
                    result["observedScopeVerified"] = report["observedScopeVerified"]
                    result["pendingControls"] = report["pendingControls"]
                    result["dataGaps"] = len(report["dataAudit"]["retryQueue"])
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--link", required=True)
    parser.add_argument("--run")
    parser.add_argument("--node", default="node")
    parser.add_argument("--wmpf-version", type=int, default=26134)
    parser.add_argument("--max-screens", type=int, default=100)
    parser.add_argument("--max-depth", type=int, default=5)
    parser.add_argument("--max-scrolls", type=int, default=20)
    parser.add_argument("--max-actions", type=int, default=500)
    args = parser.parse_args()
    result = capture_pc(args.link, run=args.run, node=args.node,
                        wmpf_version=args.wmpf_version,
                        max_screens=args.max_screens, max_depth=args.max_depth,
                        max_scrolls=args.max_scrolls, max_actions=args.max_actions)
    print(json.dumps(result, ensure_ascii=False))
    if (not result["observedScopeVerified"] or not result["completeMiniapp"] or
            result["initialResponseCoverage"] != "verified" or result.get("dataGaps", 0)):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
