# 微信小程序采集执行器

## 正式入口

- `pc_share_capture.py`：电脑微信分享口令采集编排；要求隔离测试会话和显式前台输入许可。
- `android_capture.py`：ADB 安卓设备可见界面遍历、截图和证据核验。
- `miniapp_capture.py`：Windows WMPF 采集、商品详情与资源导出入口。
- `owned_capture.mjs`：自有小程序源码与微信开发者工具连接入口。
- `public_web_capture.mjs`：小程序对应公开 HTTPS 网页采集入口。
- `source_inventory.py`：自有小程序源码页面与素材清点。

## 核心目录

- `capture/`：页面遍历、滚动、按钮台账、截图、响应关联、资源下载、断点续采与核验。
- `cdp/`：AppID 绑定的本地 CDP 采集器、资源策略和测试。
- `bridge/`：本地 WMPF 桥接协议、版本配置和测试。
- `config/`：经过记录的目标配置；换微信版本或小程序时必须重新核验。
- `tests/`：Python 回归测试和自包含的最小测试夹具。

## 测试

```powershell
npm ci
npm test
python -m unittest discover -s tests -v
```

程序会把观察范围内的证据逐项对账，但 `completeMiniapp` 保持 `false`，直到真实环境能够证明没有漏页、漏按钮、漏接口和漏资源。不得把局部采集改写为“整款小程序全部完成”。
