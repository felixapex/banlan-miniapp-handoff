# 微信小程序执行与导入工具：干净源码

本包只包含正式源码、配置、测试、必要测试夹具和技术文档。它不包含 `node_modules`、缓存、临时运行目录、历史实验脚本、品牌批量数据、微信登录资料或后端代码。

## 代码目录

- `packages/wechat-miniapp-capture/`：小程序采集执行器。
- `packages/wechat-miniapp-importer/`：把采集证据转换为编辑器组件与页面。
- `packages/import-foundation/`：三类导入器共用的数据契约，包含 `editor-data-contract.mjs`。

## 安装与测试

```powershell
cd packages\wechat-miniapp-capture
npm ci
python -m pip install -r ..\..\requirements-windows.txt
npm test
python -m unittest discover -s tests -v

cd ..\wechat-miniapp-importer
npm test
```

也可以在包根目录执行：

```powershell
pwsh -File verify-source.ps1
```

## 能力边界

采集器会为已发现的安全按钮保存点击前后截图、可见文字、接口响应、图片文件、哈希和失败原因，并在存在未核实项时保持未完成状态。

当前代码的离线与模拟通道测试通过，但不能声称“输入任意第三方小程序链接，就一定能后台取得整款小程序的所有数据”。未显现、无权限、未请求或服务端未返回的数据无法凭空取得；真实运行还受微信版本、账号风控、授权和目标小程序结构限制。

涉及微信、ADB、模拟器或 WMPF/Frida 的自动化，只能在取得授权的独立测试环境和专用账号中运行。不要用个人微信做批量自动点击。

禁止使用 Microsoft Edge。网页相关入口只允许使用隔离的 Google Chrome。
